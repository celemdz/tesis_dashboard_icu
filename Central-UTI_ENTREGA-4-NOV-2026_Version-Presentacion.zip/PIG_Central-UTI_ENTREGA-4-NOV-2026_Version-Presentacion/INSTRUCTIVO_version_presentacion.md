# Instructivo – Central UTI, versión de presentación del 4/11/2026

Versión: la **congelada del 31/10/2026** (un emisor único por cama) con **tres cambios en la interfaz** hechos el 4/11 (hora real del equipo, vista «Shock y oxigenación» protegida, y el tipo de ingreso en castellano sin los códigos de unidad de la base).
Carpeta del código: `PROYECTO INTEGRADOR\SCRIPTS\Plataforma_PRESENTACION_4-11` (dentro de este paquete).

Este paquete es independiente: trae su propia copia de `benchmark_uti.db` y de `tramos_base`. Lee la base en solo lectura y no modifica nada fuera de su carpeta.
**Importante:** la carpeta que contiene todo debe llamarse `PROYECTO INTEGRADOR` (como viene), porque el programa busca ese nombre para encontrar la base.

## 0. Antes de empezar

- Abrí **Anaconda Prompt**.
- Cerrá cualquier Streamlit que tengas abierto (si no, usá el puerto alternativo del paso 2).
- Verificá que exista `SCRIPTS\tramos_base` con 30 archivos (`.hea` y `.dat`). Sin ellos las pruebas de señal (B06) comparan 0 casos.

## 1. Entrar a la carpeta

```
cd "<donde descomprimiste>\PROYECTO INTEGRADOR\SCRIPTS\Plataforma_PRESENTACION_4-11"
```

Prueba rápida de que la base y los tramos se leen bien:

```
python verificar_plataforma.py
```

## 2. Abrir la interfaz (para la demostración)

```
streamlit run Interfaz_uti_db.py
```

Si el puerto está ocupado: `streamlit run Interfaz_uti_db.py --server.port 8502`

1. Clave de acceso: **123**.
2. Barra lateral: **INICIAR** para que corra el reloj (velocidad x1 a x60; «Ir al segundo» para saltar).
3. «Origen de los datos»:
   - **BASE DE DATOS**: lectura directa de las 15 camas.
   - **EMISORES VIRTUALES**: emisor → canal → receptor. «Replay» reproduce la base y «Sintético» usa los escenarios; «Inyectar fallas» activa las 6 fallas de transmisión de demostración.
4. Vistas: [1] visión general · [2] análisis detallado de una cama · [3] tablero de gravedad. Los indicadores de gestión y la AYUDA están en «Modo».

Esta versión usa un único emisor por cama; los emisores por dispositivo (monitor, enfermería, laboratorio) están en una versión aparte, en desarrollo, que no se incluye.

## 2 bis. Qué se cambió el 4/11

1. **Hora simulada = hora del equipo.** Al abrir la plataforma (o cambiar de origen, o tocar REINICIAR) la hora arranca en la hora real de la computadora y avanza con el reloj de simulación (t = 0 es la hora de inicio). Al usar «Ir al segundo» 900 se ve la hora de inicio + 15 min.
2. **Vista micro, «Shock y oxigenación» y demás detalles de indicadores.** Las tablas de detalle ahora son tablas HTML estáticas y los textos se escapan, en lugar de la grilla interactiva de Streamlit que se redibuja cada segundo dentro del fragmento. Además, cada tarjeta y cada detalle está protegido: si algo fallara, aparece un aviso amarillo con el motivo y el resto de la pantalla sigue armada.
3. **Tipo de ingreso en castellano.** En las tarjetas, el monitor individual y la gestión de camas ahora dice «Urgencia» o «Programado» (antes Emergency / Elective), junto a edad y sexo. Se quitó el código de unidad de la base (MICU, SICU, CCU), que no corresponde a la unidad simulada y confundía. Cambio en `datos_db.py`.

Verificación: con Streamlit real (1.66) recorrí las 15 camas × 5 detalles (NEWS2, qSOFA, SOFA, APACHE II, Shock y oxigenación), con base y con emisores virtuales: 0 excepciones, 0 avisos, hora correcta. **No pude reproducir el fallo original** en mi entorno, así que la corrección es preventiva. Si en la PC vuelve a aparecer, anotá el texto del aviso amarillo (o de la pantalla roja) y la versión de Streamlit (`streamlit --version`).

## 3. Correr la validación con emisores virtuales (≈ 50 s)

```
python validar_con_emisores.py --semillas 20
```

Resultados en `PROYECTO INTEGRADOR\SCRIPTS\Validacion_emisores\corrida_<fecha>\` (se crea sola). Leé primero **resumen.txt**. Valores obtenidos al verificar esta versión (20 semillas):

| Medida | Resultado |
|---|---|
| Sensibilidad global en escenarios sintéticos | 174/174 = 100 % |
| Falsas alarmas clínicas | 16 en 30 h simuladas (0,53 por hora-cama) |
| Alarmas técnicas en camas sin falla | 0 |
| Detección de las 6 fallas de transmisión (receptor) | 100 % |
| Integridad de la base | hash idéntico antes y después (`ea34f903…1992e4`) |

**Un detalle sobre el NEWS2.** El resumen informa la concordancia del NEWS2 contra la señal limpia: en esta versión da alrededor de 80,5 % exacta. Esta cifra tiene un error conocido: la memoria de indicadores de `scores_clinicos.py` podía reutilizar resultados de un receptor anterior, así que el valor cambia según el orden en que corras las pruebas. Con el error corregido (versión nueva) da 83,3 % exacta y diferencia media de 0,20 puntos. Las demás cifras de la tabla no cambian. Si presentás el NEWS2, aclará que es la cifra de la versión congelada.

## 4. Confirmar B06 con datos reales

B06 compara la frecuencia cardíaca calculada desde el **ECG real** (picos R detectados en los tramos de 125 Hz) contra la FC del monitor, en las 15 camas a los 900 y 1800 s (30 comparaciones, tolerancia ±5 lpm).

```
python pruebas_verificacion.py
```

Resultado esperado (verificado con tus datos reales):

```
RESULTADO: 27 de 28 pruebas cumplen (A: 22 de 22, B: 5 de 6)
  NO CUMPLE B06: 29 de 30 dentro; error medio 1.6 lpm; fuera: cama 13 t=900: 87.7 vs 95.5
```

Cómo leerlo:

- **29 de 30 comparaciones** quedan dentro de ±5 lpm, con error medio de **1,6 lpm**.
- La única fuera de tolerancia es la **cama 13 a t = 900 s**: ECG 87,7 lpm contra monitor 95,5 lpm (diferencia de 7,8).
- En esa ventana los 30 intervalos RR varían entre 480 y 912 ms (coeficiente de variación 0,09), mientras que a t = 1800 s son regulares (0,04) y la diferencia es de 1,7 lpm. Es decir, en esa ventana el ritmo es irregular y la mediana de los RR se aparta de lo que informa el monitor. No se confirmó la causa clínica (ectopia o ruido de señal), así que conviene presentarlo como una limitación conocida y no como un error de la plataforma.
- Con `tramos_base` ausente, B06 dice «0 comparaciones» y figura como cumplida sin haber comparado nada. Verificá siempre que diga **30 comparaciones**.

El script deja `resultados_verificacion_Plataforma_PRESENTACION_4-11.csv` y `alarmas_datos_reales_Plataforma_PRESENTACION_4-11.csv` dentro de esta misma carpeta.

## 5. Validar el motor de reglas contra la base (opcional)

```
python validar_plataforma.py
```

Resultado esperado: **43 VP, 0 FN, 0 FP** (sensibilidad 100 %, VPP 100 %, 0 falsas alarmas por cama-hora). Tarda aproximadamente 1 minuto.

## 6. Si algo falla

| Síntoma | Qué mirar |
|---|---|
| `No existe la base` | `benchmark_uti.db` debe estar en `SCRIPTS\` |
| La pantalla no se actualiza sola | Streamlit 1.37 o posterior (`pip install -U streamlit`) |
| B06 con 0 comparaciones | Falta `SCRIPTS\tramos_base` |
| Otro Streamlit usa el puerto | `--server.port 8502` |
