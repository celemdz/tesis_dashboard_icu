# Central UTI – Entrega del 4 de noviembre de 2026 · versión de presentación

Plataforma virtual de monitoreo de UTI (Python / Streamlit) conectada a la base de benchmark de 15 camas (MIMIC-III).
Es la versión que se presenta hoy: un emisor virtual por cama, con la interfaz corregida.

## Qué trae este paquete

| Carpeta o archivo | Qué es |
|---|---|
| `INSTRUCTIVO_version_presentacion.md` | Paso a paso para abrir la interfaz y para correr las verificaciones. **Empezar por acá.** |
| `PROYECTO INTEGRADOR\SCRIPTS\Plataforma_PRESENTACION_4-11\` | El código de la plataforma (31 archivos) con su `LEEME.txt` y `MANIFIESTO_CORREGIDA.txt`. |
| `PROYECTO INTEGRADOR\SCRIPTS\benchmark_uti.db` | Base de benchmark de las 15 camas. Se abre solo en lectura. |
| `PROYECTO INTEGRADOR\SCRIPTS\tramos_base\` | Los 15 tramos de señal (ECG, presión arterial y pletismografía a 125 Hz): 30 archivos. |
| `PROYECTO INTEGRADOR\SCRIPTS\*.csv` | Datos auxiliares que usa el código (tramos, anomalías, alineación temporal, mediciones y laboratorios). |

## En tres líneas

1. Descomprimir **sin cambiar el nombre** de la carpeta `PROYECTO INTEGRADOR` (el programa la busca por nombre).
2. En Anaconda Prompt: `cd "<donde descomprimiste>\PROYECTO INTEGRADOR\SCRIPTS\Plataforma_PRESENTACION_4-11"` y luego `python verificar_plataforma.py`.
3. Para abrir la interfaz: `streamlit run Interfaz_uti_db.py` (clave de acceso: 123).

## Qué incluye esta versión

- Interfaz con tres vistas (visión general, análisis de una cama, tablero de gravedad), indicadores NEWS2, qSOFA, SOFA, APACHE II y shock/oxigenación, alarmas, gestión de camas e indicadores de gestión.
- Hora simulada igual a la hora de la computadora.
- Tipo de ingreso en castellano (Urgencia / Programado).
- Validación del motor de reglas y de la cadena emisores → canal → receptor.

## Qué NO incluye

La versión nueva con emisores por dispositivo (monitor, enfermería, laboratorio y respirador) está en desarrollo y no forma parte de este paquete.
