# ============================================================
# senales.py - Lectura de los tramos de señal (WFDB, 125 Hz) y detección de latidos
#
# Lee directamente el .hea/.dat (formato 16 bits, un solo archivo) con numpy, sin
# depender de wfdb; si un tramo tuviera otro formato usa wfdb como respaldo.
# Valor físico = (digital - baseline) / ganancia.  Muestra inválida (-32768) -> NaN.
# ============================================================

import re
from pathlib import Path

import numpy as np

_INVALIDO = -32768


class Tramo:
    def __init__(self, ruta_sin_extension):
        self.base = Path(ruta_sin_extension)
        self._leer_encabezado()
        self._datos = None

    # --- encabezado -----------------------------------------
    def _leer_encabezado(self):
        hea = self.base.with_suffix(".hea")
        if not hea.exists():
            raise FileNotFoundError(f"Falta {hea}")
        lineas = [l.strip() for l in hea.read_text(encoding="utf-8", errors="replace").splitlines()
                  if l.strip() and not l.startswith("#")]
        cab = lineas[0].split()
        self.n_canales, self.fs, self.n_muestras = int(cab[1]), float(cab[2]), int(cab[3])
        self.canales, self.ganancia, self.baseline, self.unidades, self.archivos, self.formatos = [], [], [], [], [], []
        for l in lineas[1:1 + self.n_canales]:
            p = l.split()
            self.archivos.append(p[0])
            self.formatos.append(p[1])
            m = re.match(r"^([-+0-9.eE]+)(?:\(([-+0-9.eE]+)\))?(?:/(.*))?$", p[2])
            ganancia = float(m.group(1)) or 200.0
            adc_zero = float(p[4]) if len(p) > 4 else 0.0
            self.ganancia.append(ganancia)
            self.baseline.append(float(m.group(2)) if m.group(2) is not None else adc_zero)
            self.unidades.append(m.group(3) or "")
            self.canales.append(p[-1] if len(p) > 8 else f"canal{len(self.canales)}")
        self.canales_mayus = [c.upper() for c in self.canales]

    # --- datos ----------------------------------------------
    def _cargar(self):
        if self._datos is not None:
            return
        simple = (len(set(self.archivos)) == 1 and all(f.split(":")[0].split("x")[0].split("+")[0] == "16"
                                                       for f in self.formatos))
        if simple:
            dat = self.base.with_name(self.archivos[0])
            crudo = np.fromfile(dat, dtype="<i2")
            if crudo.size >= self.n_muestras * self.n_canales:
                self._datos = crudo[: self.n_muestras * self.n_canales].reshape(self.n_muestras, self.n_canales)
                return
        try:  # respaldo para otros formatos
            import wfdb
            reg = wfdb.rdrecord(str(self.base), physical=False)
            self._datos = reg.d_signal.astype("<i2")
        except Exception as error:
            raise RuntimeError(f"No se pudo leer {self.base}: {error}")

    def ventana(self, t_ini_s, t_fin_s, canales=None):
        """Devuelve {canal: (t_s, valores_fisicos)} para [t_ini_s, t_fin_s] (en segundos desde el inicio del tramo)."""
        self._cargar()
        a = max(0, int(np.floor(t_ini_s * self.fs)))
        b = min(self.n_muestras, int(np.ceil(t_fin_s * self.fs)))
        t = np.arange(a, b) / self.fs
        salida = {}
        for j, nombre in enumerate(self.canales):
            if canales and nombre.upper() not in [c.upper() for c in canales]:
                continue
            crudo = self._datos[a:b, j].astype(float)
            fis = (crudo - self.baseline[j]) / self.ganancia[j]
            fis[self._datos[a:b, j] == _INVALIDO] = np.nan
            salida[nombre] = (t, fis)
        return salida

    def canal_completo(self, nombre):
        v = self.ventana(0, self.n_muestras / self.fs, [nombre])
        return v.get(next((c for c in v if c.upper() == nombre.upper()), nombre), (None, None))


# ------------------------------------------------------------
# Detección de latidos (R) e intervalos RR
# ------------------------------------------------------------
def detectar_picos_r(ecg, fs):
    """Devuelve los tiempos (s) de los picos R. Pan-Tompkins simplificado."""
    from scipy.signal import butter, sosfiltfilt, find_peaks
    x = np.asarray(ecg, float)
    if np.isnan(x).all():
        return np.array([])
    x = np.where(np.isnan(x), np.nanmedian(x), x)
    x = x - np.median(x)
    sos = butter(2, [5, 20], btype="band", fs=fs, output="sos")
    y = sosfiltfilt(sos, x)
    energia = np.diff(y, prepend=y[0]) ** 2
    w = max(1, int(0.12 * fs))
    energia = np.convolve(energia, np.ones(w) / w, mode="same")
    umbral = 0.25 * np.percentile(energia, 99)
    picos, _ = find_peaks(energia, height=umbral, distance=int(0.25 * fs))
    # refinar al máximo local de |señal filtrada| (±60 ms)
    r = int(0.06 * fs)
    refinados = []
    for p in picos:
        a, b = max(0, p - r), min(len(y), p + r + 1)
        refinados.append(a + int(np.argmax(np.abs(y[a:b]))))
    return np.unique(refinados) / fs


def intervalos_rr_ms(tiempos_r, minimo=300, maximo=2000):
    rr = np.diff(tiempos_r) * 1000.0
    t_fin = tiempos_r[1:]
    ok = (rr >= minimo) & (rr <= maximo)
    return t_fin[ok], rr[ok]


class RitmoCache:
    """Detecta los latidos de un tramo una sola vez y responde 'hasta el segundo t'."""

    def __init__(self):
        self._tramos, self._picos = {}, {}

    def tramo(self, estadia_id, ruta):
        if estadia_id not in self._tramos:
            self._tramos[estadia_id] = Tramo(ruta)
        return self._tramos[estadia_id]

    def picos_r(self, estadia_id, ruta):
        if estadia_id not in self._picos:
            tr = self.tramo(estadia_id, ruta)
            nombre = next((c for c in tr.canales if c.upper() in ("II", "ECG", "I", "V")), None)
            if nombre is None:
                self._picos[estadia_id] = np.array([])
            else:
                _, ecg = tr.canal_completo(nombre)
                self._picos[estadia_id] = detectar_picos_r(ecg, tr.fs)
        return self._picos[estadia_id]

    def rr_hasta(self, estadia_id, ruta, t_s, ultimos=150):
        """RR (ms) de los latidos ocurridos hasta t_s (máximo `ultimos`)."""
        picos = self.picos_r(estadia_id, ruta)
        picos = picos[picos <= t_s]
        if len(picos) < 3:
            return np.array([])
        _, rr = intervalos_rr_ms(picos)
        return rr[-ultimos:]
