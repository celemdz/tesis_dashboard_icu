# ============================================================
# reglas_basicas.py - Motor de supervisión  [versión unificada, reglas v2 del 22/10/2026]
#
# Toma una instantánea (datos_db.BaseUTI.snapshot) y devuelve la lista de alarmas activas.
#       evaluar(snap, umbrales, base) -> [ {regla, nivel, mensaje, valores, tipo, prioridad, clave, escenario} ]
# Los valores no vigentes o fuera de rango NO se usan en las reglas clínicas.
#
# Reglas v2 (documento «Reglas de validación: propuesta de decisiones», D1 a D7):
#   - Los umbrales salen de umbrales_validacion.csv: la MISMA especificación que usa el Paso10 para
#     armar la verdad de referencia. El código que la aplica es independiente del Paso10.
#     El argumento `umbrales` se mantiene por compatibilidad con la interfaz, pero ya no se usa.
#   - D1: tipo (fisiológica / técnica) y prioridad (alta / media / baja) separados. REQUIERE REVISION
#     es solo para fallas técnicas; el desvío leve no alarma.
#   - D2: cada falla técnica lleva prioridad según el escenario del catálogo (parametros_validacion.csv).
#   - D3: una alarma fisiológica desde numéricos exige 2 muestras válidas seguidas (actual y anterior).
#     Una medición manual (PA no invasiva) alcanza por sí sola (D6).
#   - D4: FC aislada, hipertensión, SpO2 < 90 / < 85, PAM < 65 / < 55, FR, y combinadas SHOCK y RESP.
#   - D5: FR = 0 con SpO2 >= 94 % = pérdida de señal respiratoria (técnica, prioridad baja).
#   - Nueva falla técnica: PVC congelada en 0 (A11).
#   - Nueva falla técnica: cama sin comunicación (A14, prioridad alta): FC, SpO2 y FR sin datos nuevos
#     hace más de sin_comunicacion_s (120 s) a la vez.
#
# Cambios anteriores de la versión unificada (respecto de la versión de Maxi):
#   1. Se distingue SENSOR DESCONECTADO (valor exactamente 0 en un parámetro con sensor) de FUERA DE RANGO.
#   2. Se controlan también PAD y PAM.
#   3. estado_valores(): la interfaz la usa para no mostrar nunca un valor inválido como número normal.
#   Los rangos fisiológicos se toman de la tabla `variables` de la base (fuente única).
# ============================================================
import operator
from pathlib import Path

import pandas as pd

NIVELES = ["ESTABLE", "REQUIERE REVISION", "ADVERTENCIA", "CRITICA"]   # de menor a mayor prioridad
ORDEN_PRIORIDAD = {"alta": 0, "media": 1, "baja": 2}

# etiqueta -> (clave en snap, variable del diccionario de rangos, clave en snap["datos"], tiene sensor)
# "tiene sensor": un 0 exacto se interpreta como sensor desconectado / sin señal.
# FR queda afuera: un 0 en FR puede ser una apnea real (se decide con la SpO2, D5).
VARIABLES_CONTROLADAS = {
    "FC":   ("fc",   "fc",           "fc",   True),
    "SPO2": ("spo2", "spo2",         "spo2", True),
    "FR":   ("fr",   "fr",           "fr",   False),
    "PAS":  ("pas",  "pa_inv_sis",   "pa",   True),
    "PAD":  ("pad",  "pa_inv_dia",   "pa",   True),
    "PAM":  ("pam",  "pa_inv_media", "pa",   True),
}
PRESIONES = ("pas", "pad", "pam")

# Estados posibles de cada valor (los usa la interfaz)
VALIDO, FALTANTE, DESCONECTADO, NO_FISIOLOGICO, VIEJO = "VALIDO", "FALTANTE", "DESCONECTADO", "NO_FISIOLOGICO", "VIEJO"

# Falla técnica -> (escenario del catálogo, clave de emparejamiento)
ESCENARIO_DESCONEXION = {"FC": "A01", "SPO2": "A02", "PAS": "A04", "PAD": "A04", "PAM": "A04"}
CLAVE_TECNICA = {"FC": "tec_fc", "SPO2": "tec_spo2", "FR": "tec_fr", "PAS": "tec_pa", "PAD": "tec_pa", "PAM": "tec_pa"}
NOMBRE_COMBINADA = {"SHOCK": "SHOCK_HEMODINAMICO", "RESP": "FALLA_RESPIRATORIA"}
CLAVE_REGLA = {"FC": "fc", "SPO2": "spo2", "FR": "fr", "PAM": "pam", "PAS": "pas", "SHOCK": "shock", "RESP": "resp"}
ETIQUETA_VALOR = {"fc": "FC", "spo2": "SpO2", "fr": "FR", "pam": "PAM", "pas": "PAS"}

_OPS = {"<": operator.lt, "<=": operator.le, ">": operator.gt, ">=": operator.ge}
_ESPEC = {}


# ------------------------------------------------------------
# Especificación (umbrales_validacion.csv y parametros_validacion.csv)
# ------------------------------------------------------------
def _buscar(nombre, base):
    aqui = Path(__file__).resolve().parent
    carpetas = [Path(base.ruta).resolve().parent] if base is not None and hasattr(base, "ruta") else []
    carpetas += [aqui, aqui.parent, aqui.parent.parent]
    for c in carpetas:
        if (c / nombre).exists():
            return c / nombre
    raise FileNotFoundError(f"No encuentro {nombre}: dejalo junto a benchmark_uti.db.")


def especificacion(base=None):
    if not _ESPEC:
        umb = pd.read_csv(_buscar("umbrales_validacion.csv", base), encoding="utf-8-sig")
        par = pd.read_csv(_buscar("parametros_validacion.csv", base), encoding="utf-8-sig")
        par = par.set_index("clave")["valor"].to_dict()
        _ESPEC["umbrales"] = umb
        _ESPEC["fr0_spo2_min"] = float(par["fr0_spo2_min"])
        _ESPEC["pvc_muestras"] = int(par["pvc_congelada_muestras"])
        _ESPEC["salto_max_s"] = float(par["salto_max_s"])
        _ESPEC["sin_comunicacion_s"] = float(par.get("sin_comunicacion_s", 120))
        _ESPEC["prioridad_tecnica"] = {k.replace("prioridad_tecnica_", ""): v for k, v in par.items()
                                       if k.startswith("prioridad_tecnica_")}
    return _ESPEC


def _minutos(segundos):
    return int(round(segundos / 60.0))


# ------------------------------------------------------------
# Calidad de dato
# ------------------------------------------------------------
def _fr_sin_senal(snap, base):
    """D5: FR = 0 con SpO2 válida >= 94 % en el mismo minuto = pérdida de la señal respiratoria."""
    fr, spo2 = snap.get("fr"), snap.get("spo2")
    if fr != 0 or spo2 is None or spo2 == 0 or base.fuera_de_rango("spo2", spo2):
        return False
    return spo2 >= especificacion(base)["fr0_spo2_min"]


def _clasificar(snap, base):
    """Devuelve {etiqueta: (clave, estado, valor, dato)} para cada variable controlada."""
    datos = snap["datos"]
    salida = {}
    for etiqueta, (clave, var_rango, clave_dato, con_sensor) in VARIABLES_CONTROLADAS.items():
        valor = snap.get(clave)
        dato = datos.get(clave_dato)
        if valor is None:
            estado = FALTANTE
        elif con_sensor and valor == 0:
            estado = DESCONECTADO
        elif etiqueta == "FR" and _fr_sin_senal(snap, base):
            estado = DESCONECTADO
        elif base.fuera_de_rango(var_rango, valor):
            estado = NO_FISIOLOGICO
        elif dato is not None and not dato.vigente:
            estado = VIEJO
        else:
            estado = VALIDO
        salida[etiqueta] = (clave, estado, valor, dato)
    return salida


def estado_valores(snap, base):
    """{clave: estado} para la interfaz: 'fc', 'spo2', 'fr', 'pas', 'pad', 'pam'."""
    return {clave: estado for clave, estado, _, _ in _clasificar(snap, base).values()}


def _tecnica(regla, mensaje, valores, escenario, clave, base):
    return {"regla": regla, "nivel": "REQUIERE REVISION", "mensaje": f"[REVISAR] {mensaje}", "valores": valores,
            "tipo": "tecnica", "prioridad": especificacion(base)["prioridad_tecnica"].get(escenario, "baja"),
            "clave": clave, "escenario": escenario}


def _pvc_congelada(snap, base):
    """A11: las últimas N muestras de PVC del monitor, seguidas, exactamente en 0."""
    eid, t = snap.get("estadia_id"), snap.get("t_s")
    if eid is None or t is None or not hasattr(base, "serie"):
        return False
    n = especificacion(base)["pvc_muestras"]
    s = base.serie(eid, "pvc", t - 3600, t, fuente="numericos")
    if len(s) < n:
        return False
    ult = s.tail(n)
    seguidas = (ult["t_s"].diff().dropna() <= especificacion(base)["salto_max_s"]).all()
    return bool(seguidas and (ult["valor"] == 0).all() and t - ult["t_s"].iloc[-1] <= 300)


# ------------------------------------------------------------
# Reglas fisiológicas
# ------------------------------------------------------------
def _valor_valido(clave, x, base):
    """Para la muestra anterior: misma validación que la actual (no 0 en un sensor, dentro de rango)."""
    if x is None:
        return False
    var_rango = {k[0]: k[1] for k in VARIABLES_CONTROLADAS.values()}[clave]
    if clave != "fr" and x == 0:
        return False
    return not base.fuera_de_rango(var_rango, x)


def _cumple_persistente(snap, validos, clave, test, base):
    """D3: la condición se cumple en la muestra actual y, si viene del monitor, también en la anterior."""
    x = validos.get(clave)
    if x is None or not test(x):
        return False
    if (snap.get("fuentes") or {}).get(clave, "numericos") != "numericos":
        return True                                     # medición manual: alcanza una (D6)
    previos = snap.get("previos")
    if previos is None:                                 # instantánea sin historia (pruebas armadas)
        return True
    p = previos.get(clave)
    return _valor_valido(clave, p, base) and test(p)


def _evaluar_fisiologicas(snap, validos, base):
    umb = especificacion(base)["umbrales"]
    alarmas = []
    for regla, filas in umb.groupby("regla", sort=False):
        variables = list(dict.fromkeys(filas["variable"]))
        if len(variables) == 1:                         # regla de una variable: OR entre filas, gana el peor nivel
            clave = variables[0]
            elegida = None
            for _, f in filas.iterrows():
                test = (lambda op, u: (lambda x: op(x, u)))(_OPS[f.condicion], f.umbral)
                if _cumple_persistente(snap, validos, clave, test, base):
                    if elegida is None or NIVELES.index(f.nivel) > NIVELES.index(elegida.nivel):
                        elegida = f
            if elegida is None:
                continue
            x = validos[clave]
            nivel, mensaje = elegida.nivel, elegida.mensaje
            valores = {clave: x}
            texto = f"{mensaje} ({ETIQUETA_VALOR[clave]} {x:.0f})"
        else:                                           # regla combinada: AND entre variables
            if not all(_cumple_persistente(snap, validos, f.variable,
                                           (lambda op, u: (lambda x: op(x, u)))(_OPS[f.condicion], f.umbral), base)
                       for _, f in filas.iterrows()):
                continue
            nivel, mensaje = filas.iloc[0].nivel, filas.iloc[0].mensaje
            valores = {v: validos[v] for v in variables}
            texto = mensaje
        nombre = NOMBRE_COMBINADA.get(regla, mensaje.replace(" / ", "_").replace(" ", "_"))
        prefijo = "[CRITICO]" if nivel == "CRITICA" else "[ALERTA]"
        alarmas.append({"regla": nombre, "nivel": nivel, "mensaje": f"{prefijo} {texto}", "valores": valores,
                        "tipo": "fisiologica", "prioridad": "alta" if nivel == "CRITICA" else "media",
                        "clave": CLAVE_REGLA[regla], "escenario": regla})
    return alarmas


# ------------------------------------------------------------
# Evaluación completa
# ------------------------------------------------------------
def evaluar(snap, umbrales, base):
    """`umbrales` se mantiene por compatibilidad: los umbrales salen de umbrales_validacion.csv."""
    alarmas = []
    validos = {}                   # valores utilizables por las reglas clínicas

    # --- 1) Calidad de dato (alarmas técnicas) -------------------------------------------
    for etiqueta, (clave, estado, valor, dato) in _clasificar(snap, base).items():
        if estado == FALTANTE:
            if etiqueta in ("FC", "SPO2"):
                alarmas.append(_tecnica(f"SIN_SENAL_{etiqueta}", f"SIN DATO DE {etiqueta}", {}, "A03",
                                        CLAVE_TECNICA[etiqueta], base))
            continue
        if estado == DESCONECTADO:
            if etiqueta == "FR":
                alarmas.append(_tecnica("SENAL_RESPIRATORIA_PERDIDA",
                                        "FR = 0 CON SpO2 NORMAL: POSIBLE PERDIDA DE SEÑAL RESPIRATORIA",
                                        {"fr": valor, "spo2": snap.get("spo2")}, "C06", "tec_fr", base))
            else:
                alarmas.append(_tecnica(f"SENSOR_DESCONECTADO_{etiqueta}", f"{etiqueta}: SENSOR DESCONECTADO O SIN SEÑAL",
                                        {etiqueta.lower(): valor}, ESCENARIO_DESCONEXION[etiqueta],
                                        CLAVE_TECNICA[etiqueta], base))
            continue
        if estado == NO_FISIOLOGICO:
            alarmas.append(_tecnica(f"FUERA_DE_RANGO_{etiqueta}", f"{etiqueta} FUERA DE RANGO FISIOLOGICO ({valor:.0f})",
                                    {etiqueta.lower(): valor}, "A09", CLAVE_TECNICA[etiqueta], base))
            continue
        if estado == VIEJO:
            # PA vieja: no se usa para reglas, pero tampoco es falla técnica
            if clave not in PRESIONES:
                alarmas.append(_tecnica(f"DATO_VIEJO_{etiqueta}",
                                        f"{etiqueta} SIN ACTUALIZAR HACE {_minutos(dato.antiguedad_s)} MIN",
                                        {"antiguedad_s": dato.antiguedad_s}, "A03", CLAVE_TECNICA[etiqueta], base))
            continue
        validos[clave] = valor

    # A14: la cama dejó de comunicar (los tres canales del monitor sin datos nuevos a la vez)
    canales = [snap["datos"].get(k) for k in ("fc", "spo2", "fr")]
    limite = especificacion(base)["sin_comunicacion_s"]
    if all(c is not None for c in canales) and all(c.antiguedad_s > limite for c in canales):
        minimo = min(c.antiguedad_s for c in canales)
        alarmas.append(_tecnica("CAMA_SIN_COMUNICACION", f"CAMA SIN COMUNICACION: SIN DATOS DEL MONITOR HACE {_minutos(minimo)} MIN",
                                {"antiguedad_s": minimo}, "A14", "tec_cama", base))

    if _pvc_congelada(snap, base):
        alarmas.append(_tecnica("PVC_CONGELADA", "PVC CONGELADA EN 0 (TRANSDUCTOR SIN CONECTAR O EN CERO)",
                                {"pvc": 0}, "A11", "tec_pvc", base))

    # --- 2) Reglas clínicas (solo con valores válidos) --------------------------------------
    alarmas += _evaluar_fisiologicas(snap, validos, base)
    return alarmas


def es_tecnica(alarma):
    """Las alarmas técnicas (calidad de dato) son las de nivel REQUIERE REVISION."""
    return alarma.get("tipo") == "tecnica" or alarma["nivel"] == "REQUIERE REVISION"


def estado_cama(alarmas):
    nivel = max((NIVELES.index(a["nivel"]) for a in alarmas), default=0)
    return NIVELES[nivel]


def alarma_principal(alarmas):
    return max(alarmas, key=lambda a: NIVELES.index(a["nivel"])) if alarmas else None


def principal_clinica(alarmas):
    clinicas = [a for a in alarmas if not es_tecnica(a)]
    return alarma_principal(clinicas)


def tecnicas(alarmas):
    """Fallas técnicas ordenadas por prioridad (D2): alta, media, baja."""
    return sorted((a for a in alarmas if es_tecnica(a)),
                  key=lambda a: ORDEN_PRIORIDAD.get(a.get("prioridad"), 3))
