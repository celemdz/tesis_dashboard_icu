# -*- coding: utf-8 -*-
"""
emisor.py — Emisores virtuales de datos de cama (monitor multiparamétrico + datos clínicos).

Un emisor publica PAQUETES por cama; no sabe nada de la central. Formato del paquete (diccionario):
    {"cama": int, "seq": int, "t_emision": float, "origen": "historia" | "replay" | "sintetico",
     "medidas": [(variable, t_medicion, valor, texto, fuente), ...]}
Un paquete sin medidas es un "latido" (la cama sigue comunicando aunque no haya datos nuevos).

Dos tipos de emisor, misma salida:
  EmisorReplay     reproduce una cama de la base benchmark_uti.db (solo lectura, vistas v_*): es el banco "realista".
  EmisorSintetico  genera una cama por escenario con semilla; la respuesta correcta se conoce por construcción
                   (ground truth = cruce de umbrales de la señal limpia, calculado con definiciones del protocolo).

Escenarios sintéticos del mínimo viable: ESTABLE (control), DETERIORO_HEMODINAMICO, DESATURACION.
Nada de esto escribe en la base.
"""
from dataclasses import dataclass, field

import numpy as np

# ----------------------------------------------------------------------------------------------
# Definiciones del PROTOCOLO.
# [integración 22/10/2026] Salen de umbrales_validacion.csv: la MISMA especificación que aplican el motor
# (reglas_basicas.py) y la verdad de referencia del benchmark (Paso10). Lo independiente es el código: acá cada
# condición se evalúa sobre la señal LIMPIA (sin ruido, sin redondeo, sin canal), con una implementación propia.
# Antes eran los umbrales de la «Lista de indicadores» (SHOCK FC > 100 y PAS < 90, hipoxemia < 92), que no
# coincidían con las reglas: la sensibilidad medía la diferencia entre dos especificaciones, no al motor.
# Cada evento se llama igual que la regla del motor que lo alarma (ver EQUIV en validar_con_emisores.py).
# ----------------------------------------------------------------------------------------------
import operator as _op
from pathlib import Path as _Path

_OPS = {"<": _op.lt, "<=": _op.le, ">": _op.gt, ">=": _op.ge}
_COMBINADAS = {"SHOCK": "SHOCK_HEMODINAMICO", "RESP": "FALLA_RESPIRATORIA"}


def _buscar_spec(nombre="umbrales_validacion.csv"):
    aqui = _Path(__file__).resolve().parent
    for c in (aqui, aqui.parent, aqui.parent.parent):
        if (c / nombre).exists():
            return c / nombre
    raise FileNotFoundError(f"No encuentro {nombre}: dejalo junto a benchmark_uti.db.")


def _cargar_condiciones():
    import csv
    filas = list(csv.DictReader(open(_buscar_spec(), encoding="utf-8-sig")))
    cond, nivel = {}, {}
    por_regla = {}
    for f in filas:
        por_regla.setdefault(f["regla"], []).append(f)
    for regla, fs in por_regla.items():
        variables = {f["variable"] for f in fs}
        if len(variables) == 1:                       # una variable: un evento por fila (p. ej. bradi y taqui extremas)
            for f in fs:
                nombre = f["mensaje"].replace(" / ", "_").replace(" ", "_")
                op, u, v = _OPS[f["condicion"]], float(f["umbral"]), f["variable"]
                cond[nombre] = (lambda op, u, v: (lambda s: op(s[v], u)))(op, u, v)
                nivel[nombre] = (f["nivel"], v)
        else:                                         # combinada: todas las filas a la vez
            reglas_f = [(_OPS[f["condicion"]], float(f["umbral"]), f["variable"]) for f in fs]
            nombre = _COMBINADAS.get(regla, regla)
            cond[nombre] = (lambda rf: (lambda s: all(op(s[v], u) for op, u, v in rf)))(reglas_f)
            nivel[nombre] = (fs[0]["nivel"], regla.lower())
    return cond, nivel


CONDICIONES_PROTOCOLO, NIVEL_EVENTO = _cargar_condiciones()


def _pam(pas, pad):
    return pad + (pas - pad) / 3.0


def _rampa(t, t0, dur, a, b):
    f = min(max((t - t0) / dur, 0.0), 1.0)
    return a + (b - a) * f


# ----------------------------------------------------------------------------------------------
# Escenarios: cada uno devuelve, para una semilla, una función limpia(t) -> dict(fc, spo2, fr, pas, pad)
# ----------------------------------------------------------------------------------------------
def _base_estable(rng):
    return {"fc": rng.normal(78, 4), "spo2": rng.normal(97, 0.8), "fr": rng.normal(16, 1.5),
            "pas": rng.normal(122, 6), "pad": rng.normal(72, 4)}


def esc_estable(rng):
    b = _base_estable(rng)
    return (lambda t: dict(b)), {"inicio_s": None}


def esc_deterioro(rng):
    b = _base_estable(rng)
    t0, dur = float(rng.uniform(200, 500)), float(rng.uniform(600, 1000))
    fc_f, pas_f, pad_f = rng.uniform(132, 145), rng.uniform(72, 82), rng.uniform(42, 50)

    def limpia(t):
        return {"fc": _rampa(t, t0, dur, b["fc"], fc_f), "spo2": _rampa(t, t0, dur, b["spo2"], b["spo2"] - 2),
                "fr": _rampa(t, t0, dur, b["fr"], b["fr"] + 8), "pas": _rampa(t, t0, dur, b["pas"], pas_f),
                "pad": _rampa(t, t0, dur, b["pad"], pad_f)}
    return limpia, {"inicio_s": t0, "duracion_s": dur}


def esc_desaturacion(rng):
    b = _base_estable(rng)
    t0, dur = float(rng.uniform(200, 500)), float(rng.uniform(500, 800))
    spo2_f, fr_f = rng.uniform(78, 84), rng.uniform(30, 36)

    def limpia(t):
        return {"fc": _rampa(t, t0, dur, b["fc"], b["fc"] + 28), "spo2": _rampa(t, t0, dur, b["spo2"], spo2_f),
                "fr": _rampa(t, t0, dur, b["fr"], fr_f), "pas": b["pas"], "pad": b["pad"]}
    return limpia, {"inicio_s": t0, "duracion_s": dur}


ESCENARIOS = {
    "ESTABLE": esc_estable,
    "DETERIORO_HEMODINAMICO": esc_deterioro,
    "DESATURACION": esc_desaturacion,
}


def _paquete(cama, seq, t, medidas, origen):
    return {"cama": int(cama), "seq": int(seq), "t_emision": float(t), "origen": origen, "medidas": medidas}


# ----------------------------------------------------------------------------------------------
# Emisor de reproducción (lee la base en solo lectura)
# ----------------------------------------------------------------------------------------------
class EmisorReplay:
    origen = "replay"

    def __init__(self, base, cama, dt_s=60.0):
        self.base, self.cama, self.dt = base, int(cama), float(dt_s)
        self.estadia = base.estadia_de_cama(self.cama)
        if self.estadia is None:
            raise ValueError(f"La cama {cama} no tiene estadía en la base")
        self.seq = 0

    def datos_paciente(self):
        f = self.base.ficha(self.estadia)
        e = self.base.estadias.loc[self.estadia]
        return {"estadia_id": self.estadia, "subject_id": f["subject_id"], "unidad": f["unidad"],
                "tipo_internacion": f["tipo_internacion"], "sexo": f["sexo"],
                "edad": None if f["edad"] == "" else (89 if f["edad"] == "89+" else f["edad"]),
                "edad_anonimizada": int(e.get("edad_anonimizada") == 1), "t_ingreso_s": f["t_ingreso_s"]}

    def historia(self, t_ini=0.0):
        """Todo lo medido hasta t_ini - dt (historia previa y laboratorio)."""
        med = self.base.medidas(self.estadia, -1e12, t_ini - self.dt)
        return _paquete(self.cama, 0, t_ini - self.dt, med, "historia")

    def paquete(self, t):
        self.seq += 1
        return _paquete(self.cama, self.seq, t, self.base.medidas(self.estadia, t - self.dt, t), "replay")


# ----------------------------------------------------------------------------------------------
# Emisor sintético
# ----------------------------------------------------------------------------------------------
class EmisorSintetico:
    origen = "sintetico"

    def __init__(self, cama, escenario, semilla, dt_s=60.0, t_ini=0.0, t_fin=1800.0, historia_s=7200.0):
        self.cama, self.escenario, self.semilla, self.dt = int(cama), escenario, int(semilla), float(dt_s)
        self.t_ini, self.t_fin = float(t_ini), float(t_fin)
        self.estadia = 900000 + self.cama
        self.seq = 0
        rng = np.random.default_rng([self.semilla, self.cama, sum(map(ord, escenario))])
        self.limpia, self.meta = ESCENARIOS[escenario](rng)
        self.meta = dict(self.meta, escenario=escenario, semilla=self.semilla, cama=self.cama)
        self.edad = int(rng.integers(55, 86))
        self.sexo = "M" if rng.random() < 0.5 else "F"

        self.grilla = np.arange(t_ini - historia_s, t_fin + 1e-9, self.dt)
        sd = {"fc": 1.5, "spo2": 0.4, "fr": 0.8, "pas": 2.5, "pad": 1.8}
        phi = 0.6
        ruido = {k: np.zeros(len(self.grilla)) for k in sd}
        for k, s in sd.items():
            e = rng.normal(0, s * np.sqrt(1 - phi ** 2), len(self.grilla))
            for i in range(1, len(self.grilla)):
                ruido[k][i] = phi * ruido[k][i - 1] + e[i]
        self.limpias = [self.limpia(t) for t in self.grilla]
        self.obs = {}
        for i, t in enumerate(self.grilla):
            c = self.limpias[i]
            pas = round(c["pas"] + ruido["pas"][i])
            pad = round(c["pad"] + ruido["pad"][i])
            self.obs[float(t)] = {
                "fc": float(round(c["fc"] + ruido["fc"][i])),
                "spo2": float(min(100, round(c["spo2"] + ruido["spo2"][i]))),
                "fr": float(max(0, round(c["fr"] + ruido["fr"][i]))),
                "pa_inv_sis": float(pas), "pa_inv_dia": float(pad), "pa_inv_media": float(round(_pam(pas, pad)))}

    def datos_paciente(self):
        return {"estadia_id": self.estadia, "subject_id": self.estadia, "unidad": "SINT", "tipo_internacion": "EMERGENCY",
                "sexo": self.sexo, "edad": self.edad, "edad_anonimizada": 0, "t_ingreso_s": self.t_ini - 7200.0}

    def _medidas(self, t):
        o = self.obs.get(float(t))
        return [] if o is None else [(v, float(t), x, None, "numericos") for v, x in o.items()]

    def historia(self, t_ini=None):
        t_ini = self.t_ini if t_ini is None else t_ini
        med = []
        for t in self.grilla[self.grilla <= t_ini - self.dt + 1e-9]:
            med += self._medidas(t)
        # datos clínicos "manuales" y laboratorio normales (para que los indicadores puedan calcularse)
        med += [("temperatura", t_ini - 3600.0, 36.8, None, "chartevents"),
                ("gcs_total", t_ini - 3600.0, 15.0, None, "calculado"),
                ("fio2", t_ini - 3600.0, 21.0, None, "chartevents"),
                ("dispositivo_o2", t_ini - 3600.0, None, "Room air", "chartevents"),
                ("creatinina", t_ini - 7200.0, 0.9, None, "labevents"),
                ("plaquetas", t_ini - 7200.0, 220.0, None, "labevents"),
                ("bilirrubina_total", t_ini - 7200.0, 0.7, None, "labevents"),
                ("pao2", t_ini - 7200.0, 95.0, None, "labevents")]
        return _paquete(self.cama, 0, t_ini - self.dt, med, "historia")

    def paquete(self, t):
        self.seq += 1
        return _paquete(self.cama, self.seq, t, self._medidas(t), "sintetico")

    # -------------------------------------------------------------- ground truth por construcción
    def eventos_esperados(self):
        """Primer instante (>= t_ini) en que la señal LIMPIA cumple cada condición del protocolo."""
        esperados = []
        for nombre, cond in CONDICIONES_PROTOCOLO.items():
            for t, c in zip(self.grilla, self.limpias):
                if t < self.t_ini:
                    continue
                s = dict(c, pam=_pam(c["pas"], c["pad"]))
                if cond(s):
                    esperados.append({"cama": self.cama, "evento": nombre, "t_esperado": float(t),
                                      "escenario": self.escenario, "semilla": self.semilla})
                    break
        return esperados
