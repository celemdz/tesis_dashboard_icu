# ============================================================
# config.py - Rutas y parámetros generales del proyecto
# Funciona en cualquier computadora: busca la carpeta "PROYECTO INTEGRADOR"
# hacia arriba desde este archivo, y todas las rutas salen de ahí.
# Guardar junto a Paso8_crear_base.py y Paso9_cargar_numericos.py
# (en Celeste: SCRIPTS\Funciones).
# Para comprobar que está todo en su lugar ANTES de correr los pasos:
#     python config.py
# ============================================================

import os
from pathlib import Path


def _buscar_raiz():
    """Sube desde este archivo hasta encontrar la carpeta PROYECTO INTEGRADOR."""
    aca = Path(__file__).resolve()
    for carpeta in aca.parents:
        if carpeta.name.upper() == "PROYECTO INTEGRADOR":
            return carpeta
    return aca.parents[2]          # plan B: el diseño original (SCRIPTS\Funciones)


def _primero_que_exista(candidatos):
    for c in candidatos:
        if c.exists():
            return c
    return candidatos[0]           # si no existe ninguno, queda la ruta esperada (se ve en verificar())


# --- Raíz del proyecto (se calcula sola) ---------------------
RAIZ = _buscar_raiz()
BD = RAIZ / "SCRIPTS" / "DataBase"

# --- Rutas externas (se buscan solas; si tus carpetas tienen otro nombre, editá la primera opción) ---
CARPETA_DEMO = _primero_que_exista(
    [BD / "mimic-iii-clinical-database-demo-1.4"] + sorted(BD.glob("mimic-iii-clinical-database-demo*")))
RUTA_RECORDS_NUMERICS = _primero_que_exista(
    [BD / "mimic iii - waveform - database" / "RECORDS-numerics", BD / "RECORDS-numerics"]
    + sorted(BD.glob("*/RECORDS-numerics")))

# --- Carpeta donde están los archivos generados por los pasos anteriores ---
# Se busca (en este orden) en: la raíz del proyecto, SCRIPTS, y la carpeta de este archivo.
# Gana la primera que contenga tramos_seleccionados_v2.csv.
CARPETA_DATOS = _primero_que_exista(
    [c for c in (RAIZ, RAIZ / "SCRIPTS", Path(__file__).resolve().parent)
     if (c / "tramos_seleccionados_v2.csv").exists()] or [RAIZ])

TRAMOS_V2 = CARPETA_DATOS / "tramos_seleccionados_v2.csv"
ANOMALIAS_V2 = CARPETA_DATOS / "anomalias_reales_v2.csv"
ALINEACION = CARPETA_DATOS / "alineacion_temporal.csv"
MEDICIONES_CLINICAS = CARPETA_DATOS / "mediciones_clinicas.csv"
LABORATORIOS = CARPETA_DATOS / "laboratorios_cohorte.csv"
RESUMEN_CLINICO = CARPETA_DATOS / "resumen_clinico_tramo.csv"
# tramos_base: se usa la primera carpeta que tenga los 15 tramos (.hea). Si la moviste a "Versiones viejas",
# se la encuentra ahí; lo ideal es copiarla a SCRIPTS\tramos_base.
CARPETA_TRAMOS = next(
    (c for c in (CARPETA_DATOS / "tramos_base", RAIZ / "tramos_base",
                 RAIZ / "SCRIPTS" / "Versiones viejas" / "tramos_base",
                 RAIZ / "SCRIPTS" / "Versiones viejas" / "Funciones" / "tramos_base")
     if len(list(c.glob("*_tramo.hea"))) >= 15),
    CARPETA_DATOS / "tramos_base")

# --- Base de datos (queda junto a los CSV) -------------------
BASE_ORIGINAL = CARPETA_DATOS / "benchmark_uti.db"
# Para que la plataforma use otra base (p. ej. la copia con inyecciones), definir la variable de entorno UTI_DB:
#     PowerShell:  $env:UTI_DB = "...\SCRIPTS\benchmark_uti_validacion.db"
RUTA_BASE = Path(os.environ["UTI_DB"]) if os.environ.get("UTI_DB") else BASE_ORIGINAL

# --- Reloj común de la simulación ----------------------------
ANCLAJE_MINUTO_0 = "2026-03-15 10:00:00"   # fecha y hora ficticia del minuto 0
DURACION_TRAMO_S = 1800


# ============================================================
# Verificación previa (python config.py)
# ============================================================
# columnas que Paso8 necesita de cada CSV
COLUMNAS_NECESARIAS = {
    TRAMOS_V2: ["subject_id", "tramo_inicio", "canales", "grabacion", "inicio_en_grabacion_s"],
    ALINEACION: ["subject_id", "icustay_id"],
    ANOMALIAS_V2: ["subject_id", "candidato", "canal", "tipo", "detalle", "segundo_en_tramo", "inicio_candidato_s"],
    MEDICIONES_CLINICAS: ["subject_id", "icustay_id", "variable", "charttime", "valor", "valor_texto",
                          "unidad", "origen", "itemid", "plausible"],
    LABORATORIOS: ["subject_id", "hadm_id", "variable", "charttime", "valor", "valueuom", "calidad"],
    RESUMEN_CLINICO: ["subject_id", "edad", "edad_anonimizada", "gender", "first_careunit",
                      "admission_type", "egreso"],
}
TABLAS_DEMO = ["ICUSTAYS.csv", "D_ITEMS.csv", "D_LABITEMS.csv"]


def verificar():
    import csv
    print(f"Raíz del proyecto: {RAIZ}")
    print(f"Carpeta de datos (CSV, tramos_base, base): {CARPETA_DATOS}")
    faltan = 0

    def estado(ok, texto):
        nonlocal faltan
        faltan += (not ok)
        print(f"  [{'OK' if ok else 'FALTA'}] {texto}")

    print("\nCarpetas y archivos externos")
    estado(CARPETA_DEMO.is_dir(), f"Demo MIMIC-III: {CARPETA_DEMO}")
    for t in TABLAS_DEMO:
        estado((CARPETA_DEMO / t).exists(), f"   {t}")
    estado(RUTA_RECORDS_NUMERICS.is_file(), f"RECORDS-numerics: {RUTA_RECORDS_NUMERICS}")

    print("\nArchivos de los pasos anteriores (y sus columnas)")
    for ruta, columnas in COLUMNAS_NECESARIAS.items():
        if not ruta.exists():
            estado(False, f"{ruta.name}  (no está en {CARPETA_DATOS})")
            continue
        with open(ruta, newline="", encoding="utf-8-sig") as f:
            encabezado = [c.strip().lower() for c in next(csv.reader(f), [])]
        sin = [c for c in columnas if c not in encabezado]
        estado(not sin, f"{ruta.name}" + (f"  (le faltan columnas: {sin})" if sin else ""))

    print("\nTramos de señal")
    hea = sorted(CARPETA_TRAMOS.glob("*_tramo.hea")) if CARPETA_TRAMOS.is_dir() else []
    dat = sorted(CARPETA_TRAMOS.glob("*_tramo.dat")) if CARPETA_TRAMOS.is_dir() else []
    estado(len(hea) == 15 and len(dat) == 15,
           f"tramos_base: {len(hea)} archivos .hea y {len(dat)} .dat (se esperan 15 y 15)")

    print("\nPaquetes de Python")
    for modulo in ("pandas", "numpy", "wfdb"):
        try:
            __import__(modulo)
            estado(True, modulo)
        except ImportError:
            estado(False, f"{modulo}  (instalar con: pip install {modulo})")

    print(f"\n{'Todo listo para correr Paso8 y Paso9.' if not faltan else f'Faltan {faltan} cosas: resolverlas antes de correr.'}")


if __name__ == "__main__":
    verificar()
