# -*- coding: utf-8 -*-
"""
analisis_fc.py — Lectura de la frecuencia cardíaca (FC) para la vista clínica.

Todo se calcula con los datos que ya están en la base (serie de FC del monitor, ~1 muestra/min, más las
mediciones manuales) y nunca con datos posteriores al instante simulado. No depende de Streamlit ni de
Plotly: son funciones puras que se pueden probar solas (ver el bloque `if __name__ == "__main__"`).

Qué entrega:
  * banda_fc(valor)                  -> categoría de la FC (bradicardia / normal / taquicardia) y color
  * tendencia(t_s, valores)          -> pendiente en lpm/h, cambio y rango en la ventana
  * indice_shock(fc, pas)            -> FC / PAS
  * leer_fc(...)                     -> texto corto "qué podría significar" para quien mira la pantalla

Los rangos son de referencia para adultos y la lectura NO es un diagnóstico.
"""
import numpy as np

# Bandas de referencia (adulto en reposo). Coinciden con los cortes que usa el etiquetador independiente
# (<=40 y >=131 críticos; 41-50 y 101-130 intermedios).
BANDAS_FC = [
    (40.0, "bradicardia severa", "#E74C3C"),
    (50.0, "bradicardia", "#F39C12"),
    (100.0, "rango normal", "#2ECC71"),
    (110.0, "taquicardia leve", "#F1C40F"),
    (130.0, "taquicardia", "#F39C12"),
    (float("inf"), "taquicardia severa", "#E74C3C"),
]

VENTANA_TENDENCIA_S = 3600.0     # pendiente y rango: última hora
UMBRAL_PENDIENTE_LPM_H = 5.0     # por debajo de esto se considera estable
UMBRAL_PENDIENTE_RAPIDA = 15.0


def banda_fc(valor):
    """(nombre, color) de la banda de la FC; (None, gris) si no hay dato."""
    if valor is None or (isinstance(valor, float) and np.isnan(valor)):
        return None, "#777777"
    for tope, nombre, color in BANDAS_FC:
        if valor <= tope:
            return nombre, color
    return BANDAS_FC[-1][1], BANDAS_FC[-1][2]


def _limpiar(t_s, valores):
    t = np.asarray(t_s, dtype=float)
    v = np.asarray(valores, dtype=float)
    ok = ~np.isnan(v) & ~np.isnan(t)
    return t[ok], v[ok]


def tendencia(t_s, valores, t_actual, ventana_s=VENTANA_TENDENCIA_S, min_puntos=6, min_cobertura_s=1200.0):
    """Pendiente por regresión lineal sobre la ventana. Devuelve None si hay pocos datos.

    pendiente_h : lpm por hora        cambio : último - primero de la ventana (lpm)
    vmin, vmax  : extremos de la ventana    n : puntos usados
    sentido     : 'sube' | 'baja' | 'estable'      rapida : bool
    """
    t, v = _limpiar(t_s, valores)
    m = t >= t_actual - ventana_s
    t, v = t[m], v[m]
    if len(v) < min_puntos or (t[-1] - t[0]) < min_cobertura_s:
        return None
    pend = float(np.polyfit((t - t[0]) / 3600.0, v, 1)[0])
    if abs(pend) < UMBRAL_PENDIENTE_LPM_H:
        sentido = "estable"
    else:
        sentido = "sube" if pend > 0 else "baja"
    return {"pendiente_h": pend, "cambio": float(v[-1] - v[0]), "vmin": float(v.min()), "vmax": float(v.max()),
            "n": int(len(v)), "sentido": sentido, "rapida": abs(pend) >= UMBRAL_PENDIENTE_RAPIDA,
            "primero": float(v[0]), "ultimo": float(v[-1])}


def flecha(tend):
    """Símbolo corto para tarjetas: ▲ ▼ ► (vacío si no hay dato)."""
    if tend is None:
        return ""
    return {"sube": "▲", "baja": "▼", "estable": "►"}[tend["sentido"]]


def indice_shock(fc, pas):
    """FC / PAS. Normal ≈ 0,5–0,7; ≥ 0,9 elevado; ≥ 1,0 alto. None si falta alguno."""
    if fc is None or pas is None or pas <= 0:
        return None
    return float(fc) / float(pas)


def texto_shock(ix):
    if ix is None:
        return None
    if ix >= 1.0:
        return f"Índice de shock (FC/PAS) {ix:.2f}: alto (≥ 1,0); sugiere compromiso hemodinámico si se confirma."
    if ix >= 0.9:
        return f"Índice de shock (FC/PAS) {ix:.2f}: elevado (≥ 0,9); conviene vigilar la presión."
    return f"Índice de shock (FC/PAS) {ix:.2f}: por debajo de 0,9 (sin alerta)."


def leer_fc(fc, vigente, antiguedad_txt, tend, pam=None, pas=None, spo2=None, temperatura=None):
    """Arma la lectura: devuelve dict(banda, color, resumen, puntos[]) con textos en español.

    `puntos` es una lista de (rotulo, texto, color) ordenada por importancia. Sólo habla de lo que se mide:
    cualquier causa posible se presenta como posibilidad a evaluar, no como diagnóstico.
    """
    banda, color = banda_fc(fc)
    puntos = []
    if fc is None:
        return {"banda": None, "color": color, "resumen": "Sin dato de FC en este momento.", "puntos": []}
    if not vigente:
        puntos.append(("Dato desactualizado",
                       f"El último valor de FC es de {antiguedad_txt or 'hace tiempo'}; la lectura de abajo "
                       "describe ese valor y puede no reflejar el estado actual. Verificar sensor/derivación.",
                       "#F39C12"))

    # --- Qué dice el valor y hacia dónde va
    resumen = f"{fc:.0f} lpm · {banda}"
    if tend is not None:
        if tend["sentido"] == "estable":
            resumen += " · estable en la última hora"
        else:
            verbo = "en ascenso" if tend["sentido"] == "sube" else "en descenso"
            resumen += f" · {verbo} ({tend['pendiente_h']:+.0f} lpm/h)"

    if tend is not None and tend["sentido"] != "estable":
        alto = fc > 100
        bajo = fc < 51
        rapido = "rápido " if tend["rapida"] else ""
        if (alto and tend["sentido"] == "sube") or (bajo and tend["sentido"] == "baja"):
            puntos.append(("Tendencia", f"Cambio {rapido}de {tend['primero']:.0f} a {tend['ultimo']:.0f} lpm en la última hora: "
                           "la FC se aleja del rango normal.", "#E74C3C"))
        elif (alto and tend["sentido"] == "baja") or (bajo and tend["sentido"] == "sube"):
            puntos.append(("Tendencia", f"Cambio {rapido}de {tend['primero']:.0f} a {tend['ultimo']:.0f} lpm en la última hora: "
                           "la FC se acerca al rango normal.", "#2ECC71"))
        else:
            puntos.append(("Tendencia", f"Dentro del rango, pero con un cambio {rapido}de {tend['primero']:.0f} a "
                           f"{tend['ultimo']:.0f} lpm en la última hora." +
                           (" Un cambio tan rápido merece atención aunque el valor sea normal." if tend["rapida"] else ""),
                           "#F1C40F" if tend["rapida"] else "#A0A0A0"))
    elif tend is not None:
        puntos.append(("Tendencia", f"Estable: osciló entre {tend['vmin']:.0f} y {tend['vmax']:.0f} lpm en la última hora.", "#A0A0A0"))
    else:
        puntos.append(("Tendencia", "Todavía no hay suficientes datos en la última hora para calcularla.", "#777777"))

    # --- Qué podría significar
    ctx = []
    if pam is not None and pam < 65:
        ctx.append(f"PAM {pam:.0f} mmHg (baja)")
    if spo2 is not None and spo2 < 92:
        ctx.append(f"SpO2 {spo2:.0f}% (baja)")
    if temperatura is not None and temperatura >= 38.0:
        ctx.append(f"temperatura {temperatura:.1f} °C (fiebre)")
    ctx_txt = (" Contexto actual: " + "; ".join(ctx) + ".") if ctx else ""

    if fc > 100:
        causas = ("Puede reflejar dolor o agitación, fiebre, hipovolemia o sangrado, sepsis, hipoxemia, "
                  "una arritmia (p. ej. fibrilación auricular) o efecto de fármacos.")
        extra = ""
        if pam is not None and pam < 65:
            extra = " Con la presión baja pesa más la posibilidad de compromiso hemodinámico (hipovolemia, sepsis, shock)."
        elif spo2 is not None and spo2 < 92:
            extra = " Con SpO2 baja, descartar primero la hipoxemia."
        elif temperatura is not None and temperatura >= 38.0:
            extra = " Con fiebre, es compatible con un proceso infeccioso o inflamatorio."
        puntos.append(("Qué podría significar", causas + (extra if extra else ctx_txt), color))
    elif fc < 51:
        causas = ("Puede deberse a sedación o fármacos (beta-bloqueantes, opioides, dexmedetomidina), bloqueo AV, "
                  "hipotermia, hipertensión endocraneana o hipoxia grave; en un paciente entrenado o dormido puede ser normal.")
        extra = " Con la presión baja aumenta el riesgo de bajo gasto." if (pam is not None and pam < 65) else ""
        puntos.append(("Qué podría significar", causas + extra, color))
    else:
        puntos.append(("Qué podría significar", "Sin hallazgos en la FC por ahora." + ctx_txt, "#2ECC71"))

    # --- Índice de shock
    t_shock = texto_shock(indice_shock(fc, pas))
    if t_shock:
        ix = indice_shock(fc, pas)
        puntos.append(("Índice de shock", t_shock, "#E74C3C" if ix >= 1.0 else ("#F39C12" if ix >= 0.9 else "#A0A0A0")))

    return {"banda": banda, "color": color, "resumen": resumen, "puntos": puntos}


# ---------------------------------------------------------------------------
# Prueba rápida:  python analisis_fc.py
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    rng = np.random.default_rng(1)
    t = np.arange(-7200, 1, 60.0)
    caso = {
        "estable": 80 + rng.normal(0, 1.2, len(t)),
        "taquicardia_en_ascenso": 85 + np.clip((t + 3600) / 3600, 0, 1) * 40 + rng.normal(0, 1, len(t)),
        "plana": np.full(len(t), 77.0),
        "bradicardia": 47 + rng.normal(0, 1, len(t)),
    }
    for nombre, v in caso.items():
        te = tendencia(t, v, 0.0)
        lec = leer_fc(float(v[-1]), True, "", te, pam=60, spo2=95, pas=100)
        print(f"[{nombre}] {lec['resumen']}")
        for rot, txt, _ in lec["puntos"]:
            print(f"   - {rot}: {txt}")
