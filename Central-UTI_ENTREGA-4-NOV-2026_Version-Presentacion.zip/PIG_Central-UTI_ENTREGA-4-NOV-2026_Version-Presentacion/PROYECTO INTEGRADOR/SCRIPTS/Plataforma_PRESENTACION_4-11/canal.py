# -*- coding: utf-8 -*-
"""
canal.py — Canal de transmisión entre los emisores y el receptor, con inyección de fallas.

El canal es una cola en memoria (determinista y repetible): cada paquete que enviaba un emisor entra con su instante de
emisión y sale con su instante de entrega. Las fallas de transmisión se aplican AQUÍ, en tránsito; los datos de origen
(la base benchmark_uti.db o el generador sintético) no se modifican.

Fallas disponibles (cada una registra el evento que el receptor debería detectar):
  congelado             una variable repite su último valor                      -> receptor: congelado
  caida_canal           una o más variables dejan de llegar (sensor caído)       -> receptor: sin_actualizacion
  valor_imposible       una variable llega con un valor fuera del rango del sensor -> receptor: rechazo_rango
  perdida_comunicacion  la cama completa deja de enviar paquetes                  -> receptor: perdida_comunicacion
  retraso               paquetes que llegan tarde (después de otros más nuevos)   -> receptor: fuera_de_orden
  duplicado             el mismo paquete llega dos veces                          -> receptor: duplicado
"""
import heapq
from dataclasses import dataclass, field

EVENTO_RECEPTOR = {
    "congelado": "congelado", "caida_canal": "sin_actualizacion", "valor_imposible": "rechazo_rango",
    "perdida_comunicacion": "perdida_comunicacion", "retraso": "fuera_de_orden", "duplicado": "duplicado",
}


@dataclass
class Falla:
    tipo: str
    cama: int
    t_ini: float
    t_fin: float                       # la falla afecta a los paquetes emitidos en [t_ini, t_fin)
    variables: tuple = ()              # variables afectadas (congelado, caida_canal, valor_imposible)
    valor: float = None                # valor imposible a inyectar
    demora_s: float = 0.0              # retraso: segundos de demora en la entrega
    _estado: dict = field(default_factory=dict, repr=False)

    def esperado(self):
        """Evento que el receptor debería registrar y desde cuándo se puede detectar."""
        t_posible = self.t_ini + (self.demora_s if self.tipo == "retraso" else 0.0)
        return {"falla": self.tipo, "evento": EVENTO_RECEPTOR[self.tipo], "cama": self.cama,
                "variables": ",".join(self.variables), "t_ini": self.t_ini, "t_fin": self.t_fin, "t_posible": t_posible}


class Canal:
    def __init__(self, fallas=None):
        self.fallas = list(fallas or [])
        self._cola = []                # heap de (t_entrega, orden, paquete)
        self._orden = 0
        self._ultimo = {}              # (cama, variable) -> último valor emitido (para el congelado)

    def _poner(self, t_entrega, paquete):
        heapq.heappush(self._cola, (float(t_entrega), self._orden, paquete))
        self._orden += 1

    def enviar(self, paquete, t):
        """Entra un paquete emitido en t. Aplica las fallas activas y lo encola (o lo pierde)."""
        t_em = paquete["t_emision"]
        cama = paquete["cama"]
        medidas = list(paquete["medidas"])
        t_entrega, copias = float(t), 1
        for f in self.fallas:
            if f.cama != cama or not (f.t_ini <= t_em < f.t_fin):
                continue
            if f.tipo == "perdida_comunicacion":
                return                                          # el paquete nunca llega
            if f.tipo == "caida_canal":
                medidas = [m for m in medidas if m[0] not in f.variables]
            elif f.tipo == "congelado":
                for i, m in enumerate(medidas):
                    if m[0] in f.variables:
                        # valor congelado = último valor emitido antes de empezar la falla
                        clave = (cama, m[0])
                        f._estado.setdefault(clave, self._ultimo.get(clave, m[2]))
                        medidas[i] = (m[0], m[1], f._estado[clave], m[3], m[4])
            elif f.tipo == "valor_imposible":
                medidas = [(m[0], m[1], f.valor, m[3], m[4]) if m[0] in f.variables else m for m in medidas]
            elif f.tipo == "retraso":
                t_entrega = max(t_entrega, t_em + f.demora_s)
            elif f.tipo == "duplicado":
                copias = 2
        # el "último valor emitido" se actualiza con los datos SIN congelar (lo que el sensor midió antes de la falla)
        activos_cong = {v for f in self.fallas if f.tipo == "congelado" and f.cama == cama
                        and f.t_ini <= t_em < f.t_fin for v in f.variables}
        for m in paquete["medidas"]:
            if m[0] not in activos_cong:
                self._ultimo[(cama, m[0])] = m[2]
        p = dict(paquete, medidas=medidas)
        for _ in range(copias):
            self._poner(t_entrega, p)

    def entregar(self, t):
        """Paquetes cuya entrega es <= t, en orden de entrega."""
        salida = []
        while self._cola and self._cola[0][0] <= t + 1e-9:
            t_ent, _, p = heapq.heappop(self._cola)
            salida.append((t_ent, p))
        return salida

    def esperados(self):
        return [f.esperado() for f in self.fallas]
