# ============================================================
# validar_plataforma.py - Validación del motor contra la verdad de referencia (D7)
#
# Uso (Anaconda Prompt, parada en SCRIPTS\Plataforma_v2, DESPUÉS de correr Paso10):
#     python validar_plataforma.py            -> evalúa cada 5 s del tramo
#     python validar_plataforma.py 1          -> evalúa cada 1 s (más lento, más preciso en la latencia)
#     python validar_plataforma.py 5 ..\Plataforma_unificada   -> valida el motor de otra carpeta (comparación)
#
# Qué hace
#   1) Recorre las 15 camas en la ventana viva (0 a 1800 s) y evalúa el motor (reglas_basicas.evaluar)
#      con la misma instantánea que usa la pantalla (datos_db.BaseUTI.snapshot). No usa la interfaz:
#      a velocidad x10 o x60 la pantalla saltea segundos y el resultado dependería de la velocidad.
#   2) Arma los episodios de alarma de la plataforma (inicio, fin, nivel, prioridad).
#   3) Los empareja con eventos_esperados (origen real, ventana viva) por cama, tipo y clave:
#        VP  = el evento esperado tiene un episodio que empieza a más tardar en t_inicio + latencia máxima
#              del escenario y se superpone con el evento (con la tolerancia del evento hacia atrás).
#        FN  = evento esperado sin episodio emparejado.
#        FP  = episodio de la plataforma que no se superpone con ningún evento esperado de la misma clave.
#      El nivel (fisiológicas) y la prioridad (técnicas) se comparan aparte: concordancia de nivel.
#   3b) Si la base tiene fallas inyectadas (Paso11: benchmark_uti_validacion.db, con set UTI_DB=...), también
#      empareja las 23 inyecciones (fallas_tecnicas y eventos_esperados de origen inyectado). Los eventos reales
#      que caen en la ventana de una inyección se excluyen (sus datos fueron reemplazados) y las alarmas que la
#      falla provoca en esa cama se informan como consecuencia, no como falsas.
#   4) Informa sensibilidad, VPP, falsas alarmas por cama-hora, latencia y concordancia, por grupo,
#      y guarda el detalle en validacion_detalle.csv (un renglón por evento esperado y por FP).
#
# Lee eventos_esperados y escenarios: es un script de VALIDACIÓN, no parte de la plataforma.
# La plataforma (datos_db) sigue sin leer esas tablas.
# ============================================================
import sqlite3
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

AQUI = Path(__file__).resolve().parent
PASO_S = float(sys.argv[1]) if len(sys.argv) > 1 else 5.0
CARPETA = Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else AQUI
sys.path.insert(0, str(CARPETA))
import datos_db as ddb          # noqa: E402
import reglas_basicas as reglas  # noqa: E402
FUERA_DE_ALCANCE = {"temperatura", "plaquetas", "creatinina", "pao2", "tec_pao2"}   # el motor no tiene reglas
GRUPO = {"fc": "Fisiológicas · hemodinámicas", "pam": "Fisiológicas · hemodinámicas",
         "pas": "Fisiológicas · hemodinámicas", "shock": "Fisiológicas · hemodinámicas",
         "spo2": "Fisiológicas · respiratorias", "fr": "Fisiológicas · respiratorias",
         "resp": "Fisiológicas · respiratorias"}
LAT_DEFECTO = {"alarma": 180.0, "tecnica": 360.0}
# Inyecciones del Paso11 -> (tipo, claves que cuentan como respuesta correcta, alcance)
#   alcance "motor": hay regla con datos numéricos; "onda": hace falta analizar la señal continua (ECG/ABP/PLETH);
#   "sin regla": el motor todavía no tiene esa regla.
MAPA_INYECCION = {
    "A01": ("tecnica", {"tec_fc"}, "onda"),            # ECG sin electrodo: latencia 30 s, se ve en la onda
    "A03": ("tecnica", {"tec_spo2"}, "motor"),         # canal ausente
    "A04": ("tecnica", {"tec_pa"}, "onda"),            # ABP plana
    "A05": ("tecnica", {"tec_fc"}, "onda"),            # artefacto de movimiento
    "A06": ("tecnica", {"tec_pa"}, "onda"),            # línea amortiguada
    "A08": ("tecnica", {"tec_pa"}, "sin regla"),       # deriva del cero (inconsistencia entre canales)
    "A09": ("tecnica", {"tec_spo2"}, "motor"),         # valor imposible
    "A11": ("tecnica", {"tec_fc"}, "sin regla"),       # dato congelado (el criterio del catálogo da falsos positivos)
    "A14": ("tecnica", {"tec_cama", "tec_fc", "tec_spo2", "tec_fr"}, "motor"),
    "B01": ("alarma", {"fc"}, "motor"), "B02": ("alarma", {"fc"}, "motor"),
    "B03": ("alarma", {"asistolia"}, "onda"),          # asistolia: ECG y PLETH planos
    "B06": ("alarma", {"pas"}, "motor"), "B09": ("alarma", {"shock", "pam"}, "motor"),
    "C07": ("alarma", {"resp", "spo2"}, "motor"), "B12": ("alarma", {"pvc"}, "sin regla"),
}
# Variables que cada inyección reemplaza (para excluir eventos reales y no contar como falsas las alarmas que provoca)
_TODAS = {"fc", "spo2", "fr", "pam", "pas", "shock", "resp"}
AFECTA = {"A01": {"fc", "shock"}, "A05": {"fc"}, "A11": {"fc", "shock"}, "B01": {"fc", "shock"}, "B02": {"fc", "shock"},
          "B03": {"fc", "shock"}, "A03": {"spo2", "resp"}, "A09": {"spo2", "resp"}, "C07": {"spo2", "resp"},
          "A04": {"pam", "pas", "shock"}, "A06": {"pam", "pas", "shock"}, "A07": {"pam", "pas", "shock"},
          "A08": {"pam", "pas", "shock"}, "B06": {"pas", "shock"}, "B09": {"fc", "pam", "pas", "shock"},
          "A14": _TODAS, "B12": {"pvc"}, "A16": {"pam", "pas", "shock"}, "B11": set(), "A15": set()}


def relacionadas(escenario):
    """Claves (fisiológicas y técnicas) que una inyección puede alterar."""
    v = AFECTA.get(escenario, set())
    tec = {"tec_pa" if x in ("pam", "pas") else f"tec_{x}" for x in v if x not in ("shock", "resp")}
    return v | tec | ({"tec_cama"} if escenario == "A14" else set())
UMBRALES_V1 = {"fc_max": 120, "pam_min": 65, "spo2_min": 92, "fr_max": 25, "pas_min": 90}   # solo motores viejos

base = ddb.BaseUTI()
DUR = base.duracion_s
con = sqlite3.connect(base.ruta.resolve().as_uri() + "?mode=ro", uri=True)
try:
    esperados = pd.read_sql("SELECT * FROM eventos_esperados WHERE origen='real' AND ventana='vivo' "
                            "AND tipo IN ('alarma','tecnica') AND t_inicio_s <= ? AND t_fin_s >= 0",
                            con, params=[DUR])
    latencias = dict(con.execute("SELECT codigo, latencia_max_s FROM escenarios").fetchall())
    tablas = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    inyecciones = (pd.read_sql("SELECT * FROM inyecciones_aplicadas WHERE estado='aplicada'", con)
                   if "inyecciones_aplicadas" in tablas else pd.DataFrame())
except Exception as error:
    sys.exit(f"No encuentro la verdad de referencia en la base ({error}). Corré antes Paso10_cargar_escenarios.py.")
con.close()
CON_FALLAS = not inyecciones.empty
if "clave" not in esperados.columns:
    sys.exit("eventos_esperados no tiene la columna `clave`: corré la versión 2 de Paso10_cargar_escenarios.py.")
if esperados.empty:
    sys.exit("eventos_esperados está vacía: corré antes Paso10_cargar_escenarios.py.")


esperados["claves"] = esperados["clave"].map(lambda c: frozenset([c]))
esperados["alcance"] = "motor"
ventanas_falla, ventanas_vn = [], []
if CON_FALLAS:
    filas = []
    plan = pd.read_csv(AQUI / "plan_inyeccion_v3.csv", encoding="utf-8-sig").set_index("falla_id")
    estado = {"ADVERTENCIA": "media", "CRITICA": "alta", "REQUIERE REVISION": "baja"}
    for r in inyecciones.itertuples():
        if r.t_fin_s < 0:                               # A10: unidades erróneas en la historia (fuera de la ventana viva)
            continue
        if r.escenario not in MAPA_INYECCION:           # ESTABLE por diseño (A07, A15, A16, B11): no debe alarmar
            ventanas_vn.append((r.cama_id, r.t_inicio_s, r.t_fin_s, r.escenario))
            continue
        tipo, claves, alcance = MAPA_INYECCION[r.escenario]
        ventanas_falla.append((r.cama_id, r.t_inicio_s, r.t_fin_s, r.escenario))
        esperado = plan.loc[r.falla_id, "estado_esperado"]
        filas.append({"cama_id": r.cama_id, "tipo": tipo, "nombre": f"[inyectada] {r.tipo}", "t_inicio_s": r.t_inicio_s,
                      "t_fin_s": r.t_fin_s, "valor_esperado": esperado if tipo == "alarma" else "REQUIERE REVISION",
                      "prioridad": estado.get(esperado), "clave": sorted(claves)[0], "claves": frozenset(claves),
                      "confianza": "alta", "tolerancia_s": float(plan.loc[r.falla_id, "tolerancia_s"]),
                      "origen": "inyectado", "escenario": r.escenario, "ventana": "vivo", "alcance": alcance})
    # los eventos reales que caen en la ventana de una inyección se excluyen: sus datos fueron reemplazados
    def tapado(e):
        return any(e.cama_id == c and e.clave in relacionadas(esc) and e.t_inicio_s <= f + 360 and e.t_fin_s >= i - 360
                   for c, i, f, esc in ventanas_falla + ventanas_vn)
    antes = len(esperados)
    esperados = esperados[~esperados.apply(tapado, axis=1)]
    print(f"Base con fallas inyectadas: {len(filas)} inyecciones a emparejar, {len(ventanas_vn)} ventanas que no deben alarmar; "
          f"{antes - len(esperados)} eventos reales excluidos por caer en la ventana de una inyección.")
    esperados = pd.concat([esperados, pd.DataFrame(filas)], ignore_index=True)


def completar(a):
    """Motores anteriores a las reglas v2 no traen tipo, prioridad ni clave: se deducen del nombre de la regla."""
    if "clave" in a:
        return a
    r = a["regla"]
    tecnica = reglas.es_tecnica(a)
    if tecnica:
        var = r.rsplit("_", 1)[-1].lower()
        clave = {"pas": "tec_pa", "pad": "tec_pa", "pam": "tec_pa"}.get(var, f"tec_{var}")
    else:
        clave = {"SHOCK_HEMODINAMICO": "shock", "HIPOTENSION": "pam", "FALLA_RESPIRATORIA": "resp",
                 "HIPOXEMIA_SEVERA": "spo2", "HIPOXEMIA": "spo2"}.get(r, r.lower())
    nivel = a["nivel"]
    return {**a, "clave": clave, "tipo": "tecnica" if tecnica else "fisiologica",
            "prioridad": "baja" if tecnica else ("alta" if nivel == "CRITICA" else "media")}


def grupo(clave):
    return "Técnicas" if str(clave).startswith("tec_") else GRUPO.get(clave, "Otras")


# ------------------------------------------------------------
# 1) y 2) Episodios de la plataforma
# ------------------------------------------------------------
print(f"\n=== Validación de la plataforma contra la verdad de referencia ===")
print(f"Motor: {CARPETA.name}\nBase: {base.ruta}\nPaso de evaluación: {PASO_S:g} s · ventana viva 0–{DUR:g} s\n")
inicio = time.perf_counter()
instantes = np.arange(0.0, DUR + 0.1, PASO_S)
episodios = []                                    # dicts
for cama in [int(c) for c in base.camas["cama_id"]]:
    est = base.estadia_de_cama(cama)
    abiertos = {}                                 # regla -> episodio
    for t in instantes:
        activas = {a["regla"]: completar(a) for a in reglas.evaluar(base.snapshot(est, t), UMBRALES_V1, base)}
        for regla, ep in list(abiertos.items()):
            if regla not in activas:
                episodios.append(abiertos.pop(regla))
        for regla, a in activas.items():
            if regla in abiertos:
                abiertos[regla]["t1"] = t
            else:
                abiertos[regla] = {"cama_id": cama, "regla": regla, "clave": a["clave"],
                                   "tipo": "alarma" if a["tipo"] == "fisiologica" else "tecnica",
                                   "nivel": a["nivel"], "prioridad": a["prioridad"], "t0": t, "t1": t,
                                   "mensaje": a["mensaje"]}
    episodios += abiertos.values()
plataforma = pd.DataFrame(episodios)
print(f"Motor evaluado en {len(instantes) * len(base.camas)} instantes "
      f"({time.perf_counter() - inicio:.0f} s): {len(plataforma)} episodios de alarma.\n")

# ------------------------------------------------------------
# 3) Emparejamiento
# ------------------------------------------------------------
detalle = []
usados = set()
for e in esperados.itertuples():
    lat = latencias.get(e.escenario)
    lat = LAT_DEFECTO[e.tipo] if lat is None or pd.isna(lat) or lat <= 0 else float(lat)
    tol = float(e.tolerancia_s or 0)
    ref = max(e.t_inicio_s, 0.0)                 # un evento que viene de antes debe verse desde t = 0
    fila = {"resultado": "", "cama_id": e.cama_id, "tipo": e.tipo, "clave": e.clave, "grupo": grupo(e.clave),
            "escenario": e.escenario, "nombre": e.nombre, "esperado_inicio_s": e.t_inicio_s,
            "esperado_fin_s": e.t_fin_s, "esperado_nivel": e.valor_esperado, "esperada_prioridad": e.prioridad,
            "confianza": e.confianza, "plataforma_inicio_s": None, "plataforma_regla": None,
            "plataforma_nivel": None, "latencia_s": None, "nivel_coincide": None, "origen": e.origen,
            "alcance": e.alcance}
    if e.clave in FUERA_DE_ALCANCE:
        fila["resultado"] = "FUERA DE ALCANCE"
        detalle.append(fila)
        continue
    cand = plataforma[(plataforma.cama_id == e.cama_id) & (plataforma.clave.isin(e.claves)) & (plataforma.tipo == e.tipo)] \
        if not plataforma.empty else plataforma
    cand = cand[(cand.t0 <= ref + lat) & (cand.t1 >= ref - tol) & (cand.t0 <= max(e.t_fin_s, ref) + tol)]
    if e.origen == "inyectado":
        # una falla inyectada solo se acredita con una alarma que nace después de la inyección
        # (una muestra de margen); una alarma que ya estaba sonando no es respuesta a la falla
        cand = cand[cand.t0 >= ref - 60]
    if cand.empty:
        fila["resultado"] = {"motor": "FN", "onda": "FN · requiere la onda", "sin regla": "FN · sin regla"}[e.alcance]
    else:
        objetivo = e.valor_esperado if e.tipo == "alarma" else e.prioridad
        campo = "nivel" if e.tipo == "alarma" else "prioridad"
        mismos = cand[cand[campo] == objetivo]
        elegido = (mismos if not mismos.empty else cand).sort_values("t0").iloc[0]
        usados.update(cand.index)
        fila.update(resultado="VP", plataforma_inicio_s=elegido.t0, plataforma_regla=elegido.regla,
                    plataforma_nivel=elegido[campo], latencia_s=max(0.0, elegido.t0 - ref),
                    nivel_coincide=bool(elegido[campo] == objetivo))
    detalle.append(fila)

# FP: episodios que no se superponen con ningún evento esperado de la misma cama, tipo y clave
for i, p in plataforma.iterrows():
    if i in usados:
        continue
    if any(p.cama_id == c and p.clave in relacionadas(esc) and p.t0 <= f + 360 and p.t1 >= i
           for c, i, f, esc in ventanas_falla):
        continue                                       # consecuencia de una falla inyectada sobre esa variable
    en_vn = [esc for c, i, f, esc in ventanas_vn if p.cama_id == c and p.t0 <= f and p.t1 >= i]
    mismos = esperados[(esperados.cama_id == p.cama_id) & (esperados.claves.map(lambda s: p.clave in s))
                       & (esperados.tipo == p.tipo)]
    tol = mismos.tolerancia_s.max() if not mismos.empty else 0
    solapa = mismos[(mismos.t_inicio_s <= p.t1 + tol) & (mismos.t_fin_s >= p.t0 - tol)]
    if not solapa.empty:
        continue
    detalle.append({"resultado": "FP", "cama_id": p.cama_id, "tipo": p.tipo, "clave": p.clave, "grupo": grupo(p.clave),
                    "escenario": None, "nombre": p.mensaje, "esperado_inicio_s": None, "esperado_fin_s": None,
                    "esperado_nivel": None, "esperada_prioridad": None, "confianza": None,
                    "plataforma_inicio_s": p.t0, "plataforma_regla": p.regla,
                    "plataforma_nivel": p.nivel if p.tipo == "alarma" else p.prioridad,
                    "latencia_s": None, "nivel_coincide": None, "plataforma_fin_s": p.t1,
                    "origen": "plataforma", "alcance": f"durante {en_vn[0]} (no debía alarmar)" if en_vn else ""})
det = pd.DataFrame(detalle)

# ------------------------------------------------------------
# 4) Métricas
# ------------------------------------------------------------
horas_cama = len(base.camas) * DUR / 3600.0


def metricas(d):
    vp = int((d.resultado == "VP").sum())
    fn = int((d.resultado == "FN").sum())
    fuera = int(d.resultado.str.startswith("FN ·").sum())
    fp = int((d.resultado == "FP").sum())
    lat = d.loc[d.resultado == "VP", "latencia_s"].astype(float)
    conc = d.loc[d.resultado == "VP", "nivel_coincide"]
    return {"VP": vp, "FN": fn, "FP": fp, "FN fuera de alcance": fuera,
            "Sensibilidad": f"{100 * vp / (vp + fn):.0f} %" if vp + fn else "—",
            "VPP": f"{100 * vp / (vp + fp):.0f} %" if vp + fp else "—",
            "FA por cama-h": f"{fp / horas_cama:.2f}",
            "Latencia med / máx (s)": f"{lat.median():.0f} / {lat.max():.0f}" if len(lat) else "—",
            "Nivel coincide": f"{100 * conc.mean():.0f} %" if len(conc) else "—",
            "Puntaje (VP/(VP+FP+5·FN))": f"{vp / (vp + fp + 5 * fn):.2f}" if vp + fp + fn else "—"}


principal = det[(det.resultado == "FP") | (det.confianza == "alta")]
filas = []
for g in ["Fisiológicas · hemodinámicas", "Fisiológicas · respiratorias", "Técnicas"]:
    filas.append({"Grupo": g, **metricas(principal[principal.grupo == g])})
filas.append({"Grupo": "TOTAL", **metricas(principal)})
if CON_FALLAS:
    filas.append({"Grupo": "Solo las inyectadas", **metricas(principal[principal.origen == "inyectado"])})
tabla = pd.DataFrame(filas)
pd.set_option("display.width", 220, "display.max_colwidth", 60)
print("Métricas (eventos de confianza alta; las FP se cuentan siempre):")
print(tabla.to_string(index=False))

media = det[det.confianza == "media"]
if not media.empty:
    print(f"\nConfianza media (se informan aparte): {int((media.resultado == 'VP').sum())} VP, "
          f"{int((media.resultado == 'FN').sum())} FN  ->  {', '.join(sorted(media.escenario.dropna().unique()))}")
fuera = det[det.resultado == "FUERA DE ALCANCE"]
if not fuera.empty:
    print(f"Fuera de alcance del motor (sin reglas todavía): {len(fuera)} eventos -> "
          f"{', '.join(sorted(fuera.clave.unique()))}")

errores = det[det.resultado.str.startswith(("FN", "FP"))].sort_values(["cama_id", "resultado"])
if not errores.empty:
    print("\nFalsos negativos y falsos positivos:")
    cols = ["resultado", "cama_id", "escenario", "clave", "nombre", "esperado_inicio_s", "esperado_fin_s", "esperado_nivel",
            "plataforma_inicio_s", "plataforma_nivel"]
    print(errores[cols].to_string(index=False))
discord = det[(det.resultado == "VP") & (det.nivel_coincide == False)]  # noqa: E712
if not discord.empty:
    print("\nVP con nivel o prioridad distinta de la esperada:")
    print(discord[["cama_id", "clave", "nombre", "esperado_nivel", "esperada_prioridad", "plataforma_nivel",
                   "latencia_s"]].to_string(index=False))

sufijo = "" if CARPETA == AQUI else f"_{CARPETA.name}"
det.to_csv(AQUI / f"validacion_detalle{sufijo}.csv", index=False, encoding="utf-8-sig")
tabla.to_csv(AQUI / f"validacion_metricas{sufijo}.csv", index=False, encoding="utf-8-sig")
print(f"\nCSV guardados en {AQUI}:\n  validacion_metricas{sufijo}.csv\n  validacion_detalle{sufijo}.csv")
