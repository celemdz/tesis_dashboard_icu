#!/usr/bin/env python
# coding: utf-8
# ============================================================
# Interfaz_uti_db.py - Central de monitoreo UTI conectada a benchmark_uti.db
#
# Ejecutar (desde Anaconda Prompt):
#     cd "...\PROYECTO INTEGRADOR\SCRIPTS\Plataforma"
#     streamlit run Interfaz_uti_db.py
#
# Misma interfaz y roles que Interfaz_usuarios.py, pero:
#   - los datos salen de la base (solo lectura, vistas v_*) y avanzan con un reloj de simulación
#   - la vista micro muestra la señal real (ECG / ABP / pletismografía) del tramo y los indicadores clínicos
#     (NEWS2, qSOFA, SOFA y APACHE II parciales, índice de shock, oxigenación)
#   - hay una vista de AYUDA (HELP) con la explicación de lo que ofrece la plataforma
#   - las alarmas se registran en plataforma_uti.db, con reconocimiento por operador
#
# INTEGRACIÓN 22/10/2026 (Celeste) sobre la versión de Maxi del 20/10:
#   1. Motor de reglas v2 (reglas_basicas.py): umbrales de umbrales_validacion.csv, persistencia de 2 muestras,
#      prioridad de fallas técnicas, FR = 0 con SpO2 normal, PA no invasiva con vigencia de 60 min.
#   2. Calidad de dato en pantalla: un valor inválido nunca se muestra como número ('---' sin dato o sensor
#      desconectado, '-?-' fuera de rango). Las fallas técnicas van en cian con borde punteado (IEC 60601-1-8)
#      y no quedan tapadas por la alarma clínica: la tarjeta muestra las dos.
#   3. La lectura de FC solo usa valores válidos (antes leía SpO2 = 0 como «baja»).
#   4. Egreso por óbito con confirmación obligatoria.
#   5. AYUDA: la tabla de umbrales se arma desde la especificación (ya no hay umbrales fijos en el código).
#
# CAMBIOS 25/10/2026 (Maxi):
#   1. ORIGEN DE LOS DATOS (barra lateral): BASE DE DATOS (lectura directa) o EMISORES VIRTUALES (emisores -> canal ->
#      receptor, enlace.py). Con emisores se puede reproducir las 15 camas de la base o generar camas sintéticas, y
#      activar fallas de transmisión de demostración. Cambiar de origen reinicia la corrida y el reloj.
#   2. INDICADORES DE GESTIÓN: bloque «Calidad de datos del enlace» (eventos del receptor) cuando el origen son emisores.
#   0. HORA SIMULADA: arranca en la hora real del equipo en que se ejecuta la plataforma (al abrir la sesión, al REINICIAR o
#      al cambiar de origen) y avanza con el reloj de simulación (t = 0 es la hora de inicio).
#   3. INDICADORES DE GESTIÓN en dos pantallas (pestañas): [1] panel general (ocupación, alarmas, gravedad, calidad
#      del enlace, RR.HH.) y [2] trazabilidad de equipamiento (traslados, mapa de activos y hoja de vida).
# ============================================================

import html
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent))
import analisis_fc as AF        # noqa: E402
import datos_db as ddb          # noqa: E402
import enlace as EL            # noqa: E402
import persistencia as pers     # noqa: E402
import reglas_basicas as reglas  # noqa: E402
import reloj as rl              # noqa: E402
import scores_clinicos as SC    # noqa: E402
import senales                  # noqa: E402

# ==============================================================================
# CONFIGURACIÓN Y ESTILOS CLÍNICOS
# ==============================================================================
st.set_page_config(layout="wide", page_title="Sistema Central UTI", initial_sidebar_state="expanded")

st.markdown("""
<style>
    /* Fondo oscuro desde el primer instante (evita el destello al cargar) */
    html, body, .stApp, [data-testid="stAppViewContainer"], [data-testid="stHeader"], [data-testid="stSidebar"],
    [data-testid="stMain"], .main { background-color: #0A0A0A !important; }
    [data-testid="stSidebar"] { background-color: #0F0F0F !important; }
    /* Streamlit atenúa lo "viejo" en cada recarga: se desactiva para que no parpadee */
    [data-stale="true"], .stale-element, .element-container, .stElementContainer, .stPlotlyChart, .stDataFrame {
        opacity: 1 !important; transition: none !important; }
    [data-testid="stStatusWidget"] { visibility: hidden; }
    * { animation-duration: 0s !important; }
    .stApp { background-color: #0A0A0A; color: #D4D4D4; font-family: 'Segoe UI', sans-serif; }
    .stTabs [data-baseweb="tab-list"] { background-color: #121212; border-bottom: 1px solid #2A2A2A; }
    .stTabs [data-baseweb="tab"] { background-color: #1A1A1A; padding: 10px 20px; border: 1px solid #2A2A2A; border-bottom: none; }
    .stTabs [aria-selected="true"] { background-color: #222 !important; border-top: 3px solid #3498DB !important; }
    .stTabs [data-baseweb="tab-list"] button p { font-size: 12px !important; font-weight: 600 !important; color: #777; letter-spacing: 1px; }
    .stTabs [aria-selected="true"] button p { color: #FFF !important; }
    .metric-box { background-color: #121212; border-left: 3px solid; padding: 12px; border-radius: 2px; }
    .lcd-val { font-family: 'Consolas', monospace; font-size: 26px; font-weight: bold; margin: 0; }
    .lcd-lbl { font-size: 10px; color: #888; text-transform: uppercase; letter-spacing: 1px; margin: 0; }
    .lcd-text { font-family: 'Consolas', monospace; font-weight: bold; }
</style>
""", unsafe_allow_html=True)

# [integración] Las fallas técnicas (REQUIERE REVISION) pasan de violeta a cian (IEC 60601-1-8) y se distinguen por la forma.
COLOR_TECNICO = "#00BCD4"
COLOR_ESTADO = {"CRITICA": "#E74C3C", "ADVERTENCIA": "#F39C12", "REQUIERE REVISION": COLOR_TECNICO, "ESTABLE": "#2A2A2A"}
ETIQUETA_ESTADO = {"CRITICA": "CRITICA", "ADVERTENCIA": "ADVERTENCIA", "REQUIERE REVISION": "REQUIERE REVISION",
                   "ESTABLE": "PARAMETROS EN RANGO"}


# ==============================================================================
# RECURSOS COMPARTIDOS (se cargan una sola vez)
# ==============================================================================
@st.cache_resource
def abrir_base():
    return ddb.BaseUTI()


@st.cache_resource
def abrir_persistencia():
    return pers.Persistencia()


@st.cache_resource
def abrir_ritmo():
    return senales.RitmoCache()


try:
    base_real = abrir_base()
    base = base_real          # se reemplaza más abajo por el receptor si el origen son emisores virtuales
except Exception as error:   # base inexistente o ilegible
    st.error(f"No se pudo abrir la base de datos.\n\n{error}")
    st.stop()
P = abrir_persistencia()
RITMO = abrir_ritmo()

# ==============================================================================
# AUTENTICACIÓN
# ==============================================================================
if "autenticado" not in st.session_state:
    st.session_state.autenticado = False

if not st.session_state.autenticado:
    st.markdown("<br><br><br><h2 style='text-align: center; color: #FFF; font-weight: 300; letter-spacing: 2px;'>MIMIC-CENTRAL UTI</h2>", unsafe_allow_html=True)
    st.markdown("<p style='text-align: center; color: #888; font-size: 12px; letter-spacing: 1px;'>ACCESO RESTRINGIDO A PERSONAL AUTORIZADO</p>", unsafe_allow_html=True)
    col1, col2, col3 = st.columns([1.5, 1, 1.5])
    with col2:
        with st.form("login_form"):
            profesional_sel = st.selectbox("SELECCIONE OPERADOR", [
                "ING. GOMEZ, MAXIMO (BIOMEDICA)", "ING. MENDEZ QUIROGA, CELESTE (SOPORTE)",
                "DR. OLMOS, CARLOS (JEFATURA)", "LIC. ENFERMERIA (TURNO)"])
            clave = st.text_input("CLAVE DE ACCESO", type="password")
            if st.form_submit_button("INGRESAR AL SISTEMA", use_container_width=True):
                if clave == "123":
                    st.session_state.autenticado = True
                    st.session_state.profesional_activo = profesional_sel
                    st.rerun()
                else:
                    st.error("CREDENCIAL INVALIDA")
    st.stop()

operador = st.session_state.profesional_activo
es_jefatura = "JEFATURA" in operador
es_bioingenieria = "BIOMEDICA" in operador or "SOPORTE" in operador or es_jefatura

# ==============================================================================
# ORIGEN DE LOS DATOS: BASE DE DATOS o EMISORES VIRTUALES
# ==============================================================================
# Los bloques de la barra lateral se reservan ahora, en el orden en que se ven (cabecera, origen, reloj),
# y se completan más abajo; así el origen se resuelve antes de armar el resto de la pantalla.
_sb_cab = st.sidebar.container()
_sb_origen = st.sidebar.container()
_sb_reloj = st.sidebar.container()

ORIGEN_BASE, ORIGEN_EMISORES = "BASE DE DATOS", "EMISORES VIRTUALES"
with _sb_origen:
    st.markdown("---")
    st.markdown("<p style='color:#888; font-size:10px; font-weight:bold;'>ORIGEN DE LOS DATOS</p>", unsafe_allow_html=True)
    origen = st.radio("Origen de los datos", [ORIGEN_BASE, ORIGEN_EMISORES], key="origen_datos", label_visibility="collapsed",
                      help="BASE DE DATOS: la central lee benchmark_uti.db directamente. EMISORES VIRTUALES: cada cama publica "
                           "paquetes por un canal y la central los recibe, valida y guarda en memoria (la base no se toca).")
    tipo_emisor, con_fallas, semilla = "replay", False, 1
    if origen == ORIGEN_EMISORES:
        tipo_emisor = st.selectbox("Emisor", list(EL.TIPOS), format_func=EL.TIPOS.get, key="tipo_emisor")
        if tipo_emisor == "sintetico":
            semilla = int(st.number_input("Semilla del generador", min_value=1, max_value=9999, value=1, step=1, key="semilla_emisor"))
        con_fallas = st.checkbox("Inyectar fallas de transmisión (demostración)", key="fallas_canal",
                                 help="Congelado, caída de un sensor, valor imposible, pérdida de comunicación, retraso y duplicado, "
                                      "una por cama (camas 3, 5, 7, 9, 11 y 12).")

config_fuente = (origen, tipo_emisor, con_fallas, semilla)
fuente_previa = st.session_state.get("fuente_activa")
cambio_fuente = fuente_previa is not None and fuente_previa != config_fuente
if fuente_previa != config_fuente:
    SC._CACHE.clear()                       # el caché de indicadores es por objeto de datos
    if origen == ORIGEN_EMISORES:
        with st.spinner("Armando emisores, canal y receptor..."):
            st.session_state.enlace = EL.Enlace(base_real, tipo_emisor, con_fallas, semilla)
    else:
        st.session_state.enlace = None
    st.session_state.fuente_activa = config_fuente
enlace = st.session_state.get("enlace")
base = enlace.receptor if enlace is not None else base_real
with _sb_origen:
    st.caption(enlace.descripcion() if enlace is not None else f"Lectura directa de {base_real.ruta.name} (solo lectura)")

# ==============================================================================
# SIMULACIÓN: corrida y reloj (uno por sesión de navegador)
# ==============================================================================
if "corrida_id" not in st.session_state:
    st.session_state.corrida_id = P.nueva_corrida(operador)
    st.session_state.reloj = rl.RelojSim(t_max=base.duracion_s)
    st.session_state.hora_inicio_real = datetime.now().replace(microsecond=0)
corrida = st.session_state.corrida_id
reloj = st.session_state.reloj
if cambio_fuente:                           # otro origen = otra corrida, desde el segundo 0
    P.cerrar_todas(corrida, reloj.t_s)
    st.session_state.corrida_id = P.nueva_corrida(operador)
    corrida = st.session_state.corrida_id
    reloj.reiniciar()
    st.session_state.hora_inicio_real = datetime.now().replace(microsecond=0)
if enlace is not None:
    enlace.avanzar(reloj.t_s)

BASE_CAMAS = {int(r.cama_id): (None if pd.isna(r.estadia_actual) else int(r.estadia_actual))
              for r in base.camas.itertuples()}


def ocupacion_actual():
    return P.ocupacion(corrida, BASE_CAMAS)


# ==============================================================================
# FORMATO
# ==============================================================================
def box(cama_id):
    return f"BOX-{int(cama_id):02d}"


def num(x, dec=0):
    return "—" if x is None or (isinstance(x, float) and np.isnan(x)) else f"{x:.{dec}f}"


def hace(segundos):
    if segundos is None:
        return ""
    m = segundos / 60.0
    if m < 1.5:
        return ""
    return f"hace {m:.0f} min" if m < 120 else f"hace {m / 60:.1f} h"


# Reglas v2: los umbrales de alarma salen de umbrales_validacion.csv (los lee reglas_basicas.py).
# UMBRALES_FIJOS queda solo por compatibilidad: reglas_basicas.evaluar() ya no lo usa.
VENTANA_TEND_S = 3600.0   # ventana de la flecha de tendencia de FC en las tarjetas
UMBRALES_FIJOS = {"fc_max": 120, "pam_min": 65, "spo2_min": 92, "fr_max": 25, "pas_min": 90}


def umbrales_actuales():
    return UMBRALES_FIJOS


def mostrar(x, estado, dec=0):
    """[integración] Número si el valor es utilizable; símbolo si no lo es."""
    if estado in (reglas.FALTANTE, reglas.DESCONECTADO):
        return "---"
    if estado == reglas.NO_FISIOLOGICO:
        return "-?-"
    return num(x, dec)


def etiqueta_tecnica(alarmas_tec):
    """[integración] Etiqueta de falla técnica: fondo cian, texto negro; lista completa al pasar el mouse."""
    if not alarmas_tec:
        return ""
    textos = [html.escape(a["mensaje"].replace("[REVISAR] ", "")) for a in alarmas_tec]
    extra = f" (+{len(textos) - 1} más)" if len(textos) > 1 else ""
    return (f"<div title='{' | '.join(textos)}' style='background-color:{COLOR_TECNICO}; color:#000; padding:2px 4px; "
            f"margin-top:3px; border-radius:2px; text-align:center; cursor:help;'>{textos[0]}{extra}</div>")


def valor_html(etiqueta, texto, color, dato=None, sufijo=""):
    """Un valor LCD. Si el dato no está vigente se atenúa y se indica su antigüedad."""
    viejo = dato is not None and not dato.vigente and texto not in ("---", "-?-")
    c = "#555" if viejo else color
    pie = f"<br><span style='font-size:8px;color:#777;'>{hace(dato.antiguedad_s)}</span>" if viejo else ""
    return (f"<div><span style='color:{c};font-size:9px;'>{etiqueta}{sufijo}</span><br>"
            f"<span class='lcd-text' style='color:{c};font-size:16px;'>{texto}</span>{pie}</div>")


def evaluar_cama(estadia_id, t_s, registrar=True, cama_id=None):
    snap = base.snapshot(estadia_id, t_s)
    alarmas = reglas.evaluar(snap, umbrales_actuales(), base)
    if registrar and cama_id is not None:
        P.sincronizar_alarmas(corrida, cama_id, t_s, alarmas)
    return snap, alarmas, reglas.estado_cama(alarmas)


# ==============================================================================
# BARRA LATERAL
# ==============================================================================
_sb_cab.markdown("<h2 style='color: #FFF; font-weight: 300; letter-spacing: 1px;'>SISTEMA CENTRAL</h2>", unsafe_allow_html=True)
_sb_cab.markdown("<p style='color:#888; font-size:10px; font-weight:bold;'>SESION ACTIVA</p>", unsafe_allow_html=True)
_sb_cab.info(operador)
if _sb_cab.button("CERRAR SESION OPERATIVA", use_container_width=True):
    P.cerrar_todas(corrida, reloj.t_s)
    for clave in ("autenticado", "profesional_activo", "corrida_id", "reloj", "hora_inicio_real"):
        st.session_state.pop(clave, None)
    st.rerun()

_sb_cab.markdown("---")
modo_vista = _sb_cab.radio("MODO DE OPERACION", ["MONITOREO CLINICO", "GESTION DE CAMAS (ADT)", "INDICADORES DE GESTION",
                                                    "AYUDA"])

_sb_reloj.markdown("---")
_sb_reloj.markdown("<p style='color:#888; font-size:10px; font-weight:bold;'>RELOJ DE SIMULACION</p>", unsafe_allow_html=True)
cb1, cb2 = _sb_reloj.columns(2)
if cb1.button("PAUSA" if reloj.corriendo else "INICIAR", use_container_width=True):
    reloj.pausar() if reloj.corriendo else reloj.iniciar()
    st.rerun()
if cb2.button("REINICIAR", use_container_width=True):
    P.cerrar_todas(corrida, reloj.t_s)
    st.session_state.corrida_id = P.nueva_corrida(operador)
    reloj.reiniciar()
    st.session_state.hora_inicio_real = datetime.now().replace(microsecond=0)
    st.rerun()
velocidad = _sb_reloj.select_slider("VELOCIDAD (x tiempo real)", options=rl.VELOCIDADES, value=reloj.velocidad)
reloj.velocidad = velocidad
salto = _sb_reloj.number_input("Ir al segundo (0 a %d)" % base.duracion_s, min_value=0, max_value=int(base.duracion_s),
                                value=int(reloj.t_s), step=30)
if _sb_reloj.button("IR", use_container_width=True):
    reloj.ir_a(salto)
    st.rerun()


ocup = ocupacion_actual()
camas_ocupadas = [c for c, e in ocup.items() if e is not None]
camas_libres = [c for c, e in ocup.items() if e is None]

# ==============================================================================
# MODO: GESTIÓN DE CAMAS (ADT)
# ==============================================================================
if modo_vista == "GESTION DE CAMAS (ADT)":
    st.markdown("<h3 style='color: #FFF; font-weight: 300;'>GESTION DE INGRESOS, EGRESOS Y TRASLADOS (ADT)</h3>", unsafe_allow_html=True)
    col_adm, col_estado = st.columns([1.5, 1])
    with col_adm:
        st.markdown("<p style='color:#888; font-size:12px; font-weight:bold;'>MODIFICACION DE ESTADO DEL PACIENTE</p>", unsafe_allow_html=True)
        accion = st.radio("TIPO DE ORDEN HIS", ["INGRESAR PACIENTE", "LIBERAR CAMA (ALTA/OBITO)"], horizontal=True)
        st.markdown("<hr style='border-color: #222; margin-top: 5px; margin-bottom: 15px;'>", unsafe_allow_html=True)

        if accion == "INGRESAR PACIENTE":
            sin_cama = [e for e in base.ids_estadias() if e not in ocup.values()]
            if not camas_libres:
                st.error("ALERTA DE CAPACIDAD: La Unidad se encuentra con 100% de ocupación.")
            elif not sin_cama:
                st.info("No hay pacientes del banco de pruebas pendientes de ingreso. Libere una cama primero.")
            else:
                with st.form("form_ingreso"):
                    cama_sel = st.selectbox("Seleccionar Box Disponible", camas_libres, format_func=box)
                    est_sel = st.selectbox("Paciente del banco de pruebas", sin_cama,
                                           format_func=lambda e: f"Paciente {base.ficha(e)['subject_id']} | {base.descripcion(e)}")
                    if st.form_submit_button("EJECUTAR INGRESO"):
                        P.registrar_orden_adt(corrida, reloj.t_s, cama_sel, est_sel, operador, "ingreso")
                        st.success(f"ORDEN EJECUTADA: ingreso registrado en {box(cama_sel)}.")
                        time.sleep(1)
                        st.rerun()
        else:
            if not camas_ocupadas:
                st.info("La Unidad se encuentra actualmente sin pacientes activos.")
            else:
                # [integración] Sin st.form: la casilla de confirmación aparece apenas se elige Óbito.
                # El contador en las claves reinicia los campos después de cada egreso.
                n_eg = st.session_state.setdefault("contador_egresos", 0)
                with st.container(border=True):
                    cama_sel = st.selectbox("Seleccionar Box Ocupado", camas_ocupadas, format_func=box, key=f"eg_cama_{n_eg}")
                    motivo = st.selectbox("Motivo", ["Alta", "Óbito", "Traslado"], key=f"eg_motivo_{n_eg}")
                    confirma_obito = False
                    if motivo == "Óbito":
                        confirma_obito = st.checkbox("Confirmo que el egreso es por ÓBITO", key=f"eg_confirma_{n_eg}")
                    if st.button("EJECUTAR ALTA / EGRESO", key=f"eg_boton_{n_eg}"):
                        # Un óbito mal cargado distorsiona la mortalidad: exige confirmación explícita
                        if motivo == "Óbito" and not confirma_obito:
                            st.error("Para registrar un ÓBITO debe tildar la casilla de confirmación. No se realizó ningún cambio.")
                        else:
                            P.registrar_orden_adt(corrida, reloj.t_s, cama_sel, None, operador, motivo.lower())
                            st.session_state.contador_egresos = n_eg + 1
                            st.success(f"ORDEN EJECUTADA: {box(cama_sel)} liberada correctamente ({motivo}).")
                            time.sleep(1)
                            st.rerun()
        ordenes = P.ordenes_adt(corrida)
        if not ordenes.empty:
            st.markdown("<p style='color:#888; font-size:12px; font-weight:bold; margin-top:20px;'>ORDENES DE LA SIMULACION</p>", unsafe_allow_html=True)
            st.dataframe(ordenes, use_container_width=True, hide_index=True)
    with col_estado:
        st.markdown("<p style='color:#888; font-size:12px; font-weight:bold;'>ESTADO ACTUAL DE OCUPACION</p>", unsafe_allow_html=True)
        st.metric("CAMAS DISPONIBLES", f"{len(camas_libres)} / {base.total_camas}")
        st.code("[ PROTOCOLO HIGIENE ]\nCama liberada requiere\n120 min de desinfección\nantes de nuevo ingreso.", language="yaml")

# ==============================================================================
# MODO: INDICADORES DE GESTIÓN
# ==============================================================================
elif modo_vista == "INDICADORES DE GESTION":
    st.markdown("<h3 style='color: #FFF; font-weight: 300;'>PANEL GERENCIAL DE UNIDAD</h3>", unsafe_allow_html=True)
    tab_ind, tab_eq = st.tabs(["[1] PANEL GENERAL", "[2] TRAZABILIDAD DE EQUIPAMIENTO"])
    with tab_ind:
        datos_rrhh = P.dotacion()
        t_actual = reloj.t_s
        dias = [base.dias_estancia(e, t_actual) for e in ocup.values() if e is not None]
        dias = [d for d in dias if d is not None]
        eventos = P.eventos(corrida)
        activas = int(eventos["t_fin_s"].isna().sum()) if not eventos.empty else 0

        c1, c2, c3, c4 = st.columns(4)
        c1.metric("OCUPACION", f"{len(camas_ocupadas)} / {base.total_camas}", f"{100 * len(camas_ocupadas) / base.total_camas:.0f}%")
        c2.metric("ESTANCIA HASTA AHORA (PROMEDIO)", f"{np.mean(dias):.1f} días" if dias else "—")
        c3.metric("ALARMAS ACTIVAS", activas)
        c4.metric("ALARMAS REGISTRADAS", len(eventos))
        sc_unidad = [SC.calcular(base, e, t_actual) for e in ocup.values() if e is not None]
        news_u = [r["news2"]["valor"] for r in sc_unidad if r["news2"]["valor"] is not None]
        sofa_u = [r["sofa"]["valor"] for r in sc_unidad if r["sofa"]["valor"] is not None]
        g1, g2, g3, g4 = st.columns(4)
        g1.metric("CAMAS CON NEWS2 ≥ 5", sum(1 for n in news_u if n >= 5))
        g2.metric("NEWS2 PROMEDIO", f"{np.mean(news_u):.1f}" if news_u else "—")
        g3.metric("CAMAS CON qSOFA POSITIVO", sum(1 for r in sc_unidad if (r["qsofa"]["valor"] or 0) >= 2))
        g4.metric("SOFA PARCIAL PROMEDIO (≥)", f"{np.mean(sofa_u):.1f}" if sofa_u else "—")
        st.caption("Indicadores clínicos de gravedad al instante simulado actual; el detalle por cama está en MONITOREO CLINICO > "
                   "[3] TABLERO DE GRAVEDAD.")
        st.info("Mortalidad, estancia media histórica y rotación de camas requieren estadías históricas cargadas "
                "en la base; con las 15 camas del banco de pruebas no se pueden calcular y no se muestran valores inventados.")
        st.markdown("<hr style='border-color: #222;'>", unsafe_allow_html=True)

        st.markdown("<p style='color:#888; font-size:12px; font-weight:bold;'>ALARMAS DE LA SIMULACION</p>", unsafe_allow_html=True)
        if eventos.empty:
            st.caption("Aún no hay alarmas registradas. Se registran mientras el modo MONITOREO CLINICO está abierto y la simulación avanza.")
        else:
            resumen = eventos.groupby(["nivel"]).size().rename("cantidad").reset_index()
            por_cama = eventos.groupby("cama_id").size().rename("alarmas").reset_index()
            reconocidos = eventos.dropna(subset=["t_reconocido_s"])
            ca, cb, cc = st.columns(3)
            ca.dataframe(resumen, hide_index=True, use_container_width=True)
            cb.dataframe(por_cama, hide_index=True, use_container_width=True)
            cc.metric("TIEMPO MEDIO HASTA RECONOCER", f"{(reconocidos['t_reconocido_s'] - reconocidos['t_inicio_s']).mean():.0f} s"
                      if not reconocidos.empty else "—")
            st.markdown("<hr style='border-color: #222;'>", unsafe_allow_html=True)

        if enlace is not None:
            st.markdown("<p style='color:#888; font-size:12px; font-weight:bold;'>CALIDAD DE DATOS DEL ENLACE (EMISORES → RECEPTOR)</p>", unsafe_allow_html=True)
            res_enlace = enlace.resumen()
            q1, q2, q3, q4 = st.columns(4)
            q1.metric("PAQUETES RECIBIDOS", res_enlace["paquetes_recibidos"])
            q2.metric("MEDIDAS ACEPTADAS", res_enlace["medidas_aceptadas"])
            q3.metric("MEDIDAS RECHAZADAS", res_enlace["medidas_rechazadas"])
            q4.metric("EVENTOS DE CALIDAD", res_enlace["eventos_de_calidad"])
            ev_cal = base.tabla_eventos()
            if ev_cal.empty:
                st.caption("El receptor no registró eventos de calidad hasta el instante simulado.")
            else:
                por_tipo = ev_cal.groupby(["tipo", "cama"]).size().rename("cantidad").reset_index().sort_values(["tipo", "cama"])
                cq1, cq2 = st.columns([1, 1.4])
                cq1.dataframe(por_tipo, hide_index=True, use_container_width=True, height=min(60 + 36 * len(por_tipo), 360))
                cq2.dataframe(ev_cal[ev_cal["tipo"] != "rechazo_rango"].drop(columns=["abierto_al_final"], errors="ignore").tail(40),
                              hide_index=True, use_container_width=True, height=360)
                st.caption("«rechazo_rango»: valor imposible que el receptor no guarda (p. ej. SpO2 = 0). A la derecha, los demás eventos "
                           "(congelado, sin actualización, pérdida de comunicación, duplicado, fuera de orden).")
            st.markdown("<hr style='border-color: #222;'>", unsafe_allow_html=True)

        if es_jefatura:
            st.markdown("<hr style='border-color: #222;'>", unsafe_allow_html=True)
            st.markdown("<p style='color:#888; font-size:12px; font-weight:bold;'>RECURSOS HUMANOS Y PERSONAL (JEFATURA)</p>", unsafe_allow_html=True)
            col_form, col_log = st.columns(2)
            with col_form:
                st.markdown("<p style='color:#888; font-size:12px; font-weight:bold;'>ACTUALIZAR PARAMETROS DE DOTACION</p>", unsafe_allow_html=True)
                with st.form("form_rrhh"):
                    enf = st.number_input("Enfermeros de Turno", value=int(datos_rrhh["enfermeros"]), min_value=1, max_value=20)
                    med = st.number_input("Médicos Intensivistas", value=int(datos_rrhh["medicos"]), min_value=1, max_value=10)
                    kin = st.number_input("Kinesiólogos", value=int(datos_rrhh["kinesiologos"]), min_value=0, max_value=10)
                    hs = st.number_input("Horas Promedio del Turno", value=float(datos_rrhh["horas_turno"]), format="%.1f")
                    if st.form_submit_button("ACTUALIZAR BASE DE DATOS RRHH"):
                        P.guardar_dotacion(enf, med, kin, hs, operador)
                        st.success("SISTEMA ACTUALIZADO")
                        time.sleep(1)
                        st.rerun()
            with col_log:
                st.markdown("<p style='color:#888; font-size:12px; font-weight:bold;'>ESTADO ACTUAL RRHH</p>", unsafe_allow_html=True)
                ratio_ref = base.parametros.get("ratio_enfermero_paciente", "1:2")
                try:
                    maximo = float(ratio_ref.split(":")[1]) / float(ratio_ref.split(":")[0])
                except Exception:
                    maximo = 2.0
                pac = len(camas_ocupadas)
                ratio_enf = pac / datos_rrhh["enfermeros"] if datos_rrhh["enfermeros"] > 0 else 0
                st.code(f"""[ DOTACION DECLARADA ]
    Enfermeros : {datos_rrhh['enfermeros']} (Ratio 1:{ratio_enf:.1f})
    Médicos    : {datos_rrhh['medicos']}
    Kinesio.   : {datos_rrhh['kinesiologos']}
    Turno (hs) : {datos_rrhh['horas_turno']}

    [ COMPLIANCE NORMATIVO ] (referencia {ratio_ref})
    Ratio Enfermería : {'OPTIMO' if ratio_enf <= maximo else 'SOBRECARGA DETECTADA'}""", language="yaml")

    with tab_eq:
        inv = P.equipos()
        col_act1, col_act2 = st.columns([1.5, 1])
        with col_act1:
            st.markdown("<p style='color:#888; font-size:12px; font-weight:bold;'>TRASLADO DE EQUIPAMIENTO</p>", unsafe_allow_html=True)
            if es_bioingenieria:
                with st.form("form_activos"):
                    eq_id = st.selectbox("Seleccionar ID del Equipo", inv["equipo_id"].tolist())
                    nueva_ub = st.selectbox("Destino del Traslado", ["DEPOSITO", "BIOINGENIERIA"] + [box(i) for i in range(1, base.total_camas + 1)])
                    obs = st.text_input("Observación / Motivo (Obligatorio si salida a Depósito/Bioingeniería)")
                    if st.form_submit_button("REGISTRAR MOVIMIENTO"):
                        if nueva_ub in ["DEPOSITO", "BIOINGENIERIA"] and not obs:
                            st.error("ERROR: Debe ingresar el motivo.")
                        else:
                            P.mover_equipo(eq_id, nueva_ub, obs, operador)
                            st.success(f"MOVIMIENTO REGISTRADO: {eq_id} trasladado.")
                            time.sleep(1)
                            st.rerun()
            else:
                st.warning("ACCESO RESTRINGIDO: Solo el personal de Bioingeniería o Jefatura puede registrar movimientos de equipamiento.")
        with col_act2:
            st.markdown("<p style='color:#888; font-size:12px; font-weight:bold;'>MAPA DE ACTIVOS POR UBICACION</p>", unsafe_allow_html=True)
            filtro = st.selectbox("Filtrar inventario por:", ["DEPOSITO", "BIOINGENIERIA"] + [box(i) for i in range(1, base.total_camas + 1)])
            filtrados = inv[inv["ubicacion"] == filtro]
            if filtrados.empty:
                st.info(f"No hay equipos en {filtro}.")
            for r in filtrados.itertuples():
                borde = "#3498DB" if "Monitor" in r.tipo else "#2ECC71"
                st.markdown(f"""
                <div style="background-color: #121212; border-left: 3px solid {borde}; padding: 10px; margin-bottom: 8px;">
                    <span style="color:#FFF; font-size:12px; font-weight:bold;">{r.equipo_id}</span><br>
                    <span style="color:#888; font-size:10px;">{r.marca} {r.modelo} | SN: {r.sn}</span>
                </div>""", unsafe_allow_html=True)
        st.markdown("<hr style='border-color: #222;'>", unsafe_allow_html=True)
        st.markdown("<p style='color:#888; font-size:12px; font-weight:bold;'>TRAZABILIDAD HISTORICA DEL EQUIPO</p>", unsafe_allow_html=True)
        eq_hist = st.selectbox("Consultar hoja de vida técnica de:", inv["equipo_id"].tolist(), key="eq_hoja_vida")
        hist = P.historial_equipo(eq_hist)
        if hist.empty:
            st.info("Este equipo todavía no tiene movimientos registrados.")
        else:
            st.code("\n".join(f"{r.registrado} | {r.accion} | {r.detalle} ({r.operador})" for r in hist.itertuples()), language="yaml")

# ==============================================================================
# MODO: AYUDA
# ==============================================================================
elif modo_vista == "AYUDA":
    st.markdown("<h3 style='color: #FFF; font-weight: 300;'>AYUDA · QUÉ OFRECE LA PLATAFORMA</h3>", unsafe_allow_html=True)
    st.caption("Guía breve. Cada sección se despliega con un clic.")

    with st.expander("1. Qué es esta plataforma", expanded=True):
        st.markdown(f"""
Es una **central de monitoreo virtual de una UTI** con **{base.total_camas} camas**. Recibe datos biomédicos simulados a partir de un
banco de pruebas armado con registros reales anonimizados (MIMIC-III), los muestra en tiempo simulado y permite
seguir a cada paciente **desde su ingreso hasta el final de su estancia**.

Ofrece, en una sola pantalla:
- **Monitoreo en vivo** de frecuencia cardíaca, presión arterial, SpO2 y frecuencia respiratoria, con la señal continua (ECG, presión arterial invasiva, pletismografía).
- **Alarmas** con registro de eventos y reconocimiento por el operador.
- **Indicadores clínicos de gravedad** (NEWS2, qSOFA, SOFA, APACHE II, índice de shock, oxigenación).
- **Gestión de camas** (ingresos, altas, traslados) e **indicadores de gestión** de la unidad.

Origen de los datos: **{origen}** (`{base_real.ruta.name}`) · {len(base.estadias)} estadías · el reloj de simulación recorre un tramo de {base.duracion_s / 60:.0f} minutos
con hasta 24 h de historia previa por paciente.
""")

    with st.expander("2. Reloj de simulación (barra lateral)"):
        st.markdown(f"""
- **INICIAR / PAUSA**: el tiempo simulado avanza o se detiene. Con el reloj en pausa la pantalla muestra siempre el mismo instante.
- **VELOCIDAD**: de x1 (tiempo real) hasta x{max(rl.VELOCIDADES)}.
- **Ir al segundo**: salta a un instante del tramo (0 a {int(base.duracion_s)} s) y **IR** lo aplica.
- **REINICIAR**: cierra la corrida actual y empieza otra desde el segundo 0.
- Lo que se muestra **nunca incluye datos posteriores al instante simulado**: la plataforma sólo ve lo que un monitor real habría visto hasta ese momento.
""")

    with st.expander("3. Monitoreo clínico: tres vistas"):
        st.markdown("""
**[1] Visión general de la unidad.** Una tarjeta por box con FC, PAM (invasiva `INV` o no invasiva `NI`), SpO2 y FR. La flecha junto a FC
indica la tendencia de la última hora. El **color del borde** resume el estado de alarmas; abajo de cada tarjeta se ve la alarma principal
y el **NEWS2** del paciente. Un valor atenuado con «hace X min» es un dato viejo (el sensor no lo actualiza).

**[2] Análisis detallado (vista micro).** Se elige el paciente en la barra lateral. Muestra los cuatro signos vitales, la **lectura de la
frecuencia cardíaca** (banda, tendencia y posibles causas a evaluar), la **señal continua** de los últimos 8 s, los **indicadores
clínicos** con su detalle, la **tendencia de 2 horas**, el **laboratorio** y las **alarmas de la cama**.

**[3] Tablero de gravedad.** Una fila por paciente con todos los indicadores, ordenada por NEWS2: sirve para decidir a quién mirar primero.
""")

    with st.expander("4. Alarmas y registro de eventos"):
        umb = reglas.especificacion(base)["umbrales"]
        filas_umb = "\n".join(f"| {r.mensaje.title()} | {r.variable.upper()} {r.condicion} {r.umbral:g} | {r.nivel} | {r.referencia} |"
                               for r in umb.itertuples())
        st.markdown(f"""
Las reglas se evalúan en **todas las camas en cada paso**, aunque se esté mirando una sola. Los umbrales están en
`umbrales_validacion.csv` (la misma especificación con la que se arma la verdad de referencia del benchmark):

| Alarma | Condición | Nivel | Referencia |
|---|---|---|---|
{filas_umb}

- **Persistencia:** una alarma desde el monitor exige que la condición se cumpla en **2 muestras seguidas**; una medición
  manual (presión no invasiva) alcanza por sí sola. Las reglas combinadas (shock, insuficiencia respiratoria) exigen todas sus condiciones.
- **Fallas técnicas** (cian, borde punteado): sensor desconectado (valor 0), valor fuera de rango (`-?-`), dato vencido,
  FR = 0 con SpO2 normal (posible pérdida de señal respiratoria) y PVC congelada en 0. Cada una tiene prioridad alta, media o baja
  según lo que se deja de vigilar (IEC 60601-1-8) y **no tapa** la alarma clínica.
- Un valor inválido nunca se muestra como número ni se usa para alarmar ni para los peores valores de 8 h.

Estados de una cama: **CRITICA**, **ADVERTENCIA**, **REQUIERE REVISION** (solo fallas técnicas) o parámetros en rango. Cada alarma
queda registrada con su inicio y fin; el operador la **reconoce** desde la vista micro y el tiempo hasta el reconocimiento alimenta
los indicadores de gestión.
""")

    with st.expander("5. Indicadores clínicos: qué miden y cómo leerlos"):
        st.markdown("""
| Indicador | Qué mide | Cómo leerlo |
|---|---|---|
| **NEWS2** | Alerta temprana de deterioro a partir de 7 parámetros (FR, SpO2, oxígeno, presión sistólica, FC, conciencia, temperatura). | 0-4 bajo · 5-6 medio · ≥ 7 alto. Un solo parámetro con 3 puntos pide revisión urgente aunque el total sea bajo. |
| **qSOFA** | Tamizaje rápido de riesgo en sospecha de sepsis (FR ≥ 22, PAS ≤ 100, alteración mental). | ≥ 2 puntos = positivo. No descarta sepsis si es negativo. |
| **SOFA parcial** | Disfunción de 6 órganos (respiración, coagulación, hígado, circulación, sistema nervioso, riñón) con el peor valor de 24 h. | ≥ 2 puntos sugiere disfunción orgánica. Es un **valor mínimo** («≥»). |
| **APACHE II parcial** | Gravedad por fisiología aguda (temperatura, PAM, FC, FR, oxigenación, creatinina, Glasgow) más edad. | Puntos acumulados sobre los ítems disponibles; **no** se convierte en mortalidad. |
| **Índice de shock** | FC / presión sistólica (y FC / PAM). | Normal ≈ 0,5-0,7 · ≥ 0,9 elevado · ≥ 1,0 alto. |
| **Oxigenación** | P/F (PaO2 / FiO2) con gasometría; S/F (SpO2 / FiO2) como estimación; ROX orientativo. | P/F < 300 leve · < 200 moderada · < 100 severa. |

**Sobre el NEWS2 en UTI.** La escala fue diseñada para salas generales; en terapia intensiva los puntajes basales suelen ser más altos (oxígeno suplementario, presión invasiva, pacientes añosos), por eso se lo usa como orden de prioridad entre camas y como tendencia de cada paciente, más que como umbral absoluto.

**Por qué SOFA y APACHE II son parciales.** La base de pruebas no incluye vasopresores, diuresis, pH, sodio, potasio, hematocrito, leucocitos,
PaCO2 ni antecedentes crónicos. Cada indicador indica **qué componentes tiene y cuáles faltan**; con faltantes el resultado es un piso («≥ X»), no el valor
completo. Son herramientas de apoyo a la lectura, no un diagnóstico.
""")

    with st.expander("6. Antigüedad, confianza y datos descartados"):
        st.markdown("""
- **Vigencia**: un dato de monitor se considera «en vivo» hasta 5 minutos; la presión no invasiva, hasta 60 minutos; los otros signos cargados por enfermería (temperatura, Glasgow, FiO2), hasta 4 horas;
  el laboratorio, hasta 24 horas. Más allá, el dato se atenúa y se indica «hace X».
- **Confianza** de un indicador: **alta** (datos vigentes y laboratorio de hasta 24 h), **media** (laboratorio de 24 a 48 h o signos manuales de 4 a 8 h),
  **baja** (laboratorio de 48 a 72 h). Un laboratorio de más de 72 h no se usa.
- **Datos descartados**: valores fuera de rango fisiológico (por ejemplo una temperatura de 98,6 °C por cargarse en °F, o una FiO2 de 0,4 en lugar de 40 %) no entran en los
  cálculos; la vista micro avisa cuáles se descartaron.
- **Conciencia en el NEWS2**: la base registra Glasgow, no ACVPU. Se toma Glasgow 15 como «alerta» y menor como «no alerta»; en pacientes intubados se evalúa con respuesta ocular y motora.
""")

    with st.expander("7. Gestión de camas (ADT) e indicadores de gestión"):
        st.markdown("""
**Gestión de camas (ADT).** Registra **ingresos**, **altas, óbitos y traslados**, y muestra la ocupación. Las órdenes quedan guardadas en la corrida de simulación.

**Indicadores de gestión.** Ocupación, estancia hasta el momento, alarmas activas y registradas, tiempo medio hasta reconocer una alarma, y el resumen de gravedad clínica de la unidad
(camas con NEWS2 ≥ 5, NEWS2 promedio, qSOFA positivos, SOFA parcial promedio). Con el perfil de **Jefatura** se edita la dotación de personal y se controla el ratio enfermería-paciente;
Todo lo relativo a equipos está en su propia pestaña, **[2] TRAZABILIDAD DE EQUIPAMIENTO**: **Bioingeniería** y **Jefatura** registran movimientos, y se consulta la ubicación de cada equipo y su hoja de vida.
La mortalidad y la rotación de camas requieren estadías históricas que el banco de 15 camas no tiene, por eso no se muestran valores inventados.
""")

    with st.expander("8. Origen de los datos: base de datos o emisores virtuales"):
        st.markdown("""
En la barra lateral, **ORIGEN DE LOS DATOS** elige de dónde se alimenta la central:
- **BASE DE DATOS**: lee `benchmark_uti.db` directamente (solo lectura).
- **EMISORES VIRTUALES**: cada cama es un emisor que publica un paquete por minuto simulado. Los paquetes viajan por un **canal** y los
  recibe un **receptor**, que los valida (rango, duplicados, orden, datos congelados, falta de actualización, pérdida de comunicación),
  los ordena y los guarda **solo en memoria**. Las reglas, los indicadores y las pantallas son las mismas; la base no se modifica.
  - **Reproducción de la base**: las 15 camas reales pasan por el canal. Se conserva la señal continua del tramo.
  - **Sintético por escenarios**: camas generadas (estable, deterioro hemodinámico, desaturación) con una semilla; no tienen señal continua.
  - **Fallas de transmisión de demostración**: congelado (cama 3), caída de SpO2 (cama 5), valor imposible (cama 7), pérdida de comunicación (cama 9),
    retraso (cama 11) y duplicado (cama 12). Se ven como alarmas técnicas y en INDICADORES DE GESTION > calidad de datos del enlace.
- El receptor **rechaza los valores imposibles** (por ejemplo SpO2 = 0). Por eso, con emisores, una desconexión de sensor puede verse como «sin señal» o «dato viejo» en lugar de «sensor desconectado».
- Cambiar de origen reinicia la corrida y el reloj al segundo 0.
""")

    with st.expander("9. Alcance y limitaciones"):
        st.markdown("""
- Es una **plataforma de investigación y validación** (proyecto de tesis): los datos son simulados a partir de registros anonimizados y **no es un dispositivo médico**.
- Las lecturas e indicadores **apoyan** la observación clínica; no reemplazan el criterio profesional ni el diagnóstico.
- Las alarmas siguen la especificación `umbrales_validacion.csv`; las adaptaciones de NEWS2 a la UTI están documentadas y en revisión con el asesor.
- SOFA y APACHE II son **parciales** por los datos que no están en la base; se informa siempre su cobertura.
""")

# ==============================================================================
# MODO: MONITOREO CLÍNICO
# ==============================================================================
else:
    st.sidebar.markdown("---")
    cama_foco = st.sidebar.selectbox("PACIENTE EN FOCO (VISTA MICRO)", camas_ocupadas if camas_ocupadas else [None],
                                     format_func=lambda c: "SIN PACIENTES" if c is None else box(c), key="cama_foco")


    def figura_senal(estadia_id, t_s, ventana_s=8.0):
        info = base.info_tramo(estadia_id)
        if info is None:
            return None, "Esta cama no tiene señal continua registrada."
        if t_s < 1.0:
            return None, "Inicie la simulación para ver la señal continua (el tramo comienza en el segundo 0)."
        try:
            tramo = RITMO.tramo(estadia_id, info["ruta"])
            datos = tramo.ventana(max(0.0, t_s - ventana_s), t_s)
        except Exception as error:
            return None, f"No se pudo leer la señal: {error}"
        colores = {"II": "#2ECC71", "ABP": "#E74C3C", "PLETH": "#3498DB"}
        NOMBRE_CANAL = {"II": "ECG II", "ABP": "PA invasiva", "PLETH": "Pletismografía"}
        unidad = dict(zip(tramo.canales, tramo.unidades))
        fig = make_subplots(rows=len(datos), cols=1, shared_xaxes=True, vertical_spacing=0.04)
        for i, (canal, (t, y)) in enumerate(datos.items(), start=1):
            fig.add_trace(go.Scatter(x=t, y=y, mode="lines", line=dict(width=1.3, color=colores.get(canal.upper(), "#AAA")),
                                     name=canal, connectgaps=False), row=i, col=1)
            fig.update_yaxes(title_text=f"{NOMBRE_CANAL.get(canal.upper(), canal)} [{unidad.get(canal, '')}]", gridcolor="#222", color="#888", row=i, col=1)
        fig.update_xaxes(gridcolor="#222", color="#888", title_text="tiempo [s]", row=len(datos), col=1)
        fig.update_layout(plot_bgcolor="#121212", paper_bgcolor="#121212", height=110 * len(datos) + 60,
                          margin=dict(t=10, b=10, l=10, r=10), showlegend=False)
        return fig, None


    def serie_fc(estadia_id, t_s, ventana_s=7200.0):
        """Serie de FC de la ventana (sólo datos hasta t_s). Se prefiere la serie minuto a minuto del monitor."""
        s = base.serie(estadia_id, "fc", t_s - ventana_s, t_s).dropna(subset=["valor"])
        minuto = s[s["fuente"] == "numericos"]
        return minuto if len(minuto) >= 8 else s


    def html_lectura_fc(lectura):
        filas = "".join(
            f"<p style='margin:0 0 7px 0; font-size:12px; color:#BBB;'><span style='color:{c}; font-weight:bold;'>{rot}:</span> {txt}</p>"
            for rot, txt, c in lectura["puntos"])
        return (f"<div class='metric-box' style='border-color:{lectura['color']};'>"
                f"<p class='lcd-lbl'>Lectura de la frecuencia cardíaca</p>"
                f"<p style='margin:4px 0 10px 0; font-size:16px; font-weight:bold; color:{lectura['color']};'>{lectura['resumen']}</p>"
                f"{filas}"
                f"<p style='margin:6px 0 0 0; font-size:9px; color:#666;'>Rangos de referencia de adulto; es un apoyo a la lectura, "
                f"no un diagnóstico. Valores de FC del monitor, un dato por minuto.</p></div>")


    def figura_tendencias(estadia_id, snap, t_s, horas=2.0):
        var_pam = "pa_inv_media" if snap["pa_origen"] == "INV" else "pa_ni_media"
        series = [("FC [lpm]", "fc", "#2ECC71"), ("PAM [mmHg]", var_pam, "#E74C3C"), ("SpO2 [%]", "spo2", "#3498DB")]
        fig = make_subplots(rows=3, cols=1, shared_xaxes=True, vertical_spacing=0.05)
        for i, (titulo, var, color) in enumerate(series, start=1):
            s = base.serie(estadia_id, var, t_s - horas * 3600, t_s).dropna(subset=["valor"])
            fig.add_trace(go.Scatter(x=s["t_s"] / 60.0, y=s["valor"], mode="lines+markers",
                                     line=dict(width=1.2, color=color), marker=dict(size=3)), row=i, col=1)
            fig.update_yaxes(title_text=titulo, gridcolor="#222", color="#888", row=i, col=1)
        fig.update_xaxes(gridcolor="#222", color="#888", title_text="minuto de simulación", row=3, col=1)
        fig.update_layout(plot_bgcolor="#121212", paper_bgcolor="#121212", height=420,
                          margin=dict(t=10, b=10, l=10, r=10), showlegend=False)
        return fig


    def panel_clinico(snap):
        filas = []
        etiquetas = [("pao2", "PaO2", "mmHg"), ("fio2", "FiO2", "%"), ("dispositivo_o2", "Dispositivo O2", ""),
                     ("gcs", "Glasgow total", "pts"), ("temperatura", "Temperatura", "°C"),
                     ("creatinina", "Creatinina", "mg/dL"), ("bilirrubina_total", "Bilirrubina total", "mg/dL"),
                     ("plaquetas", "Plaquetas", "K/uL")]
        for clave, nombre, unidad in etiquetas:
            d = snap["datos"].get(clave)
            if d is None:
                filas.append({"Variable": nombre, "Valor": "—", "Unidad": unidad, "Antigüedad": "sin dato", "Origen": ""})
            else:
                valor = d.texto if (d.valor is None and d.texto) else num(d.valor, 1)
                filas.append({"Variable": nombre, "Valor": valor, "Unidad": unidad,
                              "Antigüedad": f"{d.antiguedad_s / 3600:.1f} h", "Origen": d.fuente})
        return pd.DataFrame(filas)


    def val_score(sc):
        return "—" if sc["valor"] is None else f"{'≥ ' if sc['minimo'] else ''}{sc['valor']}"


    def tarjeta_score(sc):
        """Tarjeta de un indicador: valor, nivel, lectura corta, cobertura de componentes y confianza."""
        etiqueta = sc.get("etiqueta", "")
        maximo = f" / {sc['max']}" if sc.get("max") else ""
        return (f"<div class='metric-box' style='border-color:{sc['color']}; margin-bottom:8px; min-height:165px;'>"
                f"<p class='lcd-lbl'>{html.escape(sc['nombre'])}</p>"
                f"<p class='lcd-val' style='color:{sc['color']};'>{val_score(sc)}"
                f"<span style='font-size:11px; color:#777; font-weight:normal;'> {html.escape(etiqueta)}{maximo}</span></p>"
                f"<p style='margin:2px 0 4px 0; font-size:11px; font-weight:bold; color:{sc['color']};'>{html.escape(sc['nivel'])}</p>"
                f"<p style='margin:0 0 4px 0; font-size:10px; color:#AAA;'>{html.escape(sc['interpretacion'])}</p>"
                f"<p style='margin:0; font-size:9px; color:#666;'>componentes {sc['cobertura']} · confianza {sc['confianza']}</p></div>")


    def texto_html(texto, color="#888", tam=12):
        """Texto plano seguro (sin que Streamlit lo interprete como markdown: $, <, *, _ ...)."""
        return f"<div style='color:{color}; font-size:{tam}px; margin:2px 0;'>{html.escape(str(texto))}</div>"


    def tabla_html(df):
        """Tabla estática en HTML: no usa el componente de grilla de Streamlit, que se redibuja y se desarma
        dentro del fragmento que se actualiza cada segundo."""
        cab = "".join(f"<th style='text-align:left; padding:4px 8px; border-bottom:1px solid #444; color:#AAA;'>{html.escape(str(c))}</th>"
                      for c in df.columns)
        cuerpo = "".join("<tr>" + "".join(f"<td style='padding:4px 8px; border-bottom:1px solid #222; color:#DDD; vertical-align:top;'>"
                                          f"{html.escape(str(v))}</td>" for v in fila) + "</tr>"
                         for fila in df.itertuples(index=False))
        return (f"<div style='overflow-x:auto; margin:4px 0 8px 0;'><table style='width:100%; border-collapse:collapse; font-size:12px;'>"
                f"<thead><tr>{cab}</tr></thead><tbody>{cuerpo}</tbody></table></div>")


    def mostrar_detalle(sc):
        st.markdown(f"<p style='margin:8px 0 2px 0; font-size:12px; font-weight:bold; color:{sc['color']};'>"
                    f"{html.escape(sc['nombre'])}: {html.escape(val_score(sc))} · {html.escape(sc['nivel'])}</p>", unsafe_allow_html=True)
        st.markdown(texto_html(sc["interpretacion"]), unsafe_allow_html=True)
        con_puntos = any(c["puntos"] is not None for c in sc["componentes"])
        filas = []
        for c in sc["componentes"]:
            fila = {"Componente": c["item"], "Valor": c["valor"]}
            if con_puntos:
                fila["Puntos"] = "—" if c["puntos"] is None else str(c["puntos"])
            fila.update({"Dato": c["edad"], "Ventana": c["ventana"], "Observación": c["nota"]})
            filas.append(fila)
        st.markdown(tabla_html(pd.DataFrame(filas)), unsafe_allow_html=True)
        if sc["limitaciones"]:
            st.markdown(texto_html("Limitaciones: " + " · ".join(sc["limitaciones"])), unsafe_allow_html=True)


    DETALLES = {"NEWS2": ["news2"], "qSOFA": ["qsofa"], "SOFA parcial": ["sofa"], "APACHE II parcial": ["apache"],
                "Shock y oxigenación": ["shock", "oxigenacion"]}


    def tablero_gravedad(ocupacion, t):
        """Una fila por cama ocupada con todos los indicadores, ordenada por NEWS2 (la más grave arriba)."""
        filas = []
        for cama, est in sorted(ocupacion.items()):
            if est is None:
                continue
            r = SC.calcular(base, est, t)
            ox = r["oxigenacion"]
            filas.append({
                "Box": box(cama), "Paciente": base.descripcion(est)[:34],
                "NEWS2": val_score(r["news2"]), "Nivel NEWS2": r["news2"]["nivel"],
                "qSOFA": val_score(r["qsofa"]), "Índice de shock": val_score(r["shock"]),
                "SOFA ≥": val_score(r["sofa"]).replace("≥ ", ""), "APACHE II ≥": val_score(r["apache"]).replace("≥ ", ""),
                "Oxigenación": "—" if ox["valor"] is None else f"{ox['etiqueta']} {ox['valor']}",
                "Confianza": r["sofa"]["confianza"],
                "_n": -1 if r["news2"]["valor"] is None else r["news2"]["valor"], "_r": r})
        if not filas:
            st.info("No hay pacientes ingresados.")
            return
        filas.sort(key=lambda f: -f["_n"])
        validos = [f["_r"] for f in filas]
        news = [r["news2"]["valor"] for r in validos if r["news2"]["valor"] is not None]
        sofa = [r["sofa"]["valor"] for r in validos if r["sofa"]["valor"] is not None]
        k1, k2, k3, k4 = st.columns(4)
        k1.metric("CAMAS CON NEWS2 ≥ 5", sum(1 for n in news if n >= 5))
        k2.metric("NEWS2 PROMEDIO", f"{np.mean(news):.1f}" if news else "—")
        k3.metric("CAMAS CON qSOFA POSITIVO", sum(1 for r in validos if (r["qsofa"]["valor"] or 0) >= 2))
        k4.metric("SOFA PARCIAL PROMEDIO (≥)", f"{np.mean(sofa):.1f}" if sofa else "—")
        tabla = pd.DataFrame([{k: v for k, v in f.items() if not k.startswith("_")} for f in filas])
        st.dataframe(tabla, hide_index=True, use_container_width=True, height=min(60 + 36 * len(tabla), 640))
        st.caption("«≥» indica valor mínimo: faltan componentes que la base no tiene (SOFA: vasopresores y diuresis; "
                   "APACHE II: pH, Na, K, hematocrito, leucocitos y enfermedad crónica) o datos vigentes. "
                   "No se estima mortalidad. Detalle de cada componente en la vista micro de la cama.")


    def vista_monitoreo():
        r = st.session_state.reloj
        r.avanzar()
        t = r.t_s
        if enlace is not None:
            enlace.avanzar(t)               # emisores -> canal -> receptor hasta el instante simulado
        ocupacion = ocupacion_actual()

        # Se evalúan TODAS las camas en cada paso (aunque se esté mirando una sola), para que el
        # registro de alarmas no dependa de la vista que esté abierta.
        evaluaciones = {}
        for cama_i, est_i in ocupacion.items():
            if est_i is None:
                P.sincronizar_alarmas(corrida, cama_i, t, [])
            else:
                evaluaciones[cama_i] = evaluar_cama(est_i, t, True, cama_i)

        estado_reloj = "EN CURSO x%s" % r.velocidad if r.corriendo else ("FINALIZADA" if t >= r.t_max else "EN PAUSA")
        st.markdown(f"<div style='color:#888; font-size:11px; letter-spacing:1px;'>HORA SIMULADA "
                    f"<span class='lcd-text' style='color:#FFF; font-size:15px;'>{st.session_state.get('hora_inicio_real', datetime.now().replace(microsecond=0)) + timedelta(seconds=float(t)):%d/%m/%Y %H:%M:%S}</span> "
                    f"&nbsp;|&nbsp; t = {t:.0f} s &nbsp;|&nbsp; {estado_reloj} &nbsp;|&nbsp; ORIGEN: {origen}</div>", unsafe_allow_html=True)
        if not hasattr(st, "fragment") and r.corriendo:
            st.warning("Esta versión de Streamlit no actualiza sola la pantalla: actualice con F5 o use IR.")

        vista = st.radio("VISTA", ["[1] VISION GENERAL DE LA UNIDAD", "[2] ANALISIS DETALLADO (VISTA MICRO)",
                                   "[3] TABLERO DE GRAVEDAD (INDICADORES CLINICOS)"],
                         horizontal=True, key="vista_mon", label_visibility="collapsed")

        # ---------------- Vista macro ----------------
        if vista.startswith("[1]"):
            cajas = sorted(ocupacion.items())
            for fila in range(3):
                cols = st.columns(5)
                for col_idx in range(5):
                    idx = fila * 5 + col_idx
                    if idx >= len(cajas):
                        continue
                    cama, estadia = cajas[idx]
                    if estadia is None:
                        cols[col_idx].markdown(f"""
                        <div style="background-color: #0A0A0A; border: 1px dashed #333; padding: 12px; border-radius: 4px; height: 120px; display: flex; align-items: center; justify-content: center;">
                            <span style="color:#444; font-size:12px; font-weight:bold;">{box(cama)} - DESOCUPADA</span>
                        </div>""", unsafe_allow_html=True)
                        continue
                    snap, alarmas, estado = evaluaciones[cama]
                    # [integración] La alarma clínica y la técnica se muestran por separado
                    clinica = reglas.principal_clinica(alarmas)
                    tec = reglas.tecnicas(alarmas)
                    ev = reglas.estado_valores(snap, base)
                    color = COLOR_ESTADO[estado]
                    trazo = "dashed" if estado == "REQUIERE REVISION" else "solid"
                    pie = (f"<div style='color:{COLOR_ESTADO[clinica['nivel']]};'>{clinica['mensaje']}</div>" if clinica else "")
                    pie += etiqueta_tecnica(tec)
                    if not pie:
                        pie = f"<div style='color:#777;'>{ETIQUETA_ESTADO['ESTABLE']}</div>"
                    d = snap["datos"]
                    sufijo_pa = f" {snap['pa_origen']}" if snap["pa_origen"] else ""
                    s_hr = serie_fc(estadia, t, VENTANA_TEND_S)
                    flecha_hr = " " + AF.flecha(AF.tendencia(s_hr["t_s"], s_hr["valor"], t)) if d['fc'] is not None and d['fc'].vigente else ""
                    n2 = SC.calcular(base, estadia, t, completo=False)["news2"]
                    linea_n2 = (f"NEWS2 {val_score(n2)} · {n2['nivel'].lower()}" if n2["valor"] is not None else "NEWS2 sin datos vigentes")
                    cols[col_idx].markdown(f"""
                    <div style="background-color: #121212; border: 1px {trazo} {color}; border-top: 3px {trazo} {color}; padding: 10px; border-radius: 2px;">
                        <div style="display: flex; justify-content: space-between; border-bottom: 1px solid #222; padding-bottom: 5px;">
                            <span style="font-weight:bold; color:#D4D4D4; font-size:11px;">{box(cama)}</span>
                            <span style="color:#777; font-size:9px;">{snap['diagnostico'][:22]}</span>
                        </div>
                        <div style="margin-top: 8px; display: grid; grid-template-columns: 1fr 1fr; gap: 4px;">
                            {valor_html('FC', mostrar(snap['fc'], ev['fc']), '#2ECC71', d['fc'], flecha_hr)}
                            {valor_html('PAM', mostrar(snap['pam'], ev['pam']), '#E74C3C', d['pa'], sufijo_pa)}
                            {valor_html('SpO2', mostrar(snap['spo2'], ev['spo2']), '#3498DB', d['spo2'])}
                            {valor_html('FR', mostrar(snap['fr'], ev['fr']), '#F1C40F', d['fr'])}
                        </div>
                        <div style="margin-top: 6px; font-size: 9px; font-weight: bold; text-align: center;">{pie}</div>
                        <div style="margin-top: 3px; font-size: 9px; color: {n2['color']}; text-align: center;">{linea_n2}</div>
                    </div>""", unsafe_allow_html=True)
            return

        # ---------------- Tablero de gravedad ----------------
        if vista.startswith("[3]"):
            st.markdown("<span style='color:#888; font-size:11px; font-weight:bold;'>INDICADORES CLÍNICOS DE TODAS LAS CAMAS (ordenado por NEWS2)</span>",
                        unsafe_allow_html=True)
            tablero_gravedad(ocupacion, t)
            return

        # ---------------- Vista micro ----------------
        cama = st.session_state.get("cama_foco")
        estadia = ocupacion.get(cama) if cama is not None else None
        if estadia is None:
            st.info("Seleccione un paciente en la barra lateral.")
            return
        snap, alarmas, estado = evaluaciones[cama]
        st.markdown(f"<h3 style='color:#FFF; font-weight:300; font-size: 16px;'>MONITOR INDIVIDUAL | "
                    f"<span style='color:#3498DB;'>{box(cama)}</span> | {snap['diagnostico']} | "
                    f"<span style='color:{COLOR_ESTADO[estado] if estado != 'ESTABLE' else '#2ECC71'};'>{estado}</span></h3>",
                    unsafe_allow_html=True)
        d = snap["datos"]
        ev = reglas.estado_valores(snap, base)
        # [integración] Lista de avisos activos: alarmas clínicas (color de su nivel) y fallas técnicas (cian)
        avisos = "".join(f"<span style='color:{COLOR_ESTADO[a['nivel']]}; font-weight:bold; margin-right:12px;'>{a['mensaje']}</span>"
                         for a in alarmas if not reglas.es_tecnica(a))
        avisos += "".join(f"<span style='background-color:{COLOR_TECNICO}; color:#000; font-weight:bold; padding:2px 6px; "
                          f"border-radius:2px; margin-right:8px;'>{a['mensaje'].replace('[REVISAR] ', '')}</span>"
                          for a in reglas.tecnicas(alarmas))
        if avisos:
            st.markdown(f"<div style='font-size:11px; margin-bottom:10px;'>{avisos}</div>", unsafe_allow_html=True)
        desc = snap.get("peor_descartados", {})
        nota = lambda k: f" ({desc[k]} desc.)" if desc.get(k) else ""
        s_fc = serie_fc(estadia, t)
        tend_fc = AF.tendencia(s_fc["t_s"], s_fc["valor"], t)
        banda_fc, color_banda = AF.banda_fc(snap["fc"] if ev["fc"] == reglas.VALIDO else None)
        if tend_fc is not None and d["fc"] is not None and d["fc"].vigente and ev["fc"] == reglas.VALIDO:
            linea_tend = (f"<p style='margin:2px 0 0 0; font-size:11px; color:{color_banda};'>{AF.flecha(tend_fc)} "
                          f"{tend_fc['pendiente_h']:+.0f} lpm/h (1 h) · {banda_fc}</p>")
        else:
            linea_tend = f"<p style='margin:2px 0 0 0; font-size:11px; color:{color_banda};'>{banda_fc or ''}</p>"
        c1, c2, c3, c4 = st.columns(4)
        pa_txt = (f"{mostrar(snap['pas'], ev['pas'])}/{mostrar(snap['pad'], ev['pad'])} "
                  f"<span style='font-size:16px;color:#A0A0A0;'>[{mostrar(snap['pam'], ev['pam'])}]</span>")
        c1.markdown(f"<div class='metric-box' style='border-color: #2ECC71;'><p class='lcd-lbl'>Frecuencia cardíaca [lpm]</p><p class='lcd-val' style='color:#2ECC71;'>{mostrar(snap['fc'], ev['fc'])}</p><p style='margin:0; font-size:9px; color:#777;'>Máx 8 h: {num(snap['peor_fc'])}{nota('fc')} {hace(d['fc'].antiguedad_s) if d['fc'] else ''}</p>{linea_tend}</div>", unsafe_allow_html=True)
        c2.markdown(f"<div class='metric-box' style='border-color: #E74C3C;'><p class='lcd-lbl'>Presión arterial [media] {snap['pa_origen'] or ''}</p><p class='lcd-val' style='color:#E74C3C;'>{pa_txt}</p><p style='margin:0; font-size:9px; color:#777;'>Mín 8 h: {num(snap['peor_pam'])}{nota('pam')} {hace(d['pa'].antiguedad_s) if d['pa'] else ''}</p></div>", unsafe_allow_html=True)
        c3.markdown(f"<div class='metric-box' style='border-color: #3498DB;'><p class='lcd-lbl'>SpO2 [%]</p><p class='lcd-val' style='color:#3498DB;'>{mostrar(snap['spo2'], ev['spo2'])}</p><p style='margin:0; font-size:9px; color:#777;'>Mín 8 h: {num(snap['peor_spo2'])}{nota('spo2')} {hace(d['spo2'].antiguedad_s) if d['spo2'] else ''}</p></div>", unsafe_allow_html=True)
        c4.markdown(f"<div class='metric-box' style='border-color: #F1C40F;'><p class='lcd-lbl'>Frecuencia respiratoria [rpm]</p><p class='lcd-val' style='color:#F1C40F;'>{mostrar(snap['fr'], ev['fr'])}</p><p style='margin:0; font-size:9px; color:#777;'>{hace(d['fr'].antiguedad_s) if d['fr'] else ''}</p></div>", unsafe_allow_html=True)

        # ---- Lectura de la FC (izquierda) y señal continua del tramo (derecha)
        dat_pa, dat_t = d["pa"], d["temperatura"]
        # [integración] La lectura solo recibe valores válidos: un 0 o un valor imposible no se interpreta como clínico.
        valido = lambda k: ev.get(k) == reglas.VALIDO
        lectura = AF.leer_fc(
            snap["fc"] if valido("fc") else None, bool(d["fc"] and d["fc"].vigente and valido("fc")),
            hace(d["fc"].antiguedad_s) if d["fc"] else "", tend_fc if valido("fc") else None,
            pam=snap["pam"] if dat_pa is not None and dat_pa.vigente and valido("pam") else None,
            pas=snap["pas"] if dat_pa is not None and dat_pa.vigente and valido("pas") else None,
            spo2=snap["spo2"] if d["spo2"] is not None and d["spo2"].vigente and valido("spo2") else None,
            temperatura=dat_t.valor if dat_t is not None and dat_t.vigente else None)
        col_lect, col_ondas = st.columns([2, 3])
        with col_lect:
            st.markdown(html_lectura_fc(lectura), unsafe_allow_html=True)
        with col_ondas:
            st.markdown("<span style='color:#888; font-size:11px; font-weight:bold;'>SEÑAL CONTINUA (125 Hz) · ÚLTIMOS 8 s</span>", unsafe_allow_html=True)
            fig, aviso = figura_senal(estadia, t)
            if fig:
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.caption(aviso)

        # ---- Indicadores clínicos
        st.markdown("<hr style='border-color: #222;'>", unsafe_allow_html=True)
        st.markdown("<span style='color:#888; font-size:11px; font-weight:bold;'>INDICADORES CLÍNICOS "
                    "(SOFA y APACHE II con el peor valor de las últimas 24 h; son parciales: ver el detalle)</span>",
                    unsafe_allow_html=True)
        res = SC.calcular(base, estadia, t)
        orden = ["news2", "qsofa", "shock", "sofa", "apache", "oxigenacion"]
        # Cada bloque está protegido: si un indicador falla se avisa en pantalla y el resto de la vista sigue armada.
        for fila in (orden[:3], orden[3:]):
            for col, clave in zip(st.columns(3), fila):
                try:
                    col.markdown(tarjeta_score(res[clave]), unsafe_allow_html=True)
                except Exception as error:
                    col.warning(f"No se pudo mostrar «{clave}»: {error}")
        detalle = st.radio("Detalle del indicador", list(DETALLES), horizontal=True, key="detalle_score",
                           label_visibility="collapsed")
        for clave in DETALLES[detalle]:
            try:
                mostrar_detalle(res[clave])
            except Exception as error:
                st.warning(f"No se pudo mostrar el detalle de «{clave}»: {error}")
        if res["descartes"]:
            st.markdown(texto_html("Datos descartados por estar fuera de rango fisiológico (posible error de carga o de unidad): "
                                   + "; ".join(res["descartes"])), unsafe_allow_html=True)
        st.markdown("<hr style='border-color: #222;'>", unsafe_allow_html=True)

        st.markdown("<span style='color:#888; font-size:11px; font-weight:bold;'>TENDENCIA (ÚLTIMAS 2 h)</span>", unsafe_allow_html=True)
        st.plotly_chart(figura_tendencias(estadia, snap, t), use_container_width=True)

        col_lab, col_ev = st.columns(2)
        with col_lab:
            st.markdown("<span style='color:#888; font-size:11px; font-weight:bold;'>LABORATORIO Y DATOS CLÍNICOS (ÚLTIMO VALOR)</span>", unsafe_allow_html=True)
            st.dataframe(panel_clinico(snap), hide_index=True, use_container_width=True)
        with col_ev:
            st.markdown("<span style='color:#888; font-size:11px; font-weight:bold;'>ALARMAS DE LA CAMA</span>", unsafe_allow_html=True)
            ev = P.eventos(corrida, cama)
            if ev.empty:
                st.caption("Sin alarmas registradas en esta simulación.")
            else:
                vista_ev = ev.assign(inicio=pd.to_numeric(ev["t_inicio_s"], errors="coerce").round(0),
                                     fin=pd.to_numeric(ev["t_fin_s"], errors="coerce").round(0))[
                    ["evento_id", "nivel", "regla", "inicio", "fin", "reconocido_por"]]
                st.dataframe(vista_ev, hide_index=True, use_container_width=True)
                pendientes = ev[ev["reconocido_por"].isna()]
                if not pendientes.empty:
                    with st.form("form_ack"):
                        sel = st.selectbox("Alarma a reconocer", pendientes["evento_id"].tolist(),
                                           format_func=lambda i: f"#{i} {pendientes.set_index('evento_id').loc[i, 'regla']}")
                        if st.form_submit_button("RECONOCER ALARMA"):
                            P.reconocer(int(sel), operador, t)
                            st.rerun()


    if hasattr(st, "fragment"):
        # Frecuencia constante: si cambia entre ejecuciones (pausa/inicio) Streamlit recrea el fragmento
        # y la pantalla parpadea. Con el reloj en pausa el ciclo sólo vuelve a dibujar el mismo instante.
        st.fragment(run_every=1.0)(vista_monitoreo)()
    else:
        vista_monitoreo()
