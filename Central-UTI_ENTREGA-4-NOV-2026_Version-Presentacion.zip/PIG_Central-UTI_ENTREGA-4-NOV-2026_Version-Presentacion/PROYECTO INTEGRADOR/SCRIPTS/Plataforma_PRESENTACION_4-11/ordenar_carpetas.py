# -*- coding: utf-8 -*-
"""
ordenar_carpetas.py — Orden mínimo y reversible de PROYECTO INTEGRADOR\\SCRIPTS (22/10/2026).

    cd "...\\PROYECTO INTEGRADOR\\SCRIPTS\\Plataforma"
    python ordenar_carpetas.py              ensayo: muestra qué movería, no toca nada
    python ordenar_carpetas.py --aplicar    mueve (nada se borra ni se pisa) y guarda ordenar_carpetas_log.csv
    python ordenar_carpetas.py --deshacer   devuelve cada archivo a su lugar según el log

Qué mueve (solo archivos que NINGÚN script actual lee; verificado buscando su nombre en los .py del proyecto):
  CSV de trabajo de pasos viejos      -> SCRIPTS\\Archivos_de_trabajo\\
  Interfaz_usuarios.py (interfaz vieja) -> SCRIPTS\\Versiones viejas\\

Qué NO toca, a propósito (los scripts lo buscan en ese lugar exacto):
  las bases .db (si se mueve benchmark_uti_ORIGINAL.db, el Paso 10 crea otra copia "original" desde una base ya modificada),
  tramos_base, tramos_con_falla, Respaldo_BD, DataBase, Plataforma, los CSV de config (tramos_seleccionados*, anomalias_reales*,
  alineacion_temporal, mediciones_clinicas, laboratorios_cohorte, resumen_clinico_tramo, huecos_naturales), candidatos_itemids.csv
  (lo lee Exportar_items.py) y los dos CSV de especificación umbrales_validacion.csv y parametros_validacion.csv.
"""
import argparse
import csv
import shutil
import sys
from datetime import datetime
from pathlib import Path

MOVER = [  # (origen relativo a PROYECTO INTEGRADOR, carpeta destino relativa)
    ("SCRIPTS/candidatos_verdes.csv", "SCRIPTS/Archivos_de_trabajo"),
    ("SCRIPTS/detalle_grabaciones.csv", "SCRIPTS/Archivos_de_trabajo"),
    ("SCRIPTS/pacientes_comunes.csv", "SCRIPTS/Archivos_de_trabajo"),
    ("SCRIPTS/resumen_candidatos.csv", "SCRIPTS/Archivos_de_trabajo"),
    ("SCRIPTS/revision_41976.csv", "SCRIPTS/Archivos_de_trabajo"),
    ("SCRIPTS/verificacion_segmentos.csv", "SCRIPTS/Archivos_de_trabajo"),
    ("SCRIPTS/Interfaz_usuarios.py", "SCRIPTS/Versiones viejas"),
]


def buscar_raiz(arg):
    if arg:
        r = Path(arg).resolve()
        if (r / "SCRIPTS").is_dir():
            return r
        sys.exit(f"No hay una carpeta SCRIPTS dentro de {r}")
    for p in [Path(__file__).resolve().parent, *Path(__file__).resolve().parents]:
        if (p / "SCRIPTS").is_dir():
            return p
    sys.exit("No encuentro PROYECTO INTEGRADOR. Pasala como argumento: python ordenar_carpetas.py --raiz <ruta>")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--aplicar", action="store_true")
    ap.add_argument("--deshacer", action="store_true")
    ap.add_argument("--raiz", default=None)
    a = ap.parse_args()
    raiz = buscar_raiz(a.raiz)
    log = raiz / "SCRIPTS" / "ordenar_carpetas_log.csv"
    print(f"Proyecto: {raiz}")

    if a.deshacer:
        if not log.exists():
            sys.exit("No hay log para deshacer.")
        filas = list(csv.DictReader(open(log, encoding="utf-8-sig")))
        quedan = []
        for f in reversed(filas):
            ori, dst = raiz / f["origen"], raiz / f["destino"]
            if not dst.exists():
                print(f"  (ya no está) {f['destino']}")
                continue
            if ori.exists():
                print(f"  NO se devuelve (ya existe uno en el origen): {f['origen']}")
                quedan.append(f)
                continue
            ori.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(dst), str(ori))
            print(f"  devuelto: {f['origen']}")
        if quedan:
            with open(log, "w", newline="", encoding="utf-8-sig") as fh:
                w = csv.DictWriter(fh, fieldnames=["fecha", "origen", "destino"])
                w.writeheader()
                w.writerows(reversed(quedan))
        else:
            log.rename(log.with_name(f"ordenar_carpetas_log_deshecho_{datetime.now():%Y%m%d_%H%M%S}.csv"))
        return

    hechos, nada = [], True
    for rel, destino in MOVER:
        ori = raiz / rel
        dst = raiz / destino / ori.name
        if not ori.exists():
            print(f"  - no está (se omite): {rel}")
            continue
        if dst.exists():
            print(f"  ! ya existe en el destino, no se pisa: {destino}/{ori.name}")
            continue
        nada = False
        print(f"  {'MUEVE' if a.aplicar else 'movería'}: {rel}  ->  {destino}/")
        if a.aplicar:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(ori), str(dst))
            hechos.append({"fecha": datetime.now().isoformat(timespec="seconds"), "origen": rel,
                           "destino": f"{destino}/{ori.name}"})
    if a.aplicar and hechos:
        nuevo = not log.exists()
        with open(log, "a", newline="", encoding="utf-8-sig") as fh:
            w = csv.DictWriter(fh, fieldnames=["fecha", "origen", "destino"])
            if nuevo:
                w.writeheader()
            w.writerows(hechos)
        print(f"\nListo: {len(hechos)} archivos movidos. Log: {log}\nPara volver atrás: python ordenar_carpetas.py --deshacer")
    elif not a.aplicar:
        print("\nEnsayo: no se movió nada. Para aplicar: python ordenar_carpetas.py --aplicar" if not nada else "\nNada para mover.")


if __name__ == "__main__":
    main()
