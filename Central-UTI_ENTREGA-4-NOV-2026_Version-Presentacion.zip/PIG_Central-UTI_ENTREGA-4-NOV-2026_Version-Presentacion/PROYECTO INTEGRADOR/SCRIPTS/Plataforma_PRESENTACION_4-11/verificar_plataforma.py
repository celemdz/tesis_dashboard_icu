# ============================================================
# verificar_plataforma.py - Prueba rápida de la capa de datos (sin Streamlit)
#   cd "...\SCRIPTS\Plataforma"
#   python verificar_plataforma.py
# Muestra qué ve la plataforma en cada cama en tres instantes y si los tramos de señal se leen bien.
# ============================================================
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
import datos_db as ddb
import reglas_basicas as reglas
import senales

base = ddb.BaseUTI()
umbrales = {"fc_max": 120, "pam_min": 65, "spo2_min": 92, "fr_max": 25, "pas_min": 90}
print(f"Base: {base.ruta}")
print(f"Camas: {len(base.camas)} | estadías: {len(base.estadias)} | series cargadas: {len(base._series)}")
print(f"Minuto 0 = {base.anclaje} | duración del tramo = {base.duracion_s:.0f} s\n")

for t in (0, 900, 1800):
    print(f"===== t = {t} s ({base.hora_sim(t):%H:%M:%S}) =====")
    print(f"{'cama':>4} {'FC':>5} {'SpO2':>5} {'FR':>4} {'PAM':>5} {'PA':>3}  {'estado':<18} alarmas")
    for cama in base.camas["cama_id"]:
        est = base.estadia_de_cama(int(cama))
        s = base.snapshot(est, t)
        a = reglas.evaluar(s, umbrales, base)
        f = lambda x: "—" if x is None else f"{x:.0f}"
        print(f"{int(cama):>4} {f(s['fc']):>5} {f(s['spo2']):>5} {f(s['fr']):>4} {f(s['pam']):>5} {s['pa_origen'] or '-':>3}  "
              f"{reglas.estado_cama(a):<18} {[x['regla'] for x in a]}")
    print()

print("===== Señal continua: latidos detectados vs FC del monitor (t = 900 s) =====")
ritmo = senales.RitmoCache()
for cama in base.camas["cama_id"]:
    est = base.estadia_de_cama(int(cama))
    info = base.info_tramo(est)
    if info is None:
        print(f"cama {int(cama):>2}: sin tramo"); continue
    try:
        rr = ritmo.rr_hasta(est, info["ruta"], 900, ultimos=30)
        fc_rr = 60000 / np.median(rr) if len(rr) else float("nan")
        d = base.ultimo(est, "fc", 900)
        print(f"cama {int(cama):>2}: canales {info['canales']}, FC por RR = {fc_rr:5.1f}, FC monitor = {d.valor if d else '—'}")
    except Exception as error:
        print(f"cama {int(cama):>2}: ERROR leyendo la señal -> {error}")


print("\n===== Indicadores clínicos (scores_clinicos.py) en t = 900 s =====")
import scores_clinicos as SC
print(f"{'cama':>4} {'NEWS2':>6} {'qSOFA':>6} {'SOFA':>6} {'APACHE':>7} {'shock':>6}  confianza")
for cama in base.camas["cama_id"]:
    r = SC.calcular(base, base.estadia_de_cama(int(cama)), 900)
    f = lambda s: "—" if s["valor"] is None else f"{'≥' if s['minimo'] else ''}{s['valor']}"
    print(f"{int(cama):>4} {f(r['news2']):>6} {f(r['qsofa']):>6} {f(r['sofa']):>6} {f(r['apache']):>7} {f(r['shock']):>6}  {r['sofa']['confianza']}"
          + (f"   descartes: {r['descartes']}" if r["descartes"] else ""))
