# -*- coding: utf-8 -*-
"""
scores_clinicos.py — Indicadores clínicos de la plataforma (NEWS2, qSOFA, SOFA, APACHE II, índice de shock,
oxigenación P/F · S/F · ROX).

Reglas de diseño (importantes para la tesis):
  * Sólo usa datos de la base hasta el instante simulado t_s (nunca el futuro) a través de datos_db.BaseUTI.
  * No depende de Streamlit: se puede probar desde la consola (`python scores_clinicos.py`).
  * La base NO tiene todo lo que piden SOFA y APACHE II (vasopresores, diuresis, pH, Na, K, hematocrito,
    leucocitos, PaCO2, enfermedad crónica). Por eso SOFA y APACHE II son PARCIALES: se calculan con los componentes
    disponibles, se informa cuáles faltan, y el resultado se presenta como VALOR MÍNIMO ("≥ X"). No se estima
    mortalidad, porque con componentes faltantes esa conversión no es válida.
  * Cada dato usado lleva su antigüedad. Los datos fuera de rango fisiológico (p. ej. temperatura 98,6 por
    unidades en °F, FiO2 0,4 en lugar de 40 %) se descartan y se informan en `descartes`.
  * Confianza del resultado: alta (datos vigentes / labs <= 24 h), media (labs 24-48 h o signos manuales 4-8 h),
    baja (labs 48-72 h). Los laboratorios de más de 72 h no se usan.

Los puntos de corte son los de las publicaciones originales:
  NEWS2: Royal College of Physicians (2017), escala 1 de SpO2.  qSOFA: Sepsis-3 (Singer, JAMA 2016).
  SOFA: Vincent 1996 / Sepsis-3.  APACHE II: Knaus 1985.  S/F: Pandharipande 2009.  ROX: Roca 2019.
"""
import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# Parámetros
# ---------------------------------------------------------------------------
VENTANA_PEOR_S = 24 * 3600          # SOFA / APACHE II: peor valor de las últimas 24 h
LAB_MAX_S = 72 * 3600               # un laboratorio de más de 72 h no se usa
VIGENCIA_MONITOR_S = 5 * 60         # monitor: dato "en vivo"
MANUAL_ESTANDAR_S = 4 * 3600        # signos cargados por enfermería: vigencia estándar de la plataforma
MANUAL_MAX_S = 8 * 3600             # NEWS2/qSOFA: se aceptan hasta 8 h (confianza media a partir de 4 h)
O2_MAX_S = 24 * 3600                # FiO2 / dispositivo de O2: se mantienen hasta 24 h
PAR_PF_MAX_S = 6 * 3600             # FiO2 asociada a una PaO2: la más cercana, hasta 6 h antes

# Rangos fisiológicos plausibles: lo que está afuera es error de carga o de unidad y no se usa.
PLAUSIBLE = {
    "fc": (20, 300), "spo2": (50, 100), "fr": (2, 80), "pas": (40, 300), "pam": (20, 200),
    "temperatura": (30, 45), "fio2": (21, 100), "pao2": (20, 700), "creatinina": (0.1, 25),
    "bilirrubina_total": (0.1, 60), "plaquetas": (1, 1500), "gcs_total": (3, 15),
    "gcs_ocular": (1, 4), "gcs_motor": (1, 6), "gcs_verbal": (1, 5),
}
UNIDAD = {"fc": "lpm", "spo2": "%", "fr": "rpm", "pas": "mmHg", "pam": "mmHg", "temperatura": "°C", "fio2": "%",
          "pao2": "mmHg", "creatinina": "mg/dL", "bilirrubina_total": "mg/dL", "plaquetas": "K/uL",
          "gcs_total": "pts"}

COLORES = {"verde": "#2ECC71", "amarillo": "#F1C40F", "naranja": "#F39C12", "rojo": "#E74C3C", "gris": "#777777"}
RANK_CONF = {"alta": 0, "media": 1, "baja": 2}


def plausible(clave, valor):
    r = PLAUSIBLE.get(clave)
    return True if r is None or valor is None else (r[0] <= valor <= r[1])


def _num(x, dec=1):
    return "—" if x is None else (f"{x:.{dec}f}" if dec else f"{x:.0f}")


def _edad_txt(seg):
    if seg is None:
        return ""
    if seg < 90:
        return "ahora"
    return f"hace {seg / 60:.0f} min" if seg < 7200 else f"hace {seg / 3600:.1f} h"


# ---------------------------------------------------------------------------
# Tablas de puntos (funciones puras, fáciles de verificar contra la bibliografía)
# ---------------------------------------------------------------------------
def news2_fr(x):
    r = round(x)
    return 3 if r <= 8 else 1 if r <= 11 else 0 if r <= 20 else 2 if r <= 24 else 3


def news2_spo2(x):                      # escala 1 (sin hipercapnia conocida)
    r = round(x)
    return 3 if r <= 91 else 2 if r <= 93 else 1 if r <= 95 else 0


def news2_pas(x):
    r = round(x)
    return 3 if r <= 90 else 2 if r <= 100 else 1 if r <= 110 else 0 if r <= 219 else 3


def news2_fc(x):
    r = round(x)
    return 3 if r <= 40 else 1 if r <= 50 else 0 if r <= 90 else 1 if r <= 110 else 2 if r <= 130 else 3


def news2_temp(x):
    r = round(x, 1)
    return 3 if r <= 35.0 else 1 if r <= 36.0 else 0 if r <= 38.0 else 1 if r <= 39.0 else 2


def sofa_resp_pf(pf, ventilado):
    if pf >= 400:
        return 0
    if pf >= 300:
        return 1
    if pf >= 200:
        return 2
    if pf >= 100:
        return 3 if ventilado else 2
    return 4 if ventilado else 2


def sofa_resp_sf(sf, ventilado):        # S/F equivalentes (Pandharipande 2009): 357 ~ P/F 300, 214 ~ 200, 89 ~ 100
    if sf > 357:
        return 0                        # 0-1: con S/F no se distingue; se informa como piso (el total ya es un mínimo)
    if sf > 214:
        return 2
    if sf > 89:
        return 3 if ventilado else 2
    return 4 if ventilado else 2


def sofa_coag(plq):
    return 0 if plq >= 150 else 1 if plq >= 100 else 2 if plq >= 50 else 3 if plq >= 20 else 4


def sofa_higado(bili):
    return 0 if bili < 1.2 else 1 if bili < 2.0 else 2 if bili < 6.0 else 3 if bili < 12.0 else 4


def sofa_cv_pam(pam):                   # sin vasopresores en la base: sólo se distingue 0 y 1
    return 1 if pam < 70 else 0


def sofa_snc(gcs):
    return 0 if gcs >= 15 else 1 if gcs >= 13 else 2 if gcs >= 10 else 3 if gcs >= 6 else 4


def sofa_renal(cr):                     # sin diuresis en la base: sólo por creatinina
    return 0 if cr < 1.2 else 1 if cr < 2.0 else 2 if cr < 3.5 else 3 if cr < 5.0 else 4


def apache_temp(t):
    return (4 if t >= 41 else 3 if t >= 39 else 1 if t >= 38.5 else 0 if t >= 36 else 1 if t >= 34
            else 2 if t >= 32 else 3 if t >= 30 else 4)


def apache_pam(p):
    return 4 if p >= 160 else 3 if p >= 130 else 2 if p >= 110 else 0 if p >= 70 else 2 if p >= 50 else 4


def apache_fc(x):
    return (4 if x >= 180 else 3 if x >= 140 else 2 if x >= 110 else 0 if x >= 70 else 2 if x >= 55
            else 3 if x >= 40 else 4)


def apache_fr(x):
    return (4 if x >= 50 else 3 if x >= 35 else 1 if x >= 25 else 0 if x >= 12 else 1 if x >= 10
            else 2 if x >= 6 else 4)


def apache_pao2(p):                     # sólo válido con FiO2 < 0,5
    return 0 if p > 70 else 1 if p >= 61 else 3 if p >= 55 else 4


def apache_creat(c):                    # sin duplicar por insuficiencia renal aguda (dato no disponible)
    return 4 if c >= 3.5 else 3 if c >= 2.0 else 2 if c >= 1.5 else 0 if c >= 0.6 else 2


def apache_edad(e):
    return 0 if e < 45 else 2 if e < 55 else 3 if e < 65 else 5 if e < 75 else 6


# ---------------------------------------------------------------------------
# Acceso a los datos (un contexto por estadía e instante)
# ---------------------------------------------------------------------------
class _Ctx:
    def __init__(self, base, estadia_id, t_s):
        self.base, self.eid, self.t = base, int(estadia_id), float(t_s)
        self.snap = base.snapshot(self.eid, self.t)
        self.descartes = []             # datos que existían pero no se usaron por ser implausibles
        self.viejos = {}                # variable -> antigüedad del último dato cuando superó el máximo permitido

    def dato(self, var, max_edad_s, clave=None):
        """Último dato plausible de `var` con antigüedad <= max_edad_s, o None."""
        clave = clave or var
        d = self.base.ultimo(self.eid, var, self.t)
        if d is None or d.valor is None:
            return None
        if not plausible(clave, d.valor):
            self.descartes.append(f"{var} = {d.valor:g} descartado: fuera de rango fisiológico"
                                  + (" (¿unidad °F?)" if clave == "temperatura" and d.valor > 45 else "")
                                  + (" (¿fracción en vez de %?)" if clave == "fio2" and d.valor < 21 else ""))
            return None
        if d.antiguedad_s > max_edad_s:
            self.viejos[var] = d.antiguedad_s
            return None
        return {"valor": float(d.valor), "edad_s": float(d.antiguedad_s), "t_s": float(d.t_s)}

    def texto(self, var, max_edad_s):
        d = self.base.ultimo(self.eid, var, self.t)
        if d is None or d.texto is None or (isinstance(d.texto, float) and np.isnan(d.texto)):
            return None
        if d.antiguedad_s > max_edad_s:
            return None
        return {"texto": str(d.texto).strip(), "edad_s": float(d.antiguedad_s)}

    def ventana(self, variables, clave, ventana_s=VENTANA_PEOR_S, suavizar=False):
        """Serie plausible de las últimas `ventana_s` (t, v). Con `suavizar` aplica mediana móvil de 5 (artefactos)."""
        marcos = []
        for v in variables:
            df = self.base.serie(self.eid, v, self.t - ventana_s, self.t).dropna(subset=["valor"])
            if not df.empty:
                marcos.append(df[["t_s", "valor"]])
        if not marcos:
            return np.array([]), np.array([])
        df = pd.concat(marcos).sort_values("t_s")
        ok = [plausible(clave, x) for x in df["valor"]]
        if len(ok) - sum(ok):
            self.descartes.append(f"{clave}: hay valores fuera de rango fisiológico en la ventana (descartados)")
        df = df[ok]
        if df.empty:
            return np.array([]), np.array([])
        v = df["valor"].to_numpy(float)
        if suavizar and len(v) >= 5:
            v = pd.Series(v).rolling(5, center=True, min_periods=3).median().to_numpy()
        return df["t_s"].to_numpy(float), v

    def peor(self, variables, clave, tabla=None, modo="min", suavizar=False, lab=False):
        """Peor valor en 24 h. `tabla` (valor->puntos) define 'peor' como el de más puntos; si no, min/max.
        Para laboratorios, si no hay dato en 24 h se usa el último de hasta 72 h (menor confianza).
        Devuelve dict(valor, puntos, edad_s, n, ventana) o None."""
        t, v = self.ventana(variables, clave, VENTANA_PEOR_S, suavizar)
        ventana = "24 h"
        if len(v) == 0 and lab:
            t, v = self.ventana(variables, clave, LAB_MAX_S, False)
            if len(v):
                t, v = t[-1:], v[-1:]
                ventana = "último ≤ 72 h"
        if len(v) == 0:
            return None
        if tabla is not None:
            pts = np.array([tabla(x) for x in v])
            i = int(np.argmax(pts))
            # empate de puntos: se toma el más reciente, para que el valor mostrado sea el más actual
            i = int(np.flatnonzero(pts == pts[i])[-1])
            return {"valor": float(v[i]), "puntos": int(pts[i]), "edad_s": float(self.t - t[-1]), "n": int(len(v)),
                    "ventana": ventana}
        i = int(np.argmin(v) if modo == "min" else np.argmax(v))
        return {"valor": float(v[i]), "puntos": None, "edad_s": float(self.t - t[-1]), "n": int(len(v)),
                "ventana": ventana}

    # ----- conveniencias -----
    def intubado(self):
        o2 = self.texto("dispositivo_o2", O2_MAX_S)
        return bool(o2 and ("endotracheal" in o2["texto"].lower() or o2["texto"].lower() in ("ett", "intubado")))

    def fr(self):
        d = self.dato("fr", MANUAL_MAX_S, "fr") or self.dato("fr_total", MANUAL_MAX_S, "fr")
        return self._solo_si_vigente_monitor(d, "fr")

    def _solo_si_vigente_monitor(self, d, var=None):
        """FC, SpO2 y FR vienen del monitor: sólo cuentan si están 'en vivo' (<= 5 min). Si no, se informan como sin dato vigente."""
        return d if (d is not None and d["edad_s"] <= VIGENCIA_MONITOR_S) else None


# ---------------------------------------------------------------------------
# Utilidades de salida
# ---------------------------------------------------------------------------
def _comp(item, valor_txt, puntos, edad_s=None, nota="", ventana=""):
    return {"item": item, "valor": valor_txt, "puntos": puntos, "edad": _edad_txt(edad_s), "edad_s": edad_s,
            "nota": nota, "ventana": ventana}


def _falta(item, motivo):
    return {"item": item, "valor": "—", "puntos": None, "edad": "", "edad_s": None, "nota": motivo, "ventana": ""}


def _confianza(componentes):
    """alta / media / baja según la antigüedad de lo que se usó (ver encabezado del módulo)."""
    peor = "alta"
    for c in componentes:
        if c["puntos"] is None or c["edad_s"] is None:
            continue
        lab = c.get("lab", False)
        s = c["edad_s"]
        if lab:
            nivel = "alta" if s <= 24 * 3600 else "media" if s <= 48 * 3600 else "baja"
        else:
            nivel = "alta" if s <= MANUAL_ESTANDAR_S else "media"
        if RANK_CONF[nivel] > RANK_CONF[peor]:
            peor = nivel
    return peor


# ---------------------------------------------------------------------------
# NEWS2
# ---------------------------------------------------------------------------
def _news2(cx):
    snap, comp = cx.snap, []

    fr = cx.fr()
    comp.append(_comp("Frecuencia respiratoria", f"{_num(fr['valor'], 0)} rpm", news2_fr(fr["valor"]), fr["edad_s"])
                 if fr else _falta("Frecuencia respiratoria", "sin dato vigente"))

    d = cx.dato("spo2", MANUAL_MAX_S, "spo2")
    d = cx._solo_si_vigente_monitor(d, "spo2")
    comp.append(_comp("SpO2 (escala 1)", f"{_num(d['valor'], 0)} %", news2_spo2(d["valor"]), d["edad_s"],
                      "sin escala 2 (hipercapnia no registrada)") if d else _falta("SpO2 (escala 1)", "sin dato vigente"))

    # Oxígeno suplementario: dispositivo cargado o FiO2 > 21 %
    dev, fio2 = cx.texto("dispositivo_o2", O2_MAX_S), cx.dato("fio2", O2_MAX_S, "fio2")
    sin_o2 = dev is not None and dev["texto"].lower() in ("none", "room air", "aire ambiente", "")
    if (dev is not None and not sin_o2) or (fio2 is not None and fio2["valor"] > 21.5):
        quien = dev["texto"] if dev and not sin_o2 else f"FiO2 {_num(fio2['valor'], 0)} %"
        comp.append(_comp("Aire / oxígeno", f"oxígeno ({quien})", 2, (dev or fio2)["edad_s"]))
    elif sin_o2 or (fio2 is not None and fio2["valor"] <= 21.5):
        comp.append(_comp("Aire / oxígeno", "aire ambiente", 0, (dev or fio2)["edad_s"]))
    else:
        comp.append(_falta("Aire / oxígeno", "sin dispositivo ni FiO2 cargados"))

    pa = snap["datos"].get("pa")
    if snap["pas"] is not None and pa is not None and plausible("pas", snap["pas"]) and \
            (pa.antiguedad_s <= VIGENCIA_MONITOR_S or (snap["pa_origen"] == "NI" and pa.antiguedad_s <= MANUAL_MAX_S)):
        comp.append(_comp("Presión sistólica", f"{_num(snap['pas'], 0)} mmHg ({snap['pa_origen']})",
                          news2_pas(snap["pas"]), pa.antiguedad_s))
    else:
        comp.append(_falta("Presión sistólica", "sin dato vigente"))

    d = cx.dato("fc", MANUAL_MAX_S, "fc")
    d = cx._solo_si_vigente_monitor(d, "fc")
    comp.append(_comp("Frecuencia cardíaca", f"{_num(d['valor'], 0)} lpm", news2_fc(d["valor"]), d["edad_s"])
                if d else _falta("Frecuencia cardíaca", "sin dato vigente"))

    # Conciencia (ACVPU) a partir de Glasgow: 15 = alerta (0); < 15 = no alerta (3).
    gcs = cx.dato("gcs_total", MANUAL_MAX_S, "gcs_total")
    if gcs is not None:
        nota = "Glasgow < 15 se asigna como 'no alerta' (supuesto de la plataforma)"
        puntos = 0 if gcs["valor"] >= 15 else 3
        valor = f"Glasgow {_num(gcs['valor'], 0)}"
        if cx.intubado():
            oc, mo = cx.dato("gcs_ocular", MANUAL_MAX_S, "gcs_ocular"), cx.dato("gcs_motor", MANUAL_MAX_S, "gcs_motor")
            if oc and mo:
                puntos = 0 if (oc["valor"] >= 4 and mo["valor"] >= 6) else 3
                nota = "paciente intubado: se evalúa con respuesta ocular + motora (la verbal no es evaluable)"
        comp.append(_comp("Conciencia (ACVPU)", valor, puntos, gcs["edad_s"], nota))
    else:
        comp.append(_falta("Conciencia (ACVPU)", "sin Glasgow reciente"))

    t = cx.dato("temperatura", MANUAL_MAX_S, "temperatura")
    comp.append(_comp("Temperatura", f"{_num(t['valor'], 1)} °C", news2_temp(t["valor"]), t["edad_s"])
                if t else _falta("Temperatura", "sin dato vigente"))

    for c in comp:
        c["lab"] = False
    pts = [c["puntos"] for c in comp if c["puntos"] is not None]
    faltan = [c["item"] for c in comp if c["puntos"] is None]
    total = int(sum(pts))
    rojo = any(p == 3 for p in pts)
    if not pts:
        nivel, color, texto = "SIN DATOS", COLORES["gris"], "No hay datos vigentes para calcular el NEWS2."
    elif total >= 7:
        nivel, color, texto = "RIESGO ALTO", COLORES["rojo"], "≥ 7: respuesta de emergencia / evaluación crítica inmediata."
    elif total >= 5:
        nivel, color, texto = "RIESGO MEDIO", COLORES["naranja"], "5-6: revisión urgente por un clínico."
    elif rojo:
        nivel, color, texto = "BAJO-MEDIO", COLORES["amarillo"], "Un parámetro con 3 puntos: revisión clínica urgente aunque el total sea bajo."
    else:
        nivel, color, texto = "RIESGO BAJO", COLORES["verde"], "0-4: continuar monitoreo habitual."
    return {"nombre": "NEWS2", "valor": total if pts else None, "minimo": bool(faltan), "max": 20,
            "nivel": nivel, "color": color, "interpretacion": texto, "componentes": comp, "faltantes": faltan,
            "limitaciones": ["Conciencia estimada desde Glasgow (la base no registra ACVPU)",
                             "Escala 2 de SpO2 (hipercapnia) no disponible"],
            "confianza": _confianza(comp), "cobertura": f"{len(pts)}/7"}


# ---------------------------------------------------------------------------
# qSOFA
# ---------------------------------------------------------------------------
def _qsofa(cx, news):
    comp = []
    fr = next((c for c in news["componentes"] if c["item"] == "Frecuencia respiratoria"), None)
    fr_v = cx.fr()
    comp.append(_comp("FR ≥ 22 rpm", f"{_num(fr_v['valor'], 0)} rpm", int(fr_v["valor"] >= 22), fr_v["edad_s"])
                if fr_v else _falta("FR ≥ 22 rpm", "sin dato vigente"))
    snap, pa = cx.snap, cx.snap["datos"].get("pa")
    if snap["pas"] is not None and pa is not None and plausible("pas", snap["pas"]) and \
            (pa.antiguedad_s <= VIGENCIA_MONITOR_S or (snap["pa_origen"] == "NI" and pa.antiguedad_s <= MANUAL_MAX_S)):
        comp.append(_comp("PAS ≤ 100 mmHg", f"{_num(snap['pas'], 0)} mmHg", int(snap["pas"] <= 100), pa.antiguedad_s))
    else:
        comp.append(_falta("PAS ≤ 100 mmHg", "sin dato vigente"))
    conc = next((c for c in news["componentes"] if c["item"].startswith("Conciencia")), None)
    if conc and conc["puntos"] is not None:
        comp.append(_comp("Alteración mental (Glasgow < 15)", conc["valor"], int(conc["puntos"] > 0), conc["edad_s"], conc["nota"]))
    else:
        comp.append(_falta("Alteración mental (Glasgow < 15)", "sin Glasgow reciente"))
    for c in comp:
        c["lab"] = False
    pts = [c["puntos"] for c in comp if c["puntos"] is not None]
    faltan = [c["item"] for c in comp if c["puntos"] is None]
    total = int(sum(pts))
    positivo = total >= 2
    return {"nombre": "qSOFA", "valor": total if pts else None, "minimo": bool(faltan), "max": 3,
            "nivel": "POSITIVO (≥ 2)" if positivo else "NEGATIVO", "color": COLORES["rojo"] if positivo else COLORES["verde"],
            "interpretacion": ("≥ 2 puntos: mayor riesgo de mala evolución si hay sospecha de infección; evaluar sepsis."
                               if positivo else "< 2 puntos. No descarta sepsis: es un tamizaje rápido, no un diagnóstico."),
            "componentes": comp, "faltantes": faltan, "limitaciones": [], "confianza": _confianza(comp),
            "cobertura": f"{len(pts)}/3"}


# ---------------------------------------------------------------------------
# Índice de shock
# ---------------------------------------------------------------------------
def _shock(cx):
    fc = cx._solo_si_vigente_monitor(cx.dato("fc", MANUAL_MAX_S, "fc"), "fc")
    snap, pa = cx.snap, cx.snap["datos"].get("pa")
    pas = snap["pas"] if (pa is not None and plausible("pas", snap["pas"]) and
                          (pa.antiguedad_s <= VIGENCIA_MONITOR_S or
                           (snap["pa_origen"] == "NI" and pa.antiguedad_s <= MANUAL_MAX_S))) else None
    pam = snap["pam"] if pas is not None and plausible("pam", snap["pam"]) else None
    comp, faltan = [], []
    ix = msi = None
    if fc and pas:
        ix = fc["valor"] / pas
        comp.append(_comp("Índice de shock (FC / PAS)", f"{ix:.2f}", None, max(fc["edad_s"], pa.antiguedad_s),
                          "normal ≈ 0,5-0,7"))
    else:
        faltan.append("Índice de shock (FC / PAS)")
        comp.append(_falta("Índice de shock (FC / PAS)", "falta FC o presión vigente"))
    if fc and pam:
        msi = fc["valor"] / pam
        comp.append(_comp("Índice de shock modificado (FC / PAM)", f"{msi:.2f}", None, max(fc["edad_s"], pa.antiguedad_s),
                          "normal ≈ 0,7-1,3"))
    for c in comp:
        c["lab"] = False
    if ix is None:
        nivel, color, texto = "SIN DATOS", COLORES["gris"], "Falta FC o presión arterial vigente."
    elif ix >= 1.0 or (msi is not None and msi >= 1.3):
        nivel, color, texto = "ALTO", COLORES["rojo"], "FC/PAS ≥ 1,0 (o modificado ≥ 1,3): sugiere compromiso hemodinámico si se confirma."
    elif ix >= 0.9:
        nivel, color, texto = "ELEVADO", COLORES["naranja"], "FC/PAS ≥ 0,9: conviene vigilar la presión y la perfusión."
    else:
        nivel, color, texto = "NORMAL", COLORES["verde"], "FC/PAS < 0,9: sin alerta hemodinámica por este índice."
    return {"nombre": "Índice de shock", "valor": None if ix is None else round(ix, 2), "minimo": False, "max": None,
            "nivel": nivel, "color": color, "interpretacion": texto, "componentes": comp, "faltantes": faltan,
            "limitaciones": ["Orientativo: no reemplaza la valoración clínica ni el lactato (no disponible)"],
            "confianza": _confianza(comp), "cobertura": f"{1 - len(faltan)}/1", "etiqueta": "FC / PAS"}


# ---------------------------------------------------------------------------
# Oxigenación: P/F, S/F, ROX
# ---------------------------------------------------------------------------
def _pares_pf(cx, ventana_s):
    """Pares (PaO2, FiO2 asociada) dentro de la ventana. FiO2 asociada = último FiO2 hasta 6 h antes de la gasometría."""
    t, v = cx.ventana(["pao2"], "pao2", ventana_s, False)
    pares = []
    for ti, pao2 in zip(t, v):
        d = cx.base.ultimo(cx.eid, "fio2", ti)
        if d is None or d.valor is None or d.antiguedad_s > PAR_PF_MAX_S or not plausible("fio2", d.valor):
            continue
        pares.append({"t": ti, "pao2": float(pao2), "fio2": float(d.valor), "pf": float(pao2) / (d.valor / 100.0)})
    return pares


def _oxigenacion(cx):
    comp, faltan = [], []
    fio2 = cx.dato("fio2", O2_MAX_S, "fio2")
    spo2 = cx._solo_si_vigente_monitor(cx.dato("spo2", MANUAL_MAX_S, "spo2"), "spo2")
    fr = cx.fr()

    pares = _pares_pf(cx, LAB_MAX_S)
    pf = pares[-1] if pares else None
    if pf:
        edad = cx.t - pf["t"]
        c = _comp("P/F (PaO2 / FiO2)", f"{pf['pf']:.0f}", None, edad,
                  f"PaO2 {pf['pao2']:.0f} con FiO2 {pf['fio2']:.0f} %")
        c["lab"] = True
        comp.append(c)
    else:
        faltan.append("P/F (PaO2 / FiO2)")
        comp.append(_falta("P/F (PaO2 / FiO2)", "no hay gasometría ≤ 72 h con FiO2 asociada"))

    sf = None
    if fio2 and spo2:
        if spo2["valor"] <= 97:
            sf = spo2["valor"] / (fio2["valor"] / 100.0)
            comp.append(_comp("S/F (SpO2 / FiO2)", f"{sf:.0f}", None, max(fio2["edad_s"], spo2["edad_s"]),
                              f"SpO2 {spo2['valor']:.0f} % con FiO2 {fio2['valor']:.0f} %"))
        else:
            faltan.append("S/F (SpO2 / FiO2)")
            comp.append(_falta("S/F (SpO2 / FiO2)", "SpO2 > 97 %: la relación S/F no es confiable"))
    else:
        faltan.append("S/F (SpO2 / FiO2)")
        comp.append(_falta("S/F (SpO2 / FiO2)", "falta FiO2 o SpO2 vigente"))

    rox = None
    if cx.intubado():
        comp.append(_falta("ROX ((SpO2/FiO2) / FR)", "no aplica: paciente intubado"))
    elif fio2 and spo2 and fr and fr["valor"] > 0:
        rox = (spo2["valor"] / (fio2["valor"] / 100.0)) / fr["valor"]
        comp.append(_comp("ROX ((SpO2/FiO2) / FR)", f"{rox:.1f}", None, max(fio2["edad_s"], spo2["edad_s"], fr["edad_s"]),
                          "referencia válida sólo para cánula de alto flujo / VNI"))
    else:
        comp.append(_falta("ROX ((SpO2/FiO2) / FR)", "falta FiO2, SpO2 o FR vigente"))
    for c in comp:
        c.setdefault("lab", False)

    ref = pf["pf"] if pf else sf
    if ref is None:
        nivel, color, texto = "SIN DATOS", COLORES["gris"], "Falta FiO2 para evaluar la oxigenación."
    else:
        base_txt = "P/F" if pf else "S/F (estimado)"
        cortes = (300, 200, 100) if pf else (357, 214, 89)
        if ref > cortes[0]:
            nivel, color, texto = "SIN COMPROMISO EVIDENTE", COLORES["verde"], f"{base_txt} sin alteración marcada."
        elif ref > cortes[1]:
            nivel, color, texto = "LEVE", COLORES["amarillo"], f"{base_txt} equivale a hipoxemia leve (P/F 200-300)."
        elif ref > cortes[2]:
            nivel, color, texto = "MODERADA", COLORES["naranja"], f"{base_txt} equivale a hipoxemia moderada (P/F 100-200)."
        else:
            nivel, color, texto = "SEVERA", COLORES["rojo"], f"{base_txt} equivale a hipoxemia severa (P/F < 100)."
    if rox is not None:
        texto += f" ROX {rox:.1f}: " + ("≥ 4,88 favorable" if rox >= 4.88 else "2,85-4,88 intermedio" if rox >= 2.85
                                        else "< 2,85 desfavorable") + " (sólo aplica con alto flujo/VNI)."
    return {"nombre": "Oxigenación", "valor": None if ref is None else round(ref), "minimo": False, "max": None,
            "nivel": nivel, "color": color, "interpretacion": texto, "componentes": comp, "faltantes": faltan,
            "limitaciones": ["La base no registra dispositivo de alto flujo/VNI: el ROX es sólo orientativo",
                             "La FiO2 asociada a la gasometría es la última cargada antes de ella"],
            "confianza": _confianza(comp), "cobertura": f"{3 - len(faltan)}/3", "pf": pf and pf["pf"], "sf": sf, "rox": rox,
            "etiqueta": "P/F" if pf else ("S/F estimado" if sf else "")}


# ---------------------------------------------------------------------------
# SOFA parcial
# ---------------------------------------------------------------------------
def _sofa(cx):
    comp = []
    ventilado = cx.intubado()

    # --- Respiratorio: P/F peor de 24 h; si no hay, último ≤ 72 h; si no hay, S/F
    pares = _pares_pf(cx, VENTANA_PEOR_S)
    ventana = "24 h"
    if not pares:
        pares = _pares_pf(cx, LAB_MAX_S)[-1:]
        ventana = "último ≤ 72 h"
    if pares:
        peor = min(pares, key=lambda p: p["pf"])
        c = _comp("Respiratorio (P/F)", f"{peor['pf']:.0f}", sofa_resp_pf(peor["pf"], ventilado), cx.t - peor["t"],
                  f"PaO2 {peor['pao2']:.0f} / FiO2 {peor['fio2']:.0f} %" + ("" if ventilado else
                                                                         " · sin ventilación: máx. 2 pts"), ventana)
        c["lab"] = True
        comp.append(c)
    else:
        fio2 = cx.dato("fio2", O2_MAX_S, "fio2")
        spo2 = cx._solo_si_vigente_monitor(cx.dato("spo2", MANUAL_MAX_S, "spo2"), "spo2")
        if fio2 and spo2 and spo2["valor"] <= 97:
            sf = spo2["valor"] / (fio2["valor"] / 100.0)
            c = _comp("Respiratorio (S/F estimado)", f"{sf:.0f}", sofa_resp_sf(sf, ventilado),
                      max(fio2["edad_s"], spo2["edad_s"]), "sin gasometría: se estima por SpO2/FiO2 (S/F > 357 se cuenta 0)")
            c["lab"] = False
            comp.append(c)
        else:
            comp.append(_falta("Respiratorio", "sin gasometría ≤ 72 h ni FiO2/SpO2 para estimarlo"))

    def lab(item, variable, tabla_pts, modo, clave, unidad, dec):
        p = cx.peor([variable], clave, None, modo, False, lab=True)
        if p is None:
            comp.append(_falta(item, f"sin dato ≤ 72 h" + (f" (último hace {cx.viejos[variable] / 3600:.0f} h)" if variable in cx.viejos else "")))
            return
        c = _comp(item, f"{p['valor']:.{dec}f} {unidad}", tabla_pts(p["valor"]), p["edad_s"], "", p["ventana"])
        c["lab"] = True
        comp.append(c)

    lab("Coagulación (plaquetas)", "plaquetas", sofa_coag, "min", "plaquetas", "K/uL", 0)
    lab("Hígado (bilirrubina)", "bilirrubina_total", sofa_higado, "max", "bilirrubina_total", "mg/dL", 1)

    # --- Cardiovascular: sólo por PAM (no hay vasopresores en la base)
    p = cx.peor(["pa_inv_media", "pa_ni_media"], "pam", sofa_cv_pam, "min", suavizar=True)
    if p:
        c = _comp("Cardiovascular (PAM)", f"{p['valor']:.0f} mmHg", p["puntos"], p["edad_s"],
                  "sin datos de vasopresores: puede estar subestimado", p["ventana"])
        c["lab"] = False
        comp.append(c)
    else:
        comp.append(_falta("Cardiovascular (PAM)", "sin PAM en 24 h"))

    # --- Neurológico
    p = cx.peor(["gcs_total"], "gcs_total", sofa_snc, "min")
    if p:
        c = _comp("Neurológico (Glasgow)", f"{p['valor']:.0f} pts", p["puntos"], p["edad_s"],
                  "intubado: la respuesta verbal no es evaluable" if ventilado else "", p["ventana"])
        c["lab"] = False
        comp.append(c)
    else:
        comp.append(_falta("Neurológico (Glasgow)", "sin Glasgow en 24 h"))

    lab("Renal (creatinina)", "creatinina", sofa_renal, "max", "creatinina", "mg/dL", 1)

    pts = [c["puntos"] for c in comp if c["puntos"] is not None]
    faltan = [c["item"] for c in comp if c["puntos"] is None]
    total = int(sum(pts))
    if not pts:
        nivel, color, texto = "SIN DATOS", COLORES["gris"], "No hay datos suficientes."
    elif total >= 10:
        nivel, color = "DISFUNCIÓN SEVERA", COLORES["rojo"]
        texto = "≥ 10 puntos (mínimo): disfunción orgánica múltiple."
    elif total >= 6:
        nivel, color = "DISFUNCIÓN MARCADA", COLORES["naranja"]
        texto = "6-9 puntos (mínimo): disfunción de varios órganos."
    elif total >= 2:
        nivel, color = "DISFUNCIÓN PRESENTE", COLORES["amarillo"]
        texto = "≥ 2 puntos: compatible con disfunción orgánica (con infección sospechada, criterio Sepsis-3)."
    else:
        nivel, color = "SIN DISFUNCIÓN EVIDENTE", COLORES["verde"]
        texto = "0-1 punto con los componentes disponibles."
    return {"nombre": "SOFA parcial", "valor": total if pts else None, "minimo": True, "max": 24,
            "nivel": nivel, "color": color, "interpretacion": texto, "componentes": comp, "faltantes": faltan,
            "limitaciones": ["Cardiovascular: sin dopamina/noradrenalina/adrenalina registradas (sólo PAM)",
                             "Renal: sin diuresis (sólo creatinina)",
                             "Ventana: peor valor de las últimas 24 h; sin valor basal previo del paciente"],
            "confianza": _confianza(comp), "cobertura": f"{len(pts)}/6"}


# ---------------------------------------------------------------------------
# APACHE II parcial
# ---------------------------------------------------------------------------
def _edad_paciente(base, estadia_id):
    e = base.ficha(estadia_id)["edad"]
    if e == "" or e is None:
        return None
    return 89 if e == "89+" else int(e)


def _apache(cx):
    comp = []

    def vital(item, variables, clave, tabla, unidad, dec, suavizar=True):
        p = cx.peor(variables, clave, tabla, suavizar=suavizar)
        if p:
            c = _comp(item, f"{p['valor']:.{dec}f} {unidad}", p["puntos"], p["edad_s"], "", p["ventana"])
            c["lab"] = False
            comp.append(c)
        else:
            comp.append(_falta(item, f"sin dato en 24 h" + (f" (último hace {cx.viejos[variables[0]] / 3600:.0f} h)" if variables[0] in cx.viejos else "")))

    vital("Temperatura", ["temperatura"], "temperatura", apache_temp, "°C", 1, suavizar=False)
    vital("Presión arterial media", ["pa_inv_media", "pa_ni_media"], "pam", apache_pam, "mmHg", 0)
    vital("Frecuencia cardíaca", ["fc"], "fc", apache_fc, "lpm", 0)
    vital("Frecuencia respiratoria", ["fr", "fr_total"], "fr", apache_fr, "rpm", 0)

    # Oxigenación: con FiO2 < 50 % se usa PaO2; con FiO2 ≥ 50 % hace falta el gradiente A-a (necesita PaCO2: no disponible)
    pares = _pares_pf(cx, VENTANA_PEOR_S)
    ventana = "24 h"
    if not pares:
        pares = _pares_pf(cx, LAB_MAX_S)[-1:]
        ventana = "último ≤ 72 h"
    if not pares:
        comp.append(_falta("Oxigenación", "sin gasometría ≤ 72 h con FiO2 asociada"))
    else:
        bajos = [p for p in pares if p["fio2"] < 50]
        altos = [p for p in pares if p["fio2"] >= 50]
        if bajos:
            peor = max(bajos, key=lambda p: apache_pao2(p["pao2"]) * 1000 - p["pao2"])
            c = _comp("Oxigenación (PaO2, FiO2 < 50 %)", f"{peor['pao2']:.0f} mmHg", apache_pao2(peor["pao2"]), cx.t - peor["t"],
                      f"FiO2 {peor['fio2']:.0f} %", ventana)
            c["lab"] = True
            comp.append(c)
        elif altos:
            comp.append(_falta("Oxigenación (A-aDO2, FiO2 ≥ 50 %)", "requiere PaCO2 (no disponible en la base)"))

    for item, var, tabla, modo, unidad, dec in [("Creatinina", "creatinina", apache_creat, "max", "mg/dL", 1)]:
        t, v = cx.ventana([var], var, VENTANA_PEOR_S)
        ventana = "24 h"
        if len(v) == 0:
            t, v = cx.ventana([var], var, LAB_MAX_S)
            t, v = t[-1:], v[-1:]
            ventana = "último ≤ 72 h"
        if len(v) == 0:
            comp.append(_falta(item, "sin dato ≤ 72 h"))
        else:
            pts = np.array([tabla(x) for x in v])
            i = int(np.flatnonzero(pts == pts.max())[-1])
            c = _comp(item, f"{v[i]:.{dec}f} {unidad}", int(pts[i]), cx.t - t[-1],
                      "sin duplicar por insuficiencia renal aguda (dato no disponible)", ventana)
            c["lab"] = True
            comp.append(c)

    g = cx.peor(["gcs_total"], "gcs_total", None, "min")
    if g:
        c = _comp("Glasgow (15 − GCS)", f"{g['valor']:.0f} pts", int(15 - g["valor"]), g["edad_s"],
                  "intubado: verbal no evaluable" if cx.intubado() else "", g["ventana"])
        c["lab"] = False
        comp.append(c)
    else:
        comp.append(_falta("Glasgow (15 − GCS)", "sin Glasgow en 24 h"))

    # Ítems que la base no tiene
    for nombre in ("pH arterial", "Sodio", "Potasio", "Hematocrito", "Leucocitos"):
        comp.append(_falta(nombre, "no está en la base"))
    edad = _edad_paciente(cx.base, cx.eid)
    if edad is not None:
        c = _comp("Edad", f"{edad} años", apache_edad(edad), None, "dato de la ficha")
        c["lab"] = False
        comp.append(c)
    else:
        comp.append(_falta("Edad", "sin dato de edad"))
    comp.append(_falta("Enfermedad crónica grave", "no está en la base (0 pts asumidos)"))

    pts = [c["puntos"] for c in comp if c["puntos"] is not None]
    evaluados = len(pts)
    faltan = [c["item"] for c in comp if c["puntos"] is None]
    total = int(sum(pts))
    # APACHE II tiene 14 ítems: 12 de fisiología aguda (APS), edad y enfermedad crónica
    return {"nombre": "APACHE II parcial", "valor": total if pts else None, "minimo": True, "max": 71,
            "nivel": "PARCIAL", "color": COLORES["gris"],
            "interpretacion": (f"{evaluados} de 14 ítems evaluados: es un valor MÍNIMO. No se convierte a mortalidad "
                               "porque faltan ítems (pH, Na, K, Hct, leucocitos, enfermedad crónica)."),
            "componentes": comp, "faltantes": faltan,
            "limitaciones": ["El APACHE II original se calcula con el peor valor de las primeras 24 h de UTI; "
                             "acá se usa el peor valor de las últimas 24 h",
                             "Temperatura de cualquier sitio (el original usa rectal)"],
            "confianza": _confianza(comp), "cobertura": f"{evaluados}/14"}


# ---------------------------------------------------------------------------
# Punto de entrada
# ---------------------------------------------------------------------------
_CACHE = {}


def calcular(base, estadia_id, t_s, completo=True):
    """Calcula los indicadores de una estadía en el instante t_s (con memoria de 15 s simulados).
    completo=False: sólo NEWS2 y qSOFA (liviano, para las tarjetas de la vista general)."""
    clave = (id(base), int(estadia_id), int(t_s // 15), bool(completo))
    if clave in _CACHE:
        return _CACHE[clave]
    if len(_CACHE) > 4000:
        _CACHE.clear()
    cx = _Ctx(base, estadia_id, t_s)
    news = _news2(cx)
    res = {"t_s": float(t_s), "news2": news, "qsofa": _qsofa(cx, news)}
    if completo:
        res.update({"shock": _shock(cx), "oxigenacion": _oxigenacion(cx), "sofa": _sofa(cx), "apache": _apache(cx)})
    res["descartes"] = list(dict.fromkeys(cx.descartes))
    _CACHE[clave] = res
    return res


def resumen_corto(res):
    """Texto para tarjetas: 'NEWS2 3'."""
    n = res["news2"]
    return "NEWS2 —" if n["valor"] is None else f"NEWS2 {'≥' if n['minimo'] else ''}{n['valor']}"


# ---------------------------------------------------------------------------
# Prueba por consola:  python scores_clinicos.py
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    # 1) Tablas contra ejemplos de la bibliografía
    assert [news2_fr(x) for x in (8, 10, 16, 22, 25)] == [3, 1, 0, 2, 3]
    assert [news2_spo2(x) for x in (91, 93, 95, 97)] == [3, 2, 1, 0]
    assert [news2_pas(x) for x in (90, 100, 110, 150, 220)] == [3, 2, 1, 0, 3]
    assert [news2_fc(x) for x in (40, 50, 80, 100, 120, 131)] == [3, 1, 0, 1, 2, 3]
    assert [news2_temp(x) for x in (35.0, 36.0, 37.0, 39.0, 39.1)] == [3, 1, 0, 1, 2]
    assert [sofa_resp_pf(x, True) for x in (450, 350, 250, 150, 80)] == [0, 1, 2, 3, 4]
    assert [sofa_resp_pf(x, False) for x in (150, 80)] == [2, 2]
    assert [sofa_coag(x) for x in (200, 120, 70, 30, 10)] == [0, 1, 2, 3, 4]
    assert [sofa_higado(x) for x in (0.8, 1.5, 3, 8, 15)] == [0, 1, 2, 3, 4]
    assert [sofa_snc(x) for x in (15, 14, 11, 7, 4)] == [0, 1, 2, 3, 4]
    assert [sofa_renal(x) for x in (0.9, 1.5, 2.5, 4, 6)] == [0, 1, 2, 3, 4]
    assert [apache_temp(x) for x in (41, 39.5, 38.6, 37, 35, 33, 31, 29)] == [4, 3, 1, 0, 1, 2, 3, 4]
    assert [apache_pam(x) for x in (170, 140, 120, 90, 60, 40)] == [4, 3, 2, 0, 2, 4]
    assert [apache_fc(x) for x in (190, 150, 120, 90, 60, 45, 30)] == [4, 3, 2, 0, 2, 3, 4]
    assert [apache_fr(x) for x in (55, 40, 30, 18, 11, 7, 4)] == [4, 3, 1, 0, 1, 2, 4]
    assert [apache_pao2(x) for x in (80, 65, 58, 50)] == [0, 1, 3, 4]
    assert [apache_creat(x) for x in (4, 2.5, 1.7, 1.0, 0.4)] == [4, 3, 2, 0, 2]
    assert [apache_edad(x) for x in (40, 50, 60, 70, 80)] == [0, 2, 3, 5, 6]
    print("Tablas de puntos: OK")

    # 2) Todas las estadías de la base en tres instantes
    import datos_db as ddb
    b = ddb.BaseUTI()
    print(f"Base: {b.ruta}\n")
    for t in (0, 900, 1800):
        print(f"===== t = {t} s =====")
        print(f"{'cama':>4} {'NEWS2':>7} {'qSOFA':>6} {'SOFA':>6} {'APACHE':>7} {'shock':>6} {'P/F':>5} {'S/F':>5} {'conf.':>6}  descartes")
        for cama in b.camas["cama_id"]:
            e = b.estadia_de_cama(int(cama))
            r = calcular(b, e, t)
            f = lambda s, mas="≥": "—" if s["valor"] is None else f"{mas if s['minimo'] else ''}{s['valor']}"
            ox = r["oxigenacion"]
            print(f"{int(cama):>4} {f(r['news2']):>7} {f(r['qsofa']):>6} {f(r['sofa']):>6} {f(r['apache']):>7} "
                  f"{f(r['shock']):>6} {'—' if not ox['pf'] else round(ox['pf']):>5} {'—' if not ox['sf'] else round(ox['sf']):>5} "
                  f"{r['sofa']['confianza']:>6}  {r['descartes']}")
        print()
