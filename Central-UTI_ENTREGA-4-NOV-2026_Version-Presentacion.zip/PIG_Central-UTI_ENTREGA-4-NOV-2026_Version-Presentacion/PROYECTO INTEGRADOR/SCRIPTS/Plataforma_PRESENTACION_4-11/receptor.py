# -*- coding: utf-8 -*-
"""
receptor.py — Módulo receptor de la central (RECIBIR · VALIDAR · ORDENAR · ALMACENAR TEMPORALMENTE).

Recibe los paquetes que publican los emisores (emisor.py) a través del canal (canal.py), los valida, los ordena
por instante de medición y los guarda en un búfer en memoria. Nunca escribe en benchmark_uti.db ni en ninguna base.

El Receptor HEREDA de datos_db.BaseUTI: expone la misma interfaz (snapshot, ultimo, serie, ficha, ...), de modo que
las reglas (reglas_basicas.evaluar) y los indicadores (scores_clinicos.calcular) funcionan igual leyendo del
receptor que leyendo de la base. Así la fuente de datos de la plataforma puede ser "base" o "receptor" sin tocar el resto.

Qué valida (cada hallazgo queda en `eventos_calidad` con su instante):
  rechazo_rango          valor imposible (fuera del rango del sensor): NO se almacena
  duplicado              paquete con un número de secuencia ya recibido: se descarta
  fuera_de_orden         paquete que llega después de uno más nuevo: se almacena en su lugar cronológico
  congelado              la misma lectura repetida N veces seguidas en una variable que debería variar (FC, PAM invasiva)
  sin_actualizacion      una variable que llegaba a ritmo normal dejó de llegar (sensor caído)
  perdida_comunicacion   la cama completa dejó de enviar paquetes
Los eventos con duración (congelado, sin_actualizacion, perdida_comunicacion) se abren al detectarlos y se cierran
cuando el dato vuelve a ser normal.
"""
import bisect
import math
from collections import defaultdict, deque

import numpy as np
import pandas as pd

import datos_db as ddb

# Rangos de sensor (mismos de la tabla `variables` de la base) + laboratorio (límites de plausibilidad)
RANGOS_DEFAULT = {
    "fc": (20, 300), "pulso": (20, 300), "spo2": (50, 100), "fr": (0, 80), "fr_total": (0, 80),
    "pa_inv_sis": (30, 300), "pa_inv_dia": (10, 200), "pa_inv_media": (20, 250),
    "pa_ni_sis": (30, 300), "pa_ni_dia": (10, 200), "pa_ni_media": (20, 250), "pvc": (-5, 40),
    "temperatura": (30, 45), "fio2": (21, 100), "gcs_total": (3, 15), "gcs_ocular": (1, 4), "gcs_motor": (1, 6),
    "gcs_verbal": (1, 5), "pao2": (20, 700), "creatinina": (0.1, 25), "bilirrubina_total": (0.1, 60),
    "plaquetas": (1, 1500),
}
CONGELABLES = ("fc", "pa_inv_media")           # variables que no deberían repetir exactamente el mismo valor
MONITOR_SEGUIDAS = ("fc", "spo2", "fr", "pa_inv_media", "pa_inv_sis")   # variables de monitor cuya llegada se vigila


class Receptor(ddb.BaseUTI):
    def __init__(self, rangos=None, anclaje=None, duracion_s=1800.0, total_camas=15,
                 stale_s=300.0, perdida_s=180.0, congelado_n=10, min_recepciones=3):
        # No se abre ninguna base: el estado es el búfer.
        from pathlib import Path
        from datetime import datetime
        self.ruta = Path("receptor_buffer_en_memoria")
        self.parametros = {}
        self.anclaje = anclaje or datetime(2026, 3, 15, 10, 0, 0)
        self.duracion_s = float(duracion_s)
        self.total_camas = int(total_camas)
        self.rangos = dict(RANGOS_DEFAULT)
        for var, (mn, mx) in (rangos or {}).items():          # los rangos sin límite en la base (laboratorio) conservan el valor por defecto
            d = self.rangos.get(var, (-math.inf, math.inf))
            self.rangos[var] = (d[0] if mn is None else mn, d[1] if mx is None else mx)
        self.unidades = {}
        self._series = {}
        self.tramos = pd.DataFrame(columns=["ruta_archivo", "fs", "canales", "duracion_s"]).rename_axis("estadia_id")

        self.stale_s, self.perdida_s, self.congelado_n, self.min_recepciones = stale_s, perdida_s, congelado_n, min_recepciones
        self._raw = {}                      # (estadia, variable) -> listas ordenadas por t
        self._dirty = set()
        self._est_de_cama = {}
        self._filas_est, self._filas_cama = {}, {}
        self._seq_vistos = set()
        self._max_emision = {}
        self._last_rx = {}                  # cama -> último instante de recepción
        self._last_var = {}                 # (cama, variable) -> último instante de recepción de esa variable
        self._n_stream = defaultdict(int)   # (cama, variable) -> recepciones desde que empezó el flujo
        self._recientes = defaultdict(lambda: deque(maxlen=self.congelado_n))
        self._abiertos = {}                 # (tipo, cama, variable) -> evento abierto
        self.eventos_calidad = []           # lista de dicts
        self.n_recibidos = 0
        self.n_medidas_aceptadas = 0
        self.n_medidas_rechazadas = 0
        self.flujo_iniciado = False
        self._refrescar()

    # ------------------------------------------------------------------ pacientes / camas
    def registrar_paciente(self, cama, estadia_id, edad=None, sexo="", unidad="", tipo_internacion="",
                           subject_id=None, t_ingreso_s=0.0, edad_anonimizada=0):
        eid = int(estadia_id)
        self._est_de_cama[int(cama)] = eid
        self._filas_est[eid] = {"estadia_id": eid, "subject_id": int(subject_id if subject_id is not None else eid),
                                "unidad": unidad, "tipo_internacion": tipo_internacion, "edad": edad, "sexo": sexo,
                                "edad_anonimizada": edad_anonimizada, "t_ingreso_s": t_ingreso_s}
        self._filas_cama[int(cama)] = {"cama_id": int(cama), "perfil_canales": None, "equipamiento": None,
                                       "estadia_actual": eid}
        self._refrescar()

    def _refrescar(self):
        cols_e = ["estadia_id", "subject_id", "unidad", "tipo_internacion", "edad", "sexo", "edad_anonimizada", "t_ingreso_s"]
        self.estadias = (pd.DataFrame(list(self._filas_est.values()), columns=cols_e)
                         .set_index("estadia_id", drop=False))
        self.camas = pd.DataFrame(list(self._filas_cama.values()),
                                  columns=["cama_id", "perfil_canales", "equipamiento", "estadia_actual"]).sort_values("cama_id")

    # ------------------------------------------------------------------ búfer ordenado
    def _insertar(self, eid, var, t, valor, texto, fuente, calidad=None):
        k = (eid, var)
        r = self._raw.get(k)
        if r is None:
            r = self._raw[k] = {"t": [], "v": [], "fuente": [], "texto": [], "calidad": []}
        i = bisect.bisect_right(r["t"], t)
        r["t"].insert(i, t)
        r["v"].insert(i, float("nan") if valor is None else float(valor))
        r["fuente"].insert(i, fuente)
        r["texto"].insert(i, texto)
        r["calidad"].insert(i, calidad)
        self._dirty.add(k)

    def _sync(self, eid, var):
        k = (int(eid), var)
        if k in self._dirty:
            r = self._raw[k]
            prio = np.array([ddb._PRIORIDAD_FUENTE.get(f, 0) for f in r["fuente"]])
            t = np.array(r["t"], float)
            orden = np.lexsort((prio, t))
            self._series[k] = {"t": t[orden], "v": np.array(r["v"], float)[orden],
                               "fuente": np.array(r["fuente"], dtype=object)[orden],
                               "texto": np.array(r["texto"], dtype=object)[orden],
                               "calidad": np.array(r["calidad"], dtype=object)[orden]}
            self._dirty.discard(k)

    def ultimo(self, estadia_id, variable, t_s):
        self._sync(estadia_id, variable)
        return super().ultimo(estadia_id, variable, t_s)

    def serie(self, estadia_id, variable, t_ini, t_fin, fuente=None):
        self._sync(estadia_id, variable)
        return super().serie(estadia_id, variable, t_ini, t_fin, fuente)

    # ------------------------------------------------------------------ eventos de calidad
    def _evento(self, tipo, cama, variable, t, detalle="", abierto=False):
        ev = {"tipo": tipo, "cama": int(cama), "variable": variable or "", "t_inicio": float(t),
              "t_fin": None if abierto else float(t), "detalle": detalle}
        self.eventos_calidad.append(ev)
        return ev

    def _abrir(self, tipo, cama, variable, t, detalle=""):
        k = (tipo, cama, variable)
        if k not in self._abiertos:
            self._abiertos[k] = self._evento(tipo, cama, variable, t, detalle, abierto=True)

    def _cerrar(self, tipo, cama, variable, t):
        ev = self._abiertos.pop((tipo, cama, variable), None)
        if ev is not None:
            ev["t_fin"] = float(t)

    def cerrar_todo(self, t):
        """Cierra los eventos que quedaron abiertos al terminar la simulación (t_fin = None se informa como abierto)."""
        for ev in list(self._abiertos.values()):
            ev["abierto_al_final"] = True

    def tabla_eventos(self):
        cols = ["tipo", "cama", "variable", "t_inicio", "t_fin", "detalle"]
        return pd.DataFrame(self.eventos_calidad, columns=cols + ["abierto_al_final"]) if self.eventos_calidad \
            else pd.DataFrame(columns=cols + ["abierto_al_final"])

    # ------------------------------------------------------------------ recepción
    def ingest(self, paquete, t_rec):
        """Recibe un paquete en el instante t_rec. Devuelve cuántas medidas se almacenaron."""
        cama = int(paquete["cama"])
        eid = self._est_de_cama.get(cama)
        if eid is None:
            self._evento("cama_desconocida", cama, "", t_rec, "paquete de una cama no registrada")
            return 0
        self.n_recibidos += 1
        clave = (cama, paquete["seq"])
        if clave in self._seq_vistos:
            self._evento("duplicado", cama, "", t_rec, f"seq {paquete['seq']} repetido")
            return 0
        self._seq_vistos.add(clave)
        t_em = float(paquete["t_emision"])
        if t_em < self._max_emision.get(cama, -math.inf) - 1e-9:
            self._evento("fuera_de_orden", cama, "", t_rec,
                         f"emitido en t={t_em:.0f} y recibido en t={t_rec:.0f} (ya había datos más nuevos)")
        self._max_emision[cama] = max(self._max_emision.get(cama, -math.inf), t_em)
        en_flujo = paquete.get("origen") != "historia"
        if en_flujo:
            self.flujo_iniciado = True
            self._last_rx[cama] = max(self._last_rx.get(cama, -math.inf), t_rec)
            self._cerrar("perdida_comunicacion", cama, "", t_rec)

        n_ok = 0
        for var, t_med, valor, texto, fuente in paquete["medidas"]:
            rng = self.rangos.get(var)
            if valor is not None and not (isinstance(valor, float) and math.isnan(valor)) and rng is not None \
                    and not (rng[0] <= valor <= rng[1]):
                self.n_medidas_rechazadas += 1
                self._evento("rechazo_rango", cama, var, t_rec, f"{var} = {valor:g} fuera de [{rng[0]}, {rng[1]}]")
                continue
            self._insertar(eid, var, float(t_med), valor, texto, fuente)
            self.n_medidas_aceptadas += 1
            n_ok += 1
            if en_flujo and valor is not None:
                self._last_var[(cama, var)] = max(self._last_var.get((cama, var), -math.inf), t_rec)
                self._n_stream[(cama, var)] += 1
                self._cerrar("sin_actualizacion", cama, var, t_rec)
                if var in CONGELABLES:
                    cola = self._recientes[(cama, var)]
                    cola.append(float(valor))
                    if len(cola) == self.congelado_n and max(cola) - min(cola) < 1e-9:
                        self._abrir("congelado", cama, var, t_rec, f"{self.congelado_n} lecturas idénticas = {valor:g}")
                    elif len(cola) == self.congelado_n:
                        self._cerrar("congelado", cama, var, t_rec)
        return n_ok

    # ------------------------------------------------------------------ vigilancia por tiempo
    def revisar(self, t):
        """Detecta lo que NO llegó: variables que dejaron de actualizarse y camas que dejaron de comunicar."""
        for cama in list(self._est_de_cama):
            ult = self._last_rx.get(cama)
            if ult is None:
                continue
            if t - ult > self.perdida_s:
                self._abrir("perdida_comunicacion", cama, "", t, f"sin paquetes desde t={ult:.0f}")
                continue
            for var in MONITOR_SEGUIDAS:
                if self._n_stream.get((cama, var), 0) < self.min_recepciones:
                    continue                        # la variable nunca estuvo "en servicio" en esta cama
                lv = self._last_var.get((cama, var))
                if lv is not None and t - lv > self.stale_s:
                    self._abrir("sin_actualizacion", cama, var, t, f"sin datos de {var} desde t={lv:.0f}")
