# -*- coding: utf-8 -*-
"""
validar_con_emisores.py — Validación de la central con emisores virtuales (versión mínima).

    cd "...\\PROYECTO INTEGRADOR\\SCRIPTS\\Plataforma"
    python validar_con_emisores.py                  (20 semillas, base benchmark_uti.db)
    python validar_con_emisores.py --semillas 50
    set UTI_DB=...\\benchmark_uti_validacion.db  &  python validar_con_emisores.py      (otra base para la parte "realista")

Qué hace (cada parte es independiente y deja su CSV):
  1. EQUIVALENCIA   Reproduce las 15 camas de la base por emisor -> canal -> receptor y verifica que la central ve lo mismo
                    que leyendo la base directamente. Las diferencias se explican por los valores que el receptor rechaza.
  2. ESCENARIOS     Camas sintéticas (ESTABLE, DETERIORO_HEMODINAMICO, DESATURACION) con muchas semillas. La respuesta correcta
                    sale de la señal limpia y de las definiciones del protocolo. Mide sensibilidad, falsas alarmas, latencia
                    y concordancia del NEWS2.
  3. FALLAS         Seis fallas de transmisión inyectadas en el canal sobre una cama estable. Mide cuántas detecta el receptor
                    (y cuántas detectan las reglas del motor) y con qué demora.
  4. INTEGRIDAD     Hash de la base antes y después: la base no se modifica.

Todo lo que genera va a SCRIPTS\\Validacion_emisores\\corrida_<fecha>\\ . No escribe en benchmark_uti.db.
"""
import argparse
import hashlib
import json
import sys
import time
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import datos_db as ddb                      # noqa: E402  (también deja config.py importable)
import reglas_basicas as reglas             # noqa: E402
import scores_clinicos as SC                # noqa: E402
import emisor as EM                         # noqa: E402
import canal as CN                          # noqa: E402
import receptor as RC                       # noqa: E402
from config import RAIZ, RUTA_BASE          # noqa: E402

# [integración 22/10/2026] Reglas v2: los umbrales salen de umbrales_validacion.csv (el motor ya no usa este dict;
# se pasa por compatibilidad y queda en el manifiesto solo como referencia histórica).
PROTOCOLO = {"especificacion": "umbrales_validacion.csv"}

# Qué regla de la central cuenta como "la alarma correcta" para cada evento esperado del protocolo.
# Los eventos se llaman igual que las reglas del motor v2 (emisor.CONDICIONES_PROTOCOLO sale de la misma especificación).
# Una ADVERTENCIA también se da por detectada si el motor ya alarma la CRÍTICA de la misma variable: el motor muestra
# un solo nivel por variable (el peor), y una caída rápida puede pasar de largo el nivel intermedio.
EQUIV = {}
for _ev, (_niv, _var) in EM.NIVEL_EVENTO.items():
    EQUIV[_ev] = {_ev} | ({e for e, (n, v) in EM.NIVEL_EVENTO.items() if v == _var and n == "CRITICA"}
                          if _niv == "ADVERTENCIA" else set())
TOL_ANTES_S, TOL_DESPUES_S = 180.0, 600.0       # una alarma "acierta" si empieza en [t_esperado - 180 s, t_esperado + 600 s]
TECNICAS = ("SIN_SENAL_", "DATO_VIEJO_", "FUERA_DE_RANGO_", "SENSOR_DESCONECTADO_", "SENAL_RESPIRATORIA_PERDIDA",
            "PVC_CONGELADA")


# ==============================================================================================
# Simulación: emisores -> canal -> receptor -> reglas
# ==============================================================================================
def simular(emisores, canal, receptor, dt=60.0, t_ini=0.0, t_fin=1800.0, usar_reglas=True, en_tick=None):
    for e in emisores:
        receptor.registrar_paciente(e.cama, **e.datos_paciente())
        receptor.ingest(e.historia(t_ini), t_ini - dt)
    abiertos, episodios = {}, []
    t = t_ini
    while t <= t_fin + 1e-9:
        for e in emisores:
            canal.enviar(e.paquete(t), t)
        for _, p in canal.entregar(t):
            receptor.ingest(p, t)
        receptor.revisar(t)
        if usar_reglas:
            for e in emisores:
                eid = receptor._est_de_cama[e.cama]
                activas = {a["regla"] for a in reglas.evaluar(receptor.snapshot(eid, t), PROTOCOLO, receptor)}
                for r in activas:
                    if (e.cama, r) not in abiertos:
                        abiertos[(e.cama, r)] = {"cama": e.cama, "regla": r, "t_inicio": t, "t_fin": None}
                for (c, r) in [k for k in abiertos if k[0] == e.cama and k[1] not in activas]:
                    ep = abiertos.pop((c, r))
                    ep["t_fin"] = t
                    episodios.append(ep)
        if en_tick:
            en_tick(t)
        t += dt
    episodios += list(abiertos.values())
    receptor.cerrar_todo(t_fin)
    return pd.DataFrame(episodios, columns=["cama", "regla", "t_inicio", "t_fin"])


def es_tecnica(regla):
    return regla.startswith(TECNICAS)


# ==============================================================================================
# 1. Equivalencia: la central ve lo mismo por el receptor que leyendo la base
# ==============================================================================================
def prueba_equivalencia(base, dt=60.0, ticks=(0, 300, 600, 900, 1200, 1500, 1800)):
    rec = RC.Receptor(rangos=base.rangos, anclaje=base.anclaje, duracion_s=base.duracion_s, total_camas=base.total_camas)
    emisores = [EM.EmisorReplay(base, int(c), dt) for c in base.camas["cama_id"] if base.estadia_de_cama(int(c))]
    diffs, filas_alarmas = [], []
    campos = ["fc", "spo2", "fr", "fio2", "gcs", "pas", "pad", "pam"]

    def comparar(t):
        if int(t) not in ticks:
            return
        for e in emisores:
            sb, sr = base.snapshot(e.estadia, t), rec.snapshot(e.estadia, t)
            for k in campos:
                a, b = sb[k], sr[k]
                if (a is None) != (b is None) or (a is not None and abs(a - b) > 1e-6):
                    diffs.append({"t_s": t, "cama": e.cama, "campo": k, "base": a, "receptor": b})
            if sb["pa_origen"] != sr["pa_origen"]:
                diffs.append({"t_s": t, "cama": e.cama, "campo": "pa_origen", "base": sb["pa_origen"], "receptor": sr["pa_origen"]})
            ab = sorted(a["regla"] for a in reglas.evaluar(sb, PROTOCOLO, base))
            ar = sorted(a["regla"] for a in reglas.evaluar(sr, PROTOCOLO, rec))
            if ab != ar:
                filas_alarmas.append({"t_s": t, "cama": e.cama, "alarmas_base": ";".join(ab), "alarmas_receptor": ";".join(ar)})

    simular(emisores, CN.Canal(), rec, dt, 0.0, base.duracion_s, usar_reglas=False, en_tick=comparar)
    n_comp = len(ticks) * len(emisores) * (len(campos) + 1)
    return {"n_comparaciones": n_comp, "diferencias": pd.DataFrame(diffs), "alarmas_distintas": pd.DataFrame(filas_alarmas),
            "eventos_calidad": rec.tabla_eventos(), "recibidos": rec.n_recibidos,
            "aceptadas": rec.n_medidas_aceptadas, "rechazadas": rec.n_medidas_rechazadas}


# ==============================================================================================
# 2. Escenarios sintéticos
# ==============================================================================================
def news2_esperado(c):
    """NEWS2 de la señal limpia (aire ambiente, Glasgow 15, temperatura 36,8): referencia independiente del módulo de scores."""
    return (SC.news2_fr(round(c["fr"])) + SC.news2_spo2(round(c["spo2"])) + SC.news2_pas(round(c["pas"]))
            + SC.news2_fc(round(c["fc"])) + SC.news2_temp(36.8))


def evaluar_escenario(emisores, episodios, rec, dt):
    esp, obs_ok = [], set()
    for e in emisores:
        ep_cama = episodios[episodios["cama"] == e.cama] if not episodios.empty else episodios
        for x in e.eventos_esperados():
            reglas_ok = EQUIV.get(x["evento"], set())
            cand = ep_cama[ep_cama["regla"].isin(reglas_ok) & (ep_cama["t_inicio"] >= x["t_esperado"] - TOL_ANTES_S)
                           & (ep_cama["t_inicio"] <= x["t_esperado"] + TOL_DESPUES_S)] if reglas_ok and not ep_cama.empty else None
            if cand is not None and len(cand):
                primero = cand.sort_values("t_inicio").iloc[0]
                obs_ok.update(cand.index.tolist())
                esp.append(dict(x, resultado="detectada", regla=primero["regla"], t_alarma=primero["t_inicio"],
                                latencia_s=primero["t_inicio"] - x["t_esperado"]))
            else:
                motivo = "no_detectada" if reglas_ok else "regla_no_implementada"
                if reglas_ok and not ep_cama.empty:
                    # ¿había otra alarma clínica activa que la haya tapado? (las reglas v0 están encadenadas con if/elif)
                    act = ep_cama[~ep_cama["regla"].map(es_tecnica) & (ep_cama["t_inicio"] <= x["t_esperado"] + TOL_DESPUES_S)
                                  & (ep_cama["t_fin"].isna() | (ep_cama["t_fin"] >= x["t_esperado"]))]
                    if len(act):
                        motivo = "enmascarada_por_" + "+".join(sorted(set(act["regla"])))
                esp.append(dict(x, resultado=motivo, regla="", t_alarma=np.nan, latencia_s=np.nan))
    falsas = []
    por_cama = {e.cama: e for e in emisores}
    if not episodios.empty:
        for i, ep in episodios.iterrows():
            if es_tecnica(ep["regla"]) or i in obs_ok:
                continue
            # [integración] Un episodio nuevo de una condición que en la señal limpia SIGUE vigente no es una falsa
            # alarma: es una re-notificación (la alarma se apagó y volvió, p. ej. al alternar entre TAQUIPNEA y
            # TAQUIPNEA_SEVERA cerca del umbral). Se informa aparte, porque suma carga de alarmas (escenario G03).
            vigente = _condicion_vigente(por_cama.get(ep["cama"]), ep["regla"], ep["t_inicio"])
            falsas.append({"cama": ep["cama"], "regla": ep["regla"], "t_inicio": ep["t_inicio"], "t_fin": ep["t_fin"],
                           "tipo": "re-notificación" if vigente else "falsa"})
    return esp, falsas


def _condicion_vigente(emisor, regla, t, ventana_s=TOL_ANTES_S):
    """¿Algún evento del protocolo que esta regla alarma se cumple en la señal limpia en [t - ventana, t]?"""
    if emisor is None or not hasattr(emisor, "limpia"):
        return False
    eventos = [ev for ev, reglas_ok in EQUIV.items() if regla in reglas_ok]
    for tt in np.arange(max(t - ventana_s, 0.0), t + 1e-9, 60.0):
        c = dict(emisor.limpia(tt))
        s = dict(c, pam=EM._pam(c["pas"], c["pad"]))
        if any(EM.CONDICIONES_PROTOCOLO[ev](s) for ev in eventos):
            return True
    return False


def suite_escenarios(n_semillas, dt, t_fin=1800.0):
    filas_esp, filas_falsas, filas_tec, filas_news = [], [], [], []
    nombres = list(EM.ESCENARIOS)
    for semilla in range(n_semillas):
        emisores = [EM.EmisorSintetico(i + 1, nombre, semilla, dt, 0.0, t_fin) for i, nombre in enumerate(nombres)]
        rec = RC.Receptor(duracion_s=t_fin, total_camas=len(emisores))
        snaps = {}

        def capturar(t, rec=rec, emisores=emisores, snaps=snaps):
            if int(t) % 300 == 0:
                for e in emisores:
                    r = SC.calcular(rec, e.estadia, t, completo=False)["news2"]
                    snaps[(e.cama, int(t))] = r["valor"]
        episodios = simular(emisores, CN.Canal(), rec, dt, 0.0, t_fin, True, capturar)
        esp, falsas = evaluar_escenario(emisores, episodios, rec, dt)
        for f in esp:
            filas_esp.append(f)
        for f in falsas:
            filas_falsas.append(dict(f, semilla=semilla, escenario=nombres[int(f["cama"]) - 1]))
        if not episodios.empty:
            for _, ep in episodios[episodios["regla"].map(es_tecnica)].iterrows():
                filas_tec.append(dict(ep, semilla=semilla, escenario=nombres[int(ep["cama"]) - 1]))
        for e in emisores:
            for t in range(0, int(t_fin) + 1, 300):
                esperado = news2_esperado(dict(e.limpia(t)))
                obtenido = snaps.get((e.cama, t))
                filas_news.append({"semilla": semilla, "escenario": e.escenario, "t_s": t, "news2_esperado": esperado,
                                   "news2_central": obtenido, "diferencia": None if obtenido is None else obtenido - esperado})
    return (pd.DataFrame(filas_esp), pd.DataFrame(filas_falsas), pd.DataFrame(filas_tec), pd.DataFrame(filas_news))


# ==============================================================================================
# 3. Fallas de transmisión
# ==============================================================================================
def construir_falla(tipo, cama, rng, dt):
    t_ini = float(dt * rng.integers(7, 14))            # entre 420 s y 780 s
    if tipo == "congelado":
        return CN.Falla(tipo, cama, t_ini, t_ini + 900.0, variables=("fc",))
    if tipo == "caida_canal":
        return CN.Falla(tipo, cama, t_ini, t_ini + 600.0, variables=("spo2",))
    if tipo == "valor_imposible":
        return CN.Falla(tipo, cama, t_ini, t_ini + 3 * dt, variables=("spo2",), valor=127.0)
    if tipo == "perdida_comunicacion":
        return CN.Falla(tipo, cama, t_ini, t_ini + 480.0)
    if tipo == "retraso":
        return CN.Falla(tipo, cama, t_ini, t_ini + 2 * dt, demora_s=300.0)
    if tipo == "duplicado":
        return CN.Falla(tipo, cama, t_ini, t_ini + 3 * dt)
    raise ValueError(tipo)


TIPOS_FALLA = ["congelado", "caida_canal", "valor_imposible", "perdida_comunicacion", "retraso", "duplicado"]


def suite_fallas(n_semillas, dt, t_fin=1800.0):
    filas = []
    for semilla in range(n_semillas):
        rng = np.random.default_rng([semilla, 77])
        emisores = [EM.EmisorSintetico(i + 1, "ESTABLE", semilla, dt, 0.0, t_fin) for i in range(len(TIPOS_FALLA))]
        fallas = [construir_falla(tipo, i + 1, rng, dt) for i, tipo in enumerate(TIPOS_FALLA)]
        rec = RC.Receptor(duracion_s=t_fin, total_camas=len(emisores))
        episodios = simular(emisores, CN.Canal(fallas), rec, dt, 0.0, t_fin, True)
        ev = rec.tabla_eventos()
        for f in fallas:
            x = f.esperado()
            sel = ev[(ev["tipo"] == x["evento"]) & (ev["cama"] == f.cama)] if not ev.empty else ev
            if x["variables"] and not sel.empty:
                sel = sel[sel["variable"] == x["variables"]]
            sel = sel[(sel["t_inicio"] >= x["t_posible"]) & (sel["t_inicio"] <= x["t_fin"] + 900.0)] if not sel.empty else sel
            det = not sel.empty
            lat = float(sel["t_inicio"].min() - x["t_posible"]) if det else np.nan
            ep = episodios[(episodios["cama"] == f.cama) & episodios["regla"].map(es_tecnica)] if not episodios.empty else episodios
            ep = ep[(ep["t_inicio"] >= x["t_ini"]) & (ep["t_inicio"] <= x["t_fin"] + 600.0)] if not ep.empty else ep
            filas.append({"semilla": semilla, "falla": f.tipo, "cama": f.cama, "variables": x["variables"], "t_ini": x["t_ini"],
                          "t_fin": x["t_fin"], "evento_esperado": x["evento"], "detectada_receptor": det,
                          "latencia_receptor_s": lat, "detectada_reglas_v0": not ep.empty,
                          "reglas_v0": ";".join(sorted(set(ep["regla"]))) if not ep.empty else ""})
        # falsas alarmas clínicas durante las fallas (la cama es estable: ninguna alarma clínica es correcta)
        if not episodios.empty:
            for _, e in episodios[~episodios["regla"].map(es_tecnica)].iterrows():
                filas.append({"semilla": semilla, "falla": "(alarma clínica durante falla)", "cama": e["cama"],
                              "variables": e["regla"], "t_ini": e["t_inicio"], "t_fin": e["t_fin"], "evento_esperado": "",
                              "detectada_receptor": False, "latencia_receptor_s": np.nan, "detectada_reglas_v0": False, "reglas_v0": ""})
    return pd.DataFrame(filas)


# ==============================================================================================
# Resúmenes
# ==============================================================================================
def resumen_escenarios(esp, falsas, n_semillas, t_fin):
    filas = []
    for (esc, ev), g in esp.groupby(["escenario", "evento"]):
        det = g[g["resultado"] == "detectada"]
        filas.append({"escenario": esc, "evento_esperado": ev, "n": len(g), "detectadas": len(det),
                      "sensibilidad_%": round(100 * len(det) / len(g), 1),
                      "latencia_mediana_s": round(det["latencia_s"].median(), 0) if len(det) else np.nan,
                      "latencia_p90_s": round(det["latencia_s"].quantile(0.9), 0) if len(det) else np.nan,
                      "motivo_si_falla": ", ".join(f"{k} ({v})" for k, v in g[g["resultado"] != "detectada"]["resultado"].value_counts().items())})
    return pd.DataFrame(filas)


def resumen_fallas(df):
    d = df[~df["falla"].str.startswith("(")]
    filas = []
    for f, g in d.groupby("falla", sort=False):
        det = g[g["detectada_receptor"]]
        filas.append({"falla": f, "n": len(g), "detectadas_receptor_%": round(100 * g["detectada_receptor"].mean(), 1),
                      "latencia_mediana_s": round(det["latencia_receptor_s"].median(), 0) if len(det) else np.nan,
                      "detectadas_reglas_v0_%": round(100 * g["detectada_reglas_v0"].mean(), 1)})
    return pd.DataFrame(filas)


def sha256(ruta):
    h = hashlib.sha256()
    with open(ruta, "rb") as f:
        for bloque in iter(lambda: f.read(1 << 20), b""):
            h.update(bloque)
    return h.hexdigest()


# ==============================================================================================
def main():
    ap = argparse.ArgumentParser(description="Validación de la central con emisores virtuales")
    ap.add_argument("--semillas", type=int, default=20)
    ap.add_argument("--dt", type=float, default=60.0, help="período de emisión en segundos")
    ap.add_argument("--base", default=None, help="ruta de la base para la parte de equivalencia (por defecto la de config.py / UTI_DB)")
    ap.add_argument("--salida", default=None, help="carpeta de salida")
    ap.add_argument("--sin-equivalencia", action="store_true")
    a = ap.parse_args()

    ruta_base = Path(a.base or RUTA_BASE)
    sello = datetime.now().strftime("%Y%m%d_%H%M%S")
    salida = Path(a.salida) if a.salida else RAIZ / "SCRIPTS" / "Validacion_emisores" / f"corrida_{sello}"
    salida.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    hash_antes = sha256(ruta_base) if ruta_base.exists() else None
    lineas = [f"VALIDACIÓN CON EMISORES VIRTUALES · {datetime.now():%d/%m/%Y %H:%M}",
              f"Base de reproducción: {ruta_base.name} · semillas: {a.semillas} · período de emisión: {a.dt:.0f} s",
              f"Referencia del protocolo: umbrales_validacion.csv (la misma especificación del motor v2 y del Paso10)", ""]

    # ---- 1. equivalencia
    if not a.sin_equivalencia and ruta_base.exists():
        print("1/3 Equivalencia (reproducción de las 15 camas)...", flush=True)
        base = ddb.BaseUTI(ruta_base)
        r = prueba_equivalencia(base, a.dt)
        r["diferencias"].to_csv(salida / "equivalencia_diferencias.csv", index=False, encoding="utf-8-sig")
        r["alarmas_distintas"].to_csv(salida / "equivalencia_alarmas_distintas.csv", index=False, encoding="utf-8-sig")
        r["eventos_calidad"].to_csv(salida / "equivalencia_eventos_calidad_receptor.csv", index=False, encoding="utf-8-sig")
        nd = len(r["diferencias"])
        lineas += ["1. EQUIVALENCIA · el receptor ve lo mismo que la base",
                   f"   paquetes recibidos: {r['recibidos']} · medidas aceptadas: {r['aceptadas']} · rechazadas por rango: {r['rechazadas']}",
                   f"   comparaciones de instantánea (7 instantes x 15 camas): {r['n_comparaciones']} · diferencias: {nd}",
                   f"   instantes cama con alarmas distintas entre base y receptor: {len(r['alarmas_distintas'])}"]
        if not r["eventos_calidad"].empty:
            lineas.append("   eventos de calidad detectados en los datos reales: " +
                          ", ".join(f"{k}: {v}" for k, v in r["eventos_calidad"]["tipo"].value_counts().items()))
        if nd:
            lineas.append("   (las diferencias corresponden a valores que el receptor rechazó por estar fuera de rango; ver el CSV)")
        lineas.append("")

    # ---- 2. escenarios
    print(f"2/3 Escenarios sintéticos ({a.semillas} semillas x 3 escenarios)...", flush=True)
    esp, falsas, tec, news = suite_escenarios(a.semillas, a.dt)
    esp.to_csv(salida / "escenarios_esperado_vs_observado.csv", index=False, encoding="utf-8-sig")
    falsas.to_csv(salida / "escenarios_falsas_alarmas.csv", index=False, encoding="utf-8-sig")
    tec.to_csv(salida / "escenarios_alarmas_tecnicas.csv", index=False, encoding="utf-8-sig")
    news.to_csv(salida / "escenarios_concordancia_news2.csv", index=False, encoding="utf-8-sig")
    res = resumen_escenarios(esp, falsas, a.semillas, 1800.0)
    res.to_csv(salida / "resumen_escenarios.csv", index=False, encoding="utf-8-sig")
    horas = a.semillas * 3 * 1800.0 / 3600.0
    n_total, n_det = len(esp), int((esp["resultado"] == "detectada").sum())
    renot = falsas[falsas["tipo"] == "re-notificación"] if len(falsas) else falsas
    falsas = falsas[falsas["tipo"] == "falsa"] if len(falsas) else falsas
    nws = news.dropna(subset=["diferencia"])
    lineas += ["2. ESCENARIOS SINTÉTICOS · sensibilidad y latencia por evento esperado",
               res.to_string(index=False),
               f"   Sensibilidad global: {n_det}/{n_total} = {100 * n_det / n_total:.1f} %",
               f"   Falsas alarmas clínicas: {len(falsas)} en {horas:.0f} h simuladas ({len(falsas) / horas:.2f} por hora-cama)"]
    if len(falsas):
        lineas.append("   por escenario/regla: " + "; ".join(f"{k[0]}/{k[1]}: {v}" for k, v in falsas.groupby(["escenario", "regla"]).size().items()))
    lineas.append(f"   Re-notificaciones (la condición seguía vigente en la señal limpia; la alarma se apagó y volvió): {len(renot)}"
                  + (" -> " + "; ".join(f"{k[0]}/{k[1]}: {v}" for k, v in renot.groupby(["escenario", "regla"]).size().items())
                     if len(renot) else ""))
    lineas += [f"   Alarmas técnicas en camas sin falla (debería ser 0): {len(tec)}",
               f"   Concordancia del NEWS2 (central vs. señal limpia): exacta en {100 * (nws['diferencia'] == 0).mean():.1f} % de {len(nws)} comparaciones; "
               f"diferencia absoluta media {nws['diferencia'].abs().mean():.2f} puntos (el ruido y el redondeo del monitor mueven el valor ±1)",
               ""]

    # ---- 3. fallas
    print(f"3/3 Fallas de transmisión ({a.semillas} semillas x 6 fallas)...", flush=True)
    fal = suite_fallas(a.semillas, a.dt)
    fal.to_csv(salida / "fallas_detalle.csv", index=False, encoding="utf-8-sig")
    rf = resumen_fallas(fal)
    rf.to_csv(salida / "resumen_fallas.csv", index=False, encoding="utf-8-sig")
    solo = fal[~fal["falla"].str.startswith("(")]
    lineas += ["3. FALLAS DE TRANSMISIÓN · detección por el receptor y por las reglas del motor", rf.to_string(index=False),
               f"   Tasa de detección global (receptor): {100 * solo['detectada_receptor'].mean():.1f} %",
               f"   Alarmas clínicas falsas disparadas por las fallas: {int(fal['falla'].str.startswith('(').sum())}", ""]

    # ---- 4. integridad
    hash_despues = sha256(ruta_base) if ruta_base.exists() else None
    ok = hash_antes == hash_despues
    lineas += ["4. INTEGRIDAD DE LA BASE",
               f"   {ruta_base.name}: {'SIN CAMBIOS (hash idéntico antes y después)' if ok else '¡CAMBIÓ! revisar'}",
               f"   sha256: {hash_despues}", f"   duración de la corrida: {time.time() - t0:.0f} s", f"   resultados en: {salida}"]
    texto = "\n".join(lineas)
    (salida / "resumen.txt").write_text(texto, encoding="utf-8")
    (salida / "manifiesto.json").write_text(json.dumps({
        "fecha": datetime.now().isoformat(timespec="seconds"), "base": str(ruta_base), "sha256_antes": hash_antes,
        "sha256_despues": hash_despues, "semillas": a.semillas, "dt_s": a.dt, "protocolo": PROTOCOLO,
        "equivalencias_regla": {k: sorted(v) for k, v in EQUIV.items()}, "tolerancia_s": [TOL_ANTES_S, TOL_DESPUES_S]},
        indent=2, ensure_ascii=False), encoding="utf-8")
    print("\n" + texto)


if __name__ == "__main__":
    main()
