# -*- coding: utf-8 -*-
"""
enlace.py — Fuente de datos "EMISORES VIRTUALES" de la plataforma (emisores -> canal -> receptor).

La interfaz puede alimentarse de dos orígenes:
  BASE DE DATOS         lectura directa de benchmark_uti.db (datos_db.BaseUTI, solo lectura).
  EMISORES VIRTUALES    un emisor por cama publica paquetes cada `dt` s; viajan por el canal (con o sin fallas de
                        transmisión) y los recibe el Receptor, que los valida y los guarda en memoria.
                        El Receptor tiene la misma interfaz que BaseUTI, así que reglas, scores y pantallas no cambian.

Un Enlace acompaña al reloj de simulación: `avanzar(t)` emite y entrega todo lo que corresponde hasta t.
Si el reloj retrocede (IR a un instante anterior o REINICIAR) el enlace se reconstruye desde cero.
Nada de esto escribe en la base: los emisores de reproducción la leen con `?mode=ro` a través de BaseUTI.
"""
import canal as CN
import emisor as EM
import receptor as RC

TIPOS = {
    "replay": "REPRODUCCION DE LA BASE (las 15 camas por el canal)",
    "sintetico": "SINTETICO POR ESCENARIOS (una cama = un escenario)",
}
ROTACION_ESCENARIOS = ["ESTABLE", "DETERIORO_HEMODINAMICO", "DESATURACION"]


def fallas_demostracion():
    """Fallas de transmisión de demostración (una de cada tipo, en camas distintas). Son datos de ejemplo:
    sirven para ver cómo reacciona el receptor y las reglas técnicas; no forman parte de la validación."""
    F = CN.Falla
    return [
        F("congelado", 3, 300.0, 1000.0, variables=("fc",)),
        F("caida_canal", 5, 400.0, 1000.0, variables=("spo2",)),
        F("valor_imposible", 7, 600.0, 720.0, variables=("fc",), valor=999.0),
        F("perdida_comunicacion", 9, 700.0, 1000.0),
        F("retraso", 11, 500.0, 800.0, demora_s=240.0),
        F("duplicado", 12, 600.0, 720.0),
    ]


class Enlace:
    def __init__(self, base_real, tipo="replay", con_fallas=False, semilla=1, dt_s=60.0):
        if tipo not in TIPOS:
            raise ValueError(f"tipo de emisor desconocido: {tipo}")
        self.base_real, self.tipo, self.con_fallas = base_real, tipo, bool(con_fallas)
        self.semilla, self.dt = int(semilla), float(dt_s)
        self._construir()

    # ------------------------------------------------------------------------------------------
    def _construir(self):
        b = self.base_real
        rec = RC.Receptor(rangos=b.rangos, anclaje=b.anclaje, duracion_s=b.duracion_s, total_camas=b.total_camas)
        rec.parametros = dict(b.parametros)
        rec.unidades = dict(b.unidades)
        camas = [int(c) for c in b.camas["cama_id"]]
        if self.tipo == "replay":
            self.emisores = [EM.EmisorReplay(b, c, self.dt) for c in camas if b.estadia_de_cama(c)]
            rec.tramos = b.tramos.copy()          # la señal continua (ECG/ABP/PLETH) se sigue leyendo del tramo registrado
        else:
            self.emisores = [EM.EmisorSintetico(c, ROTACION_ESCENARIOS[(c - 1) % len(ROTACION_ESCENARIOS)], self.semilla,
                                                self.dt, 0.0, b.duracion_s) for c in camas]
        for e in self.emisores:
            rec.registrar_paciente(e.cama, **e.datos_paciente())
            rec.ingest(e.historia(0.0), -self.dt)
        self.receptor = rec
        self.canal = CN.Canal(fallas_demostracion() if self.con_fallas else [])
        self._proximo = 0.0                         # próximo instante de emisión
        self._t = 0.0

    def reiniciar(self):
        self._construir()

    # ------------------------------------------------------------------------------------------
    def avanzar(self, t):
        """Emite y entrega todos los paquetes con instante de emisión <= t."""
        t = float(t)
        if t < self._t - 1e-9:                      # el reloj retrocedió: se reconstruye
            self._construir()
        self._t = t
        while self._proximo <= t + 1e-9:
            tk = self._proximo
            for e in self.emisores:
                self.canal.enviar(e.paquete(tk), tk)
            for _, p in self.canal.entregar(tk):
                self.receptor.ingest(p, tk)
            self.receptor.revisar(tk)
            self._proximo += self.dt
        return self.receptor

    # ------------------------------------------------------------------------------------------
    def descripcion(self):
        extra = " | canal con fallas de demostración" if self.con_fallas else " | canal sin fallas"
        return TIPOS[self.tipo] + extra

    def resumen(self):
        r = self.receptor
        return {"paquetes_recibidos": r.n_recibidos, "medidas_aceptadas": r.n_medidas_aceptadas,
                "medidas_rechazadas": r.n_medidas_rechazadas, "eventos_de_calidad": len(r.eventos_calidad)}
