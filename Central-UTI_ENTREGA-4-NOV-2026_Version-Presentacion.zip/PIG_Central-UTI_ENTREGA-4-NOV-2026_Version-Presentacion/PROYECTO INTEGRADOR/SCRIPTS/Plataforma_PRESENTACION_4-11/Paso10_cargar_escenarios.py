#!/usr/bin/env python
# coding: utf-8
# ============================================================
# Paso10_cargar_escenarios.py
# Carga el catálogo de escenarios v3 en benchmark_uti.db y etiqueta los eventos reales.
#
# Qué hace
#   1) Recrea las tablas de verdad-terreno (ocultas a la plataforma):
#        escenarios, asignaciones, eventos_esperados, fallas_tecnicas, esperado_cama
#      (asignaciones pasa a permitir varios escenarios por cama).
#   2) Carga catalogo_escenarios_v3.csv  -> escenarios + asignaciones (camas reales).
#   3) Carga plan_inyeccion_v3.csv       -> fallas_tecnicas / eventos_esperados + asignaciones (camas inyectadas).
#   4) Etiqueta los eventos REALES de los datos crudos con un criterio escrito aparte del motor de la
#      plataforma (así el motor se valida contra algo que no es él mismo).
#
# Uso (desde Anaconda Prompt, en la carpeta Plataforma; los dos CSV junto al script o en SCRIPTS):
#       python Paso10_cargar_escenarios.py                 # trabaja sobre la base de config.py y hace backup antes
#       python Paso10_cargar_escenarios.py RUTA.db         # otra base
#       python Paso10_cargar_escenarios.py --solo-copia    # no toca la original: crea y modifica benchmark_uti_paso10.db
#       python Paso10_cargar_escenarios.py --restaurar     # vuelve a la base anterior (el último backup)
#
# Seguridad de la base original
#   - Antes de modificar nada copia la base a SCRIPTS\Respaldo_BD\benchmark_uti_ANTES_PASO10_<fecha-hora>.db
#     (usa la API de respaldo de SQLite y verifica la copia; si el respaldo falla, el script se detiene sin tocar nada).
#   - La primera vez deja además benchmark_uti_ORIGINAL.db (copia maestra; nunca se vuelve a sobrescribir).
#   - Toda la carga se hace en una sola transacción: si algo falla a mitad de camino, la base queda como estaba.
#   - Si la base está abierta por la plataforma (Streamlit), SQLite la bloquea: cerrá Streamlit antes de correrlo.
#   No toca mediciones, estadías ni las vistas visibles. Se puede repetir cuantas veces haga falta.
#   Si existe huecos_naturales.csv, lo carga como tabla `huecos_naturales` (momentos en que el dato real ya falta).
#
# Reglas v2 de Celeste (22/10/2026, documento «Reglas de validación: propuesta de decisiones», D1 a D7)
#   - Los umbrales y parámetros se leen de umbrales_validacion.csv y parametros_validacion.csv
#     (misma especificación que el motor; el código que la aplica es independiente).
#   - D1: el desvío leve (antes nivel 1 = REQUIERE REVISION) ya no es alarma. REQUIERE REVISION
#     queda solo para fallas técnicas. Nueva columna `prioridad` (alta / media / baja).
#   - D2: cada falla técnica lleva la prioridad de su escenario.
#   - D4: umbrales nuevos (FC 111/131/40, SpO2 90/85, FR, PAM 65/55, PAS 180/220) y reglas combinadas
#     (SHOCK y RESP) también para los eventos reales.
#   - D6: la PA no invasiva (chartevents) se etiqueta: cada medición vale hasta la siguiente o hasta
#     su vigencia (60 min), sin persistencia.
#   - D7: nueva columna `clave` (variable o regla) para emparejar con las alarmas de la plataforma.
#   - Un 0 en FC, SpO2 o PA invasiva = desconexión (A01 / A02 / A04, prioridad media); otros valores
#     fuera de rango = valor imposible (A09, prioridad baja).
#
# IMPORTANTE: el etiquetado verifica que el motor aplique bien los criterios definidos (verificación),
# no prueba que los criterios sean clínicamente óptimos (eso lo respalda la bibliografía).
# ============================================================

import argparse
import csv
import json
import shutil
import sqlite3
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from config import CARPETA_DATOS, DURACION_TRAMO_S
    try:
        from config import BASE_ORIGINAL as RUTA_BASE      # siempre la original, aunque UTI_DB apunte a la copia de validación
    except ImportError:
        from config import RUTA_BASE
except ImportError:                                   # permite probarlo suelto
    RUTA_BASE = Path("benchmark_uti.db")
    CARPETA_DATOS = Path(".")
    DURACION_TRAMO_S = 1800

NIVELES = ["ESTABLE", "REQUIERE REVISION", "ADVERTENCIA", "CRITICA"]
NUM_NIVEL = {"ADVERTENCIA": 2, "CRITICA": 3}
PRIORIDAD_FISIOLOGICA = {3: "alta", 2: "media"}

QUIEN = Path(__file__).resolve().parent
_ap = argparse.ArgumentParser(description="Carga el catálogo de escenarios v3 en la base de benchmark (con respaldo previo).")
_ap.add_argument("base", nargs="?", default=None, help="ruta de la base (por defecto, la de config.py)")
_ap.add_argument("--solo-copia", action="store_true", help="no toca la base original: trabaja sobre benchmark_uti_paso10.db")
_ap.add_argument("--restaurar", action="store_true", help="restaura el último respaldo ANTES_PASO10 sobre la base y termina")
_ap.add_argument("--sin-respaldo", action="store_true", help="(no recomendado) omite el respaldo previo")
ARGS = _ap.parse_args()
BASE = Path(ARGS.base) if ARGS.base else Path(RUTA_BASE)
CARPETA_RESPALDO = BASE.parent / "Respaldo_BD"


def buscar(nombre):
    # [parche 22/10] también busca en PROYECTO INTEGRADOR (donde el LEEME de la entrega manda dejar los dos CSV de especificación)
    for c in (QUIEN, QUIEN.parent, QUIEN.parent.parent, Path(CARPETA_DATOS), Path(CARPETA_DATOS).parent, Path.cwd()):
        if (c / nombre).exists():
            return c / nombre
    raise FileNotFoundError(f"No encuentro {nombre}. Dejalo junto a este script o en SCRIPTS.")


# ------------------------------------------------------------
# Especificación (umbrales_validacion.csv + parametros_validacion.csv)
# ------------------------------------------------------------
UMBRALES = pd.read_csv(buscar("umbrales_validacion.csv"), encoding="utf-8-sig")
_PAR = pd.read_csv(buscar("parametros_validacion.csv"), encoding="utf-8-sig").set_index("clave")["valor"].to_dict()

PERSISTENCIA_MUESTRAS = int(_PAR["persistencia_muestras"])
SALTO_MAX_S = float(_PAR["salto_max_s"])
VIGENCIA_MONITOR_S = float(_PAR["vigencia_monitor_s"])
VIGENCIA_PNI_S = float(_PAR["vigencia_pni_s"])
FR0_SPO2_MIN = float(_PAR["fr0_spo2_min"])
PVC_MUESTRAS = int(_PAR["pvc_congelada_muestras"])
TOL_FISIOLOGICO_S = float(_PAR["tolerancia_fisiologica_s"])
TOL_TECNICO_S = float(_PAR["tolerancia_tecnica_s"])
PRIORIDAD_TECNICA = {k.replace("prioridad_tecnica_", ""): v for k, v in _PAR.items()
                     if k.startswith("prioridad_tecnica_")}

_OPS = {"<": np.less, "<=": np.less_equal, ">": np.greater, ">=": np.greater_equal}


def nivel_simple(regla, x):
    """Nivel 0, 2 o 3 de un valor según las filas de una regla de una sola variable (OR entre filas)."""
    filas = UMBRALES[UMBRALES.regla == regla]
    nivel = 0
    for _, f in filas.iterrows():
        if _OPS[f.condicion](x, f.umbral):
            nivel = max(nivel, NUM_NIVEL[f.nivel])
    return nivel


def cumple_combinada(regla, valores):
    """Regla combinada (AND entre variables distintas). valores = {variable: valor}."""
    filas = UMBRALES[UMBRALES.regla == regla]
    return all(valores.get(f.variable) is not None and _OPS[f.condicion](valores[f.variable], f.umbral)
               for _, f in filas.iterrows())


# variable de la base -> (regla de umbrales, clave de emparejamiento)
CONTINUAS = {
    "fc": ("FC", "fc"),
    "spo2": ("SPO2", "spo2"),
    "fr": ("FR", "fr"),
    "pa_inv_media": ("PAM", "pam"),
    "pa_inv_sis": ("PAS", "pas"),
}
INTERMITENTES = {          # PA no invasiva cargada por enfermería (chartevents)
    "pa_ni_media": ("PAM", "pam"),
    "pa_ni_sis": ("PAS", "pas"),
}
# 0 exacto en un canal con sensor = desconexión
DESCONEXION = {"fc": "A01", "spo2": "A02", "pa_inv_media": "A04", "pa_inv_sis": "A04"}
CLAVE_TECNICA = {"fc": "tec_fc", "spo2": "tec_spo2", "fr": "tec_fr", "pa_inv_media": "tec_pa",
                 "pa_inv_sis": "tec_pa", "pa_ni_media": "tec_pa", "pa_ni_sis": "tec_pa", "pvc": "tec_pvc"}


def escenario_fisiologico(clave, nivel, x):
    """Código del catálogo para un evento fisiológico real."""
    if clave == "fc":
        return "B02" if x <= 60 else "B01"
    if clave == "spo2":
        return "C02"
    if clave == "fr":
        return "C05" if x <= 12 else "C04"
    if clave == "pam":
        return "B05" if nivel == 3 else "B04"
    if clave == "pas":
        return "B06"
    return {"shock": "B09", "resp": "C07"}[clave]


def episodios(t, nivel, persistencia=PERSISTENCIA_MUESTRAS):
    """Tramos de nivel constante (>=1) con persistencia; devuelve [(t0, t1, nivel)]."""
    t = np.asarray(t, float)
    nivel = np.asarray(nivel, int)
    n = len(t)
    if n == 0:
        return []
    # nivel efectivo: mínimo de la muestra actual y las anteriores consecutivas (persistencia)
    efectivo = nivel.copy()
    for i in range(n):
        ventana = [nivel[i]]
        j = i
        while len(ventana) < persistencia and j > 0 and t[j] - t[j - 1] <= SALTO_MAX_S:
            j -= 1
            ventana.append(nivel[j])
        efectivo[i] = min(ventana) if len(ventana) == persistencia else 0
    # Segmentos de nivel constante: cada cambio de nivel abre un tramo nuevo
    salida, i = [], 0
    while i < n:
        if efectivo[i] >= 1:
            j = i
            while j + 1 < n and efectivo[j + 1] == efectivo[i] and t[j + 1] - t[j] <= SALTO_MAX_S:
                j += 1
            inicio = t[i]
            # el primer tramo de una racha arranca cuando la condición empezó a cumplirse
            if i == 0 or efectivo[i - 1] < 1 or t[i] - t[i - 1] > SALTO_MAX_S:
                k = i
                while k > 0 and nivel[k - 1] >= 1 and t[k] - t[k - 1] <= SALTO_MAX_S:
                    k -= 1
                inicio = t[k]
            salida.append([float(inicio), float(t[j]), int(efectivo[i])])
            i = j + 1
        else:
            i += 1
    # tramos contiguos: el fin de uno es el comienzo del siguiente
    for k in range(len(salida) - 1):
        if salida[k + 1][0] - salida[k][1] <= SALTO_MAX_S:
            salida[k][1] = salida[k + 1][0]
    return [tuple(x) for x in salida]


def intervalos_intermitentes(t, nivel, t_limite=None):
    """D6: cada medición vale desde su t hasta la siguiente o hasta la vigencia. Une los contiguos de igual nivel."""
    salida = []
    for i in range(len(t)):
        if nivel[i] < 2:
            continue
        fin = t[i] + VIGENCIA_PNI_S
        if i + 1 < len(t):
            fin = min(fin, t[i + 1])
        if t_limite is not None:
            fin = min(fin, t_limite)
        if salida and salida[-1][2] == nivel[i] and abs(salida[-1][1] - t[i]) < 1:
            salida[-1][1] = fin
        else:
            salida.append([float(t[i]), float(fin), int(nivel[i])])
    return [tuple(x) for x in salida]


def etiquetar(con):
    """Devuelve una lista de dicts con los eventos reales etiquetados."""
    m = pd.read_sql(
        "SELECT e.cama_id, m.variable, m.t_s, m.valor, m.fuente FROM mediciones m JOIN estadias e USING(estadia_id) "
        "WHERE m.origen_dato='real' AND m.valor IS NOT NULL AND "
        "(m.fuente='numericos' OR (m.fuente='chartevents' AND m.variable IN ('pa_ni_media','pa_ni_sis')))", con)
    rangos = pd.read_sql("SELECT variable, rango_min, rango_max FROM variables", con).set_index("variable")
    cams = pd.read_sql("SELECT cama_id FROM camas ORDER BY cama_id", con).cama_id.tolist()
    ev = []

    def alta(cama, tipo, nombre, t0, t1, estado, esc, clave, prioridad, conf="alta", tol=TOL_FISIOLOGICO_S):
        ev.append(dict(cama_id=int(cama), tipo=tipo, nombre=nombre, t_inicio_s=float(t0), t_fin_s=float(t1),
                       valor_esperado=estado, confianza=conf, tolerancia_s=tol, origen="real", escenario=esc,
                       prioridad=prioridad, clave=clave))

    def tecnica(cama, nombre, t0, t1, esc, clave, conf="alta"):
        alta(cama, "tecnica", nombre, t0, t1, "REQUIERE REVISION", esc, clave,
             PRIORIDAD_TECNICA.get(esc, "baja"), conf, TOL_TECNICO_S)

    def rango(var):
        if var in rangos.index:
            lo, hi = rangos.loc[var, ["rango_min", "rango_max"]]
            return (-np.inf if pd.isna(lo) else lo), (np.inf if pd.isna(hi) else hi)
        return -np.inf, np.inf

    for cama in cams:
        d = m[m.cama_id == cama]
        piv = {(v, f): g.sort_values("t_s") for (v, f), g in d.groupby(["variable", "fuente"])}

        def serie(v, fuente="numericos"):
            g = piv.get((v, fuente))
            return (g.t_s.values, g.valor.values) if g is not None else (np.array([]), np.array([]))

        spo2_t, spo2_v = serie("spo2")
        spo2_en = dict(zip(np.round(spo2_t).astype(int), spo2_v))
        validos = {}                       # variable -> (t, v) válidos (para las combinadas)

        # --- variables continuas del monitor: técnicas + fisiológicas con persistencia ---
        for var, (regla, clave) in CONTINUAS.items():
            t, v = serie(var)
            if len(t) == 0:
                continue
            lo, hi = rango(var)
            en_rango = (v >= lo) & (v <= hi)
            valido = en_rango.copy()
            # D5: FR = 0 con SpO2 normal en el mismo minuto = pérdida de señal respiratoria (C06)
            if var == "fr":
                cero = (v == 0)
                aparente = cero & np.array([spo2_en.get(int(round(x)), 0) >= FR0_SPO2_MIN for x in t])
                for t0, t1, _ in episodios(t[aparente], np.ones(aparente.sum(), int), persistencia=1):
                    tecnica(cama, "FR = 0 sin descenso de SpO2 (pérdida de señal respiratoria)", t0, t1,
                            "C06", "tec_fr", "media")
                valido &= ~aparente
            # Valores fuera de rango: 0 en un canal con sensor = desconexión; el resto = valor imposible
            fuera = ~en_rango
            if fuera.any():
                cero = fuera & (v == 0)
                otro = fuera & (v != 0)
                if var in DESCONEXION and cero.any():
                    esc = DESCONEXION[var]
                    for t0, t1, _ in episodios(t[cero], np.ones(cero.sum(), int), persistencia=1):
                        tecnica(cama, f"{var} = 0 (sensor desconectado o sin señal)", t0, t1, esc, CLAVE_TECNICA[var])
                imposible = otro | (cero if var not in DESCONEXION else np.zeros_like(cero))
                if imposible.any():
                    for t0, t1, _ in episodios(t[imposible], np.ones(imposible.sum(), int), persistencia=1):
                        tecnica(cama, f"{var}: valor imposible o fuera de rango", t0, t1, "A09", CLAVE_TECNICA[var])
            tt, vv = t[valido], v[valido]
            validos[var] = (tt, vv)
            niveles = np.array([nivel_simple(regla, x) for x in vv], int)
            for t0, t1, pico in episodios(tt, niveles):
                x = vv[np.searchsorted(tt, t0)] if len(vv) else 0
                alta(cama, "alarma", f"{regla}: {NIVELES[pico].lower()}", t0, t1, NIVELES[pico],
                     escenario_fisiologico(clave, pico, x), clave, PRIORIDAD_FISIOLOGICA[pico])

        # --- D6: PA no invasiva (intermitente): cada medición vale hasta la siguiente o su vigencia ---
        t_inv, _ = validos.get("pa_inv_media", (np.array([]), None))
        for var, (regla, clave) in INTERMITENTES.items():
            t, v = serie(var, "chartevents")
            if len(t) == 0:
                continue
            lo, hi = rango(var)
            ok = (v >= lo) & (v <= hi)
            for x_t in t[~ok]:
                tecnica(cama, f"{var}: valor imposible o fuera de rango", x_t, x_t, "A09", "tec_pa")
            t, v = t[ok], v[ok]
            validos[var] = (t, v)
            niveles = np.array([nivel_simple(regla, x) for x in v], int)
            for t0, t1, pico in intervalos_intermitentes(t, niveles):
                # si en ese intervalo hay presión invasiva en vivo, manda la invasiva (no se duplica)
                if len(t_inv) and ((t_inv >= t0) & (t_inv <= t1)).any():
                    continue
                x = v[np.searchsorted(t, t0)]
                alta(cama, "alarma", f"{regla} no invasiva: {NIVELES[pico].lower()}", t0, t1, NIVELES[pico],
                     escenario_fisiologico(clave, pico, x), clave, PRIORIDAD_FISIOLOGICA[pico])

        # --- D4: reglas combinadas, por minuto, con persistencia ---
        def valor_en(var, t0, intermitente=None):
            tv = validos.get(var)
            if tv is not None and len(tv[0]):
                i = int(np.argmin(np.abs(tv[0] - t0)))
                if abs(tv[0][i] - t0) <= 60:
                    return tv[1][i]
            if intermitente:
                tv = validos.get(intermitente)
                if tv is not None and len(tv[0]):
                    i = int(np.searchsorted(tv[0], t0, side="right")) - 1
                    if i >= 0 and t0 - tv[0][i] <= VIGENCIA_PNI_S:
                        return tv[1][i]
            return None

        for regla, clave, base_var, otra, inter in (("SHOCK", "shock", "fc", "pa_inv_sis", "pa_ni_sis"),
                                                   ("RESP", "resp", "fr", "spo2", None)):
            tb, vb = validos.get(base_var, (np.array([]), np.array([])))
            if len(tb) == 0:
                continue
            otros = [valor_en(otra, x, inter) for x in tb]
            var_otra = "pas" if regla == "SHOCK" else "spo2"
            var_base = "fc" if regla == "SHOCK" else "fr"
            niveles = np.array([3 if o is not None and cumple_combinada(regla, {var_base: b, var_otra: o}) else 0
                                for b, o in zip(vb, otros)], int)
            for t0, t1, pico in episodios(tb, niveles):
                alta(cama, "alarma", f"{regla}: crítica", t0, t1, "CRITICA",
                     escenario_fisiologico(clave, 3, 0), clave, "alta")

        # --- PVC congelada en 0 (A11): rachas de >= N muestras seguidas exactamente en 0 ---
        # (v2: criterio causal; la v1 miraba el tramo entero, que en tiempo real no se conoce)
        t, v = serie("pvc")
        i = 0
        while i < len(t):
            if v[i] != 0:
                i += 1
                continue
            j = i
            while j + 1 < len(t) and v[j + 1] == 0 and t[j + 1] - t[j] <= SALTO_MAX_S:
                j += 1
            if j - i + 1 >= PVC_MUESTRAS:
                tecnica(cama, "PVC = 0 constante (transductor sin conectar o en cero)",
                        t[i], t[j], "A11", "tec_pvc", "media")
            i = j + 1

        # --- huecos de datos en la FC (A03) ---
        t, _ = serie("fc")
        if len(t) > 1:
            for k in np.where(np.diff(t) > VIGENCIA_MONITOR_S)[0]:
                tecnica(cama, "Hueco de datos de FC", t[k] + 60, t[k + 1] - 1, "A03", "tec_fc")

        # --- canal presente en la historia pero ausente en la ventana viva (A03) ---
        for var in ("fc", "spo2", "fr"):
            t, _ = serie(var)
            if len(t) and not ((t >= 0) & (t <= DURACION_TRAMO_S)).any():
                tecnica(cama, f"Canal {var} sin datos en la ventana", 0, DURACION_TRAMO_S, "A03", CLAVE_TECNICA[var])

    return ev


def etiquetar_manual(con):
    """Eventos de historia clínica y laboratorio (temperatura, plaquetas, creatinina, PaO2).
    D1: los desvíos leves (fiebre 38,1–38,9 °C, hipotermia leve) ya no son alarma y no se guardan."""
    m = pd.read_sql(
        "SELECT e.cama_id, m.variable, m.t_s, m.valor, m.fuente FROM mediciones m JOIN estadias e USING(estadia_id) "
        "WHERE m.origen_dato='real' AND m.fuente IN ('chartevents','labevents') AND m.valor IS NOT NULL", con)
    sp = pd.read_sql(
        "SELECT e.cama_id, m.t_s, m.valor FROM mediciones m JOIN estadias e USING(estadia_id) "
        "WHERE m.origen_dato='real' AND m.fuente='numericos' AND m.variable='spo2' AND m.valor > 50", con)
    ev = []

    def alta(cama, nombre, t, estado, esc, clave, tipo="alarma", conf="alta"):
        prioridad = PRIORIDAD_TECNICA.get(esc, "baja") if tipo == "tecnica" else PRIORIDAD_FISIOLOGICA[NUM_NIVEL[estado]]
        ev.append(dict(cama_id=int(cama), tipo=tipo, nombre=nombre, t_inicio_s=float(t), t_fin_s=float(t),
                       valor_esperado=estado, confianza=conf, tolerancia_s=0.0, origen="real", escenario=esc,
                       prioridad=prioridad, clave=clave))

    for cama, d in m.groupby("cama_id"):
        for _, r in d[d.variable == "temperatura"].iterrows():
            if r.valor <= 35.0:
                alta(cama, "Hipotermia (≤ 35 °C)", r.t_s, "ADVERTENCIA", "D04", "temperatura")
            elif r.valor >= 39.0:
                alta(cama, "Fiebre (≥ 39 °C)", r.t_s, "ADVERTENCIA", "D03", "temperatura")
        for _, r in d[d.variable == "plaquetas"].iterrows():
            if r.valor < 50:
                alta(cama, "Plaquetas < 50", r.t_s, "CRITICA", "E02", "plaquetas")
            elif r.valor < 100:
                alta(cama, "Plaquetas < 100", r.t_s, "ADVERTENCIA", "E02", "plaquetas")
        c = d[d.variable == "creatinina"].sort_values("t_s")
        for _, r in c.iterrows():
            previos = c[(c.t_s < r.t_s) & (c.t_s >= r.t_s - 48 * 3600)]
            if len(previos) and r.valor - previos.valor.min() >= 0.3:
                alta(cama, "Aumento de creatinina ≥ 0,3 mg/dL en 48 h", r.t_s, "ADVERTENCIA", "E01", "creatinina")
        s = sp[sp.cama_id == cama]
        for _, r in d[d.variable == "pao2"].iterrows():
            if r.valor < 60:
                cerca = s[(s.t_s >= r.t_s - 3600) & (s.t_s <= r.t_s + 3600)]
                if len(cerca) >= 5 and cerca.valor.median() >= 94:
                    alta(cama, "PaO2 < 60 discordante con SpO2 ≥ 94 % (posible muestra venosa)", r.t_s,
                         "REQUIERE REVISION", "E04", "tec_pao2", "tecnica", "media")
                else:
                    alta(cama, "PaO2 < 60 mmHg", r.t_s, "CRITICA" if r.valor < 50 else "ADVERTENCIA", "E04", "pao2")
    return ev


DDL = """
DROP TABLE IF EXISTS asignaciones;
DROP TABLE IF EXISTS escenarios;
DROP TABLE IF EXISTS eventos_esperados;
DROP TABLE IF EXISTS fallas_tecnicas;
DROP TABLE IF EXISTS esperado_cama;
DROP TABLE IF EXISTS huecos_naturales;

CREATE TABLE huecos_naturales (
    hueco_id         INTEGER PRIMARY KEY,
    cama_id          INTEGER REFERENCES camas(cama_id),
    subject_id       INTEGER,
    estadia_id       INTEGER,
    variable         TEXT,
    tipo             TEXT,            -- sin_dato / no_plausible / canal_ausente
    t_inicio_s       REAL,
    t_fin_s          REAL,
    duracion_min     REAL,
    dentro_del_tramo INTEGER,         -- 1 si el hueco cae en la ventana viva (0..1800 s)
    detalle          TEXT
);

CREATE TABLE escenarios (
    escenario_id     INTEGER PRIMARY KEY,
    codigo           TEXT UNIQUE,
    familia          TEXT,
    nombre           TEXT,
    situacion        TEXT,
    por_que_importa  TEXT,
    fuente           TEXT,
    variables        TEXT,
    criterio         TEXT,
    estado_esperado  TEXT,
    tipo_alarma      TEXT,
    latencia_max_s   REAL,
    metodo           TEXT,
    rol              TEXT,
    prioridad        INTEGER,
    referencia       TEXT,
    grupo            TEXT,            -- compatibilidad con la versión anterior
    descripcion      TEXT             -- compatibilidad con la versión anterior
);

CREATE TABLE asignaciones (
    asignacion_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    cama_id          INTEGER REFERENCES camas(cama_id),
    escenario_id     INTEGER REFERENCES escenarios(escenario_id),
    origen           TEXT,            -- real / inyectado
    rol              TEXT,            -- VP / VN / LIMITE
    estado_esperado  TEXT,
    justificacion    TEXT,
    UNIQUE (cama_id, escenario_id, origen)
);

CREATE TABLE eventos_esperados (
    evento_id        INTEGER PRIMARY KEY AUTOINCREMENT,
    cama_id          INTEGER REFERENCES camas(cama_id),
    tipo             TEXT,            -- alarma (fisiológica) / tecnica
    nombre           TEXT,
    t_inicio_s       REAL,
    t_fin_s          REAL,
    valor_esperado   TEXT,            -- estado esperado
    prioridad        TEXT,            -- alta / media / baja (D1, D2)
    clave            TEXT,            -- variable o regla para emparejar con la plataforma (D7)
    confianza        TEXT,            -- alta / media / baja
    tolerancia_s     REAL,
    origen           TEXT,            -- real / inyectado
    escenario        TEXT,            -- código del catálogo
    ventana          TEXT             -- vivo (0..1800 s) / historia (t < 0)
);

CREATE TABLE fallas_tecnicas (
    falla_id            INTEGER PRIMARY KEY,
    cama_id             INTEGER REFERENCES camas(cama_id),
    tipo                TEXT,
    canal               TEXT,
    t_inicio_s          REAL,
    t_fin_s             REAL,
    gravedad            TEXT,
    respuesta_esperada  TEXT,
    parametros          TEXT,
    escenario           TEXT,
    estado_esperado     TEXT,
    tolerancia_s        REAL
);

CREATE TABLE esperado_cama (
    cama_id              INTEGER PRIMARY KEY REFERENCES camas(cama_id),
    estado_fisiologico   TEXT,        -- peor estado esperado en la ventana viva (sin inyecciones)
    n_eventos_fisiol     INTEGER,
    n_eventos_tecnicos   INTEGER,
    resumen              TEXT
);
"""


def hacer_respaldo():
    """Copia consistente de la base (API de respaldo de SQLite) + copia maestra la primera vez. Devuelve la ruta del respaldo."""
    CARPETA_RESPALDO.mkdir(parents=True, exist_ok=True)
    sello = datetime.now().strftime("%Y%m%d_%H%M%S")
    destino = CARPETA_RESPALDO / f"{BASE.stem}_ANTES_PASO10_{sello}.db"
    origen = sqlite3.connect(BASE, timeout=5)
    try:
        copia = sqlite3.connect(destino)
        origen.backup(copia)
        copia.close()
    finally:
        origen.close()
    # verificar la copia: íntegra y con las mismas filas de mediciones
    chk = sqlite3.connect(destino)
    ok = chk.execute("PRAGMA integrity_check").fetchone()[0]
    n_copia = chk.execute("SELECT COUNT(*) FROM mediciones").fetchone()[0]
    chk.close()
    o = sqlite3.connect(BASE)
    n_orig = o.execute("SELECT COUNT(*) FROM mediciones").fetchone()[0]
    o.close()
    if ok != "ok" or n_copia != n_orig:
        destino.unlink(missing_ok=True)
        sys.exit(f"El respaldo no pasó la verificación (integridad: {ok}; filas {n_copia} vs {n_orig}). No se modificó nada.")
    maestra = BASE.with_name(f"{BASE.stem}_ORIGINAL.db")
    if not maestra.exists():
        shutil.copy2(destino, maestra)
        print(f"Copia maestra creada: {maestra}  (no se vuelve a sobrescribir; guardala aparte)")
    print(f"Respaldo previo: {destino}  ({n_copia:,} mediciones, integridad {ok})")
    return destino


def restaurar():
    cand = sorted(CARPETA_RESPALDO.glob(f"{BASE.stem}_ANTES_PASO10_*.db"))
    if not cand:
        sys.exit(f"No hay respaldos en {CARPETA_RESPALDO}")
    ultimo = cand[-1]
    seguro = BASE.with_name(f"{BASE.stem}_DESCARTADA_{datetime.now():%Y%m%d_%H%M%S}.db")
    if BASE.exists():
        shutil.move(str(BASE), str(seguro))                 # no se borra: queda aparte por las dudas
        print(f"La base actual quedó guardada como {seguro.name}")
    shutil.copy2(ultimo, BASE)
    print(f"Base restaurada desde {ultimo.name}")


def cargar_huecos(con):
    """Carga huecos_naturales.csv en la tabla huecos_naturales (dentro de la transacción en curso)."""
    try:
        h = pd.read_csv(buscar("huecos_naturales.csv"), encoding="utf-8-sig")
    except FileNotFoundError:
        print("AVISO: no encuentro huecos_naturales.csv; la tabla huecos_naturales queda vacía.")
        return 0
    cols = ["hueco_id", "cama_id", "subject_id", "estadia_id", "variable", "tipo", "t_inicio_s", "t_fin_s",
            "duracion_min", "dentro_del_tramo", "detalle"]
    h["dentro_del_tramo"] = h["dentro_del_tramo"].astype(str).str.lower().isin(["true", "1"]).astype(int)
    h = h[cols].astype(object).where(h[cols].notna(), None)
    con.executemany(f"INSERT INTO huecos_naturales VALUES ({','.join('?' * len(cols))})", h.values.tolist())
    return len(h)


_PRIORIDAD_DE_ESTADO = {"CRITICA": "alta", "ADVERTENCIA": "media", "REQUIERE REVISION": "baja", "ESTABLE": None}
# Escenarios del plan que se cargan en eventos_esperados (alarmas fisiológicas inyectadas) -> clave de emparejamiento
CLAVE_INYECTADA = {"B01": "fc", "B02": "fc", "B03": "asistolia", "B06": "pas", "B09": "shock", "B10": "ritmo",
                   "B11": "ritmo", "B12": "pvc", "C07": "resp"}


def lista_camas(txt, todas):
    txt = (txt or "").strip()
    if not txt:
        return []
    if txt.lower() == "todas":
        return todas
    return [int(x) for x in txt.replace(",", ";").split(";") if x.strip().isdigit()]


def main():
    global BASE
    if ARGS.restaurar:
        restaurar()
        return
    if not BASE.exists():
        sys.exit(f"No existe la base: {BASE}")
    if ARGS.solo_copia:                                    # trabaja sobre una copia; la original no se toca
        copia = BASE.with_name("benchmark_uti_paso10.db")
        shutil.copy2(BASE, copia)
        print(f"Modo copia: se trabaja sobre {copia.name}; {BASE.name} no se toca.")
        BASE = copia
    elif not ARGS.sin_respaldo:
        hacer_respaldo()
    cat = pd.read_csv(buscar("catalogo_escenarios_v3.csv"), encoding="utf-8-sig").fillna("")
    plan = pd.read_csv(buscar("plan_inyeccion_v3.csv"), encoding="utf-8-sig").fillna("")

    try:
        con = sqlite3.connect(BASE, timeout=5, isolation_level=None)      # transacción manual
        con.execute("BEGIN IMMEDIATE")                                    # falla enseguida si Streamlit tiene la base abierta
    except sqlite3.OperationalError as e:
        sys.exit(f"No pude abrir la base para escribir ({e}). Cerrá la plataforma (Streamlit) y volvé a correrlo. No se modificó nada.")
    try:
        _cargar(con, cat, plan)
        con.execute("COMMIT")
    except Exception:
        con.execute("ROLLBACK")
        print("\nERROR: la carga se canceló y la base quedó como estaba antes de correr el script.")
        raise
    _resumen(con)
    con.close()


def _cargar(con, cat, plan):
    for sentencia in DDL.split(";"):
        if sentencia.strip():
            con.execute(sentencia)
    todas = [r[0] for r in con.execute("SELECT cama_id FROM camas ORDER BY cama_id")]
    cod2id = {}

    # 1) escenarios + asignaciones de camas reales
    for _, r in cat.iterrows():
        con.execute(
            "INSERT INTO escenarios VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (int(r.escenario_id), r.id, r.familia, r.nombre, r.situacion_en_uti, r.por_que_importa, r.fuente,
             r.variables, r.criterio_deteccion, r.estado_esperado, r.tipo_alarma,
             float(r.latencia_max_s) if str(r.latencia_max_s) != "" else None, r.metodo, r.rol,
             int(r.prioridad), r.referencia, r.familia, r.situacion_en_uti))
        cod2id[r.id] = int(r.escenario_id)
        for cama in lista_camas(str(r.camas_real), todas):
            con.execute("INSERT OR IGNORE INTO asignaciones (cama_id,escenario_id,origen,rol,estado_esperado,justificacion) "
                        "VALUES (?,?,?,?,?,?)", (cama, int(r.escenario_id), "real", r.rol, r.estado_esperado, r.evidencia_en_bd))

    # 2) plan de inyección
    for _, r in plan.iterrows():
        esc = cod2id[r.escenario]
        fila = cat[cat.id == r.escenario].iloc[0]
        con.execute("INSERT OR IGNORE INTO asignaciones (cama_id,escenario_id,origen,rol,estado_esperado,justificacion) "
                    "VALUES (?,?,?,?,?,?)",
                    (int(r.cama_id), esc, "inyectado", fila.rol, r.estado_esperado,
                     f"{r.tipo}: {r.canal}, t = {r.t_inicio_s:g}–{r.t_fin_s:g} s"))
        if r.tabla_destino == "fallas_tecnicas":
            con.execute("INSERT INTO fallas_tecnicas VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                        (int(r.falla_id), int(r.cama_id), r.tipo, r.canal, float(r.t_inicio_s), float(r.t_fin_s),
                         r.gravedad, r.respuesta_esperada, r.parametros, r.escenario, r.estado_esperado,
                         float(r.tolerancia_s)))
        else:
            con.execute("INSERT INTO eventos_esperados (cama_id,tipo,nombre,t_inicio_s,t_fin_s,valor_esperado,prioridad,"
                        "clave,confianza,tolerancia_s,origen,escenario,ventana) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (int(r.cama_id), "alarma", r.tipo, float(r.t_inicio_s), float(r.t_fin_s), r.estado_esperado,
                         _PRIORIDAD_DE_ESTADO.get(r.estado_esperado), CLAVE_INYECTADA.get(r.escenario), "alta",
                         float(r.tolerancia_s), "inyectado", r.escenario, "vivo"))

    # 3) eventos reales etiquetados
    reales = etiquetar(con) + etiquetar_manual(con)
    for e in reales:
        ventana = "vivo" if e["t_fin_s"] >= 0 else "historia"
        con.execute("INSERT INTO eventos_esperados (cama_id,tipo,nombre,t_inicio_s,t_fin_s,valor_esperado,prioridad,"
                    "clave,confianza,tolerancia_s,origen,escenario,ventana) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (e["cama_id"], e["tipo"], e["nombre"], e["t_inicio_s"], e["t_fin_s"], e["valor_esperado"],
                     e["prioridad"], e["clave"], e["confianza"], e["tolerancia_s"], "real", e["escenario"], ventana))

    # 4) estado esperado por cama en la ventana viva (sólo eventos reales)
    for cama in todas:
        filas = con.execute(
            "SELECT tipo, valor_esperado, nombre FROM eventos_esperados WHERE cama_id=? AND origen='real' "
            "AND t_fin_s >= 0 AND t_inicio_s <= ?", (cama, DURACION_TRAMO_S)).fetchall()
        fis = [f for f in filas if f[0] == "alarma"]
        tec = [f for f in filas if f[0] == "tecnica"]
        peor = max([NIVELES.index(f[1]) for f in fis], default=0)
        if peor == 0 and tec:
            peor = 1                          # solo fallas técnicas: REQUIERE REVISION
        nombres = sorted({f[2] for f in fis + tec})
        con.execute("INSERT INTO esperado_cama VALUES (?,?,?,?,?)",
                    (cama, NIVELES[peor], len(fis), len(tec), "; ".join(nombres)[:400]))
    n_huecos = cargar_huecos(con)
    print(f"huecos_naturales: {n_huecos} filas cargadas")


def _resumen(con):
    print(f"\nBase: {BASE}")
    for t in ("escenarios", "asignaciones", "eventos_esperados", "fallas_tecnicas", "esperado_cama", "huecos_naturales"):
        print(f"  {t:20s} {con.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0]:6d} filas")
    print("\nEventos reales en la ventana viva, por clave y estado esperado:")
    print(pd.read_sql("SELECT tipo, clave, valor_esperado, prioridad, COUNT(*) n FROM eventos_esperados "
                      "WHERE origen='real' AND ventana='vivo' GROUP BY 1,2,3,4 ORDER BY 1,2", con).to_string(index=False))
    print("\nEstado fisiológico esperado en la ventana viva (sólo eventos reales):")
    print(pd.read_sql("SELECT cama_id, estado_fisiologico, n_eventos_fisiol AS fisiol, n_eventos_tecnicos AS tecn, resumen "
                      "FROM esperado_cama", con).to_string(index=False))


if __name__ == "__main__":
    main()
