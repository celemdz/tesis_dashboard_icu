# ============================================================
# pruebas_verificacion.py - Verificación de la plataforma (sin Streamlit)
#
# Uso (Anaconda Prompt, parada en SCRIPTS\Plataforma_v2):
# Reglas v2: casos A15 a A22 nuevos (persistencia, FR = 0, PA manual, hipertensión, taquicardia, desvío leve).
#     python pruebas_verificacion.py                       -> prueba esta carpeta (versión unificada)
#     python pruebas_verificacion.py ..\Código_Maxi        -> prueba otra carpeta (por ejemplo, la original)
#
# Dos grupos de pruebas:
#   A) Casos controlados: entradas armadas a propósito, con resultado esperado definido antes.
#   B) Datos reales: las 15 camas de benchmark_uti.db recorridas cada 30 s durante los 30 min del tramo.
# Es VERIFICACIÓN (el software hace lo especificado). La VALIDACIÓN contra el ground truth del
# benchmark (escenarios y fallas inyectadas) se hará cuando estén cargadas esas tablas.
#
# Salida: tabla por consola y CSV en esta carpeta:
#     resultados_verificacion_<carpeta>.csv   (una fila por prueba)
#     alarmas_datos_reales_<carpeta>.csv      (cuántas veces apareció cada alarma en cada cama)
# ============================================================
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

CARPETA = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent
sys.path.insert(0, str(CARPETA))
import datos_db as ddb      # noqa: E402
import reglas_basicas as reglas  # noqa: E402
import senales              # noqa: E402

ETIQUETA = CARPETA.name
UMBRALES = {"fc_max": 120, "pam_min": 65, "spo2_min": 92, "fr_max": 25, "pas_min": 90}   # los de la interfaz
TIENE_CLASIFICACION = hasattr(reglas, "estado_valores")
INSTANTES = list(range(0, 1801, 30))     # 61 instantes: cada 30 s del tramo
TOLERANCIA_FC_LPM = 5.0

base = ddb.BaseUTI()
resultados = []


def registrar(prueba_id, grupo, descripcion, entrada, esperado, observado, cumple):
    resultados.append({"id": prueba_id, "grupo": grupo, "descripcion": descripcion, "entrada": entrada,
                       "esperado": esperado, "observado": observado, "cumple": "SI" if cumple else "NO"})


# ------------------------------------------------------------
# Cómo muestra cada versión un valor y la tarjeta (misma lógica que la interfaz)
# ------------------------------------------------------------
def num(x):
    return "—" if x is None else f"{x:.0f}"


def mostrado(snap, clave):
    """Texto que la interfaz muestra para ese valor."""
    if not TIENE_CLASIFICACION:            # versión original: muestra el número tal cual
        return num(snap.get(clave))
    estado = reglas.estado_valores(snap, base)[clave]
    if estado in (reglas.FALTANTE, reglas.DESCONECTADO):
        return "---"
    if estado == reglas.NO_FISIOLOGICO:
        return "-?-"
    return num(snap.get(clave))


def tecnica_visible_en_tarjeta(alarmas):
    """¿La tarjeta muestra la falla técnica cuando hay alarma técnica?"""
    if hasattr(reglas, "tecnicas"):        # versión unificada: muestra clínica y técnica por separado
        return bool(reglas.tecnicas(alarmas))
    p = reglas.alarma_principal(alarmas)   # versión original: muestra solo la de mayor prioridad
    return p is not None and p["nivel"] == "REQUIERE REVISION"


# ------------------------------------------------------------
# A) CASOS CONTROLADOS
# ------------------------------------------------------------
def snap_sintetico(fc=80, spo2=97, fr=16, pas=120, pad=75, pam=90, viejo=(), previos=None, manual=()):
    """Instantánea armada a mano, con la misma estructura que datos_db.BaseUTI.snapshot().
    previos: valores de la muestra anterior (D3). Por defecto, iguales a los actuales (condición sostenida).
    manual: claves medidas a mano (p. ej. PA no invasiva), que no exigen persistencia (D6)."""
    def dato(v, var):
        antig = 600.0 if var in viejo else 30.0          # 10 min = vencido para un monitor
        return None if v is None else ddb.Dato(valor=v, t_s=0.0, antiguedad_s=antig, fuente="prueba",
                                               vigente=antig <= ddb.vigencia_s(var))
    datos = {"fc": dato(fc, "fc"), "spo2": dato(spo2, "spo2"), "fr": dato(fr, "fr"),
             "pa": dato(pam if pam is not None else pas, "pa_inv_media")}
    actuales = {"fc": fc, "spo2": spo2, "fr": fr, "pas": pas, "pad": pad, "pam": pam}
    prev = dict(actuales)
    prev.update(previos or {})
    fuentes = {k: ("chartevents" if k in manual else "numericos") for k in actuales}
    return {"datos": datos, "fc": fc, "spo2": spo2, "fr": fr, "pas": pas, "pad": pad, "pam": pam, "pa_origen": "INV",
            "previos": prev, "fuentes": fuentes}


CASOS = [
    # id, descripción, parámetros, reglas que DEBEN aparecer, reglas que NO deben aparecer, {valor: texto esperado}
    ("A01", "Control: todos los valores normales", {}, [], ["*"], {"fc": "80", "pam": "90"}),
    ("A02", "Control: PAM 50 (hipotensión severa real)", {"pam": 50, "pas": 80, "pad": 35}, ["HIPOTENSION_SEVERA"], [], {"pam": "50"}),
    ("A03", "Línea arterial desconectada (PAS, PAD y PAM = 0)", {"pas": 0, "pad": 0, "pam": 0},
     ["SENSOR_DESCONECTADO_PAM"], ["HIPOTENSION", "HIPOTENSION_SEVERA", "SHOCK_HEMODINAMICO"], {"pam": "---", "pas": "---"}),
    ("A04", "PAM 10 con PAD -5 (valores imposibles)", {"pas": 40, "pad": -5, "pam": 10},
     ["FUERA_DE_RANGO_PAM", "FUERA_DE_RANGO_PAD"], ["HIPOTENSION", "HIPOTENSION_SEVERA"], {"pam": "-?-", "pad": "-?-"}),
    ("A05", "FC sin dato", {"fc": None}, ["SIN_SENAL_FC"], [], {"fc": "---"}),
    ("A06", "Oxímetro desconectado (SpO2 = 0)", {"spo2": 0},
     ["SENSOR_DESCONECTADO_SPO2"], ["HIPOXEMIA", "HIPOXEMIA_SEVERA", "FALLA_RESPIRATORIA"], {"spo2": "---"}),
    ("A07", "FC no fisiológica (400) con PAS 80", {"fc": 400, "pas": 80},
     ["FUERA_DE_RANGO_FC"], ["SHOCK_HEMODINAMICO", "TAQUICARDIA_EXTREMA"], {"fc": "-?-"}),
    ("A08", "Control: shock (FC 130 y PAS 80)", {"fc": 130, "pas": 80, "pam": 60}, ["SHOCK_HEMODINAMICO"], [], {}),
    ("A09", "FC 130 con PAS desconectada (0)", {"fc": 130, "pas": 0},
     ["SENSOR_DESCONECTADO_PAS"], ["SHOCK_HEMODINAMICO"], {"pas": "---"}),
    ("A10", "Control: falla respiratoria (FR 30 y SpO2 88)", {"fr": 30, "spo2": 88}, ["FALLA_RESPIRATORIA"], [], {}),
    ("A11", "Control: hipoxemia severa (SpO2 80)", {"spo2": 80}, ["HIPOXEMIA_SEVERA"], [], {}),
    ("A12", "FC vencida (10 min sin actualizar) con PAS 80", {"fc": 130, "pas": 80, "viejo": ("fc",)},
     ["DATO_VIEJO_FC"], ["SHOCK_HEMODINAMICO"], {}),
    ("A13", "Solo la PAD imposible (-5)", {"pad": -5}, ["FUERA_DE_RANGO_PAD"], [], {"pad": "-?-", "pam": "90"}),
    # --- reglas v2 ---
    ("A15", "D3: SpO2 80 en una sola muestra (la anterior, 97)", {"spo2": 80, "previos": {"spo2": 97}},
     [], ["HIPOXEMIA", "HIPOXEMIA_SEVERA"], {"spo2": "80"}),
    ("A16", "D5: FR = 0 con SpO2 97 (pérdida de señal respiratoria)", {"fr": 0},
     ["SENAL_RESPIRATORIA_PERDIDA"], ["APNEA_BRADIPNEA_SEVERA"], {"fr": "---"}),
    ("A17", "D5: FR = 0 con SpO2 86, sostenida (posible apnea)", {"fr": 0, "spo2": 86},
     ["APNEA_BRADIPNEA_SEVERA"], ["SENAL_RESPIRATORIA_PERDIDA"], {"fr": "0"}),
    ("A18", "D6: PA no invasiva PAM 50 en una sola medición manual", {"pam": 50, "pas": 75, "pad": 38,
     "previos": {"pam": 90, "pas": 120, "pad": 75}, "manual": ("pam", "pas", "pad")}, ["HIPOTENSION_SEVERA"], [], {}),
    ("A19", "D4: hipertensión severa (PAS 190)", {"pas": 190, "pad": 95, "pam": 127}, ["HIPERTENSION_SEVERA"], [], {}),
    ("A20", "D4: taquicardia aislada (FC 118)", {"fc": 118}, ["TAQUICARDIA"], ["SHOCK_HEMODINAMICO"], {}),
    ("A21", "D1: desvío leve (SpO2 92, FR 22) no alarma", {"spo2": 92, "fr": 22}, [], ["*"], {}),
    ("A22", "A14: FC, SpO2 y FR sin datos nuevos hace 10 min (cama sin comunicación)", {"viejo": ("fc", "spo2", "fr")},
     ["CAMA_SIN_COMUNICACION"], ["SHOCK_HEMODINAMICO"], {}),
]

print(f"\n=== Verificación de la carpeta: {ETIQUETA} ===")
print(f"Base: {base.ruta}\n")

for cid, desc, params, deben, no_deben, textos in CASOS:
    snap = snap_sintetico(**params)
    alarmas = reglas.evaluar(snap, UMBRALES, base)
    activas = sorted(a["regla"] for a in alarmas)
    ok = all(r in activas for r in deben)
    ok &= (not activas) if no_deben == ["*"] else not any(r in activas for r in no_deben)
    mostrados = {k: mostrado(snap, k) for k in textos}
    # "—" (sin dato en la versión original) equivale a "---": en ambos casos no se muestra un número
    ok &= all(mostrados[k] == v or (v == "---" and mostrados[k] == "—") for k, v in textos.items())
    esperado = ("sin alarmas" if no_deben == ["*"] else
                f"con {deben or '-'}; sin {no_deben or '-'}") + (f"; muestra {textos}" if textos else "")
    observado = f"alarmas {activas or 'ninguna'}" + (f"; muestra {mostrados}" if textos else "")
    registrar(cid, "A - casos controlados", desc, str({k: v for k, v in params.items() if k != 'viejo'}),
              esperado, observado, ok)

# A14: alarma clínica + falla técnica al mismo tiempo -> la tarjeta debe mostrar las dos
snap = snap_sintetico(spo2=0, pam=50, pas=80, pad=35)
alarmas = reglas.evaluar(snap, UMBRALES, base)
visible = tecnica_visible_en_tarjeta(alarmas)
registrar("A14", "A - casos controlados", "Hipotensión real + oxímetro desconectado (la técnica no debe quedar tapada)",
          "{'spo2': 0, 'pam': 50}", "tarjeta muestra HIPOTENSION_SEVERA y la falla del oxímetro",
          f"alarmas {sorted(a['regla'] for a in alarmas)}; falla técnica visible en la tarjeta: {'sí' if visible else 'no'}",
          visible and any(a["regla"] == "HIPOTENSION_SEVERA" for a in alarmas))

# ------------------------------------------------------------
# B) DATOS REALES (15 camas, cada 30 s durante 30 min)
# ------------------------------------------------------------
camas = [int(c) for c in base.camas["cama_id"]]
errores, futuros, chequeos_futuro = [], 0, 0
mostrados_invalidos, peores_invalidos, n_valores, n_peores = [], [], 0, 0
conteo_alarmas = {}
tiempos = []
VARS_FUTURO = ("fc", "spo2", "fr", "pa_inv_media", "pa_ni_media", "temperatura")

for t in INSTANTES:
    inicio = time.perf_counter()
    for cama in camas:
        est = base.estadia_de_cama(cama)
        try:
            snap = base.snapshot(est, t)
            alarmas = reglas.evaluar(snap, UMBRALES, base)
        except Exception as error:
            errores.append(f"cama {cama} t={t}: {error}")
            continue
        for a in alarmas:
            conteo_alarmas[(cama, a["regla"])] = conteo_alarmas.get((cama, a["regla"]), 0) + 1
        # B02: ningún dato del futuro
        for var in VARS_FUTURO:
            d = base.ultimo(est, var, t)
            if d is not None:
                chequeos_futuro += 1
                futuros += d.t_s > t
        # B03: ningún valor inválido mostrado como número
        for clave, var_rango in (("fc", "fc"), ("spo2", "spo2"), ("pam", "pa_inv_media"), ("pas", "pa_inv_sis"), ("pad", "pa_inv_dia")):
            v = snap.get(clave)
            if v is None:
                continue
            n_valores += 1
            invalido = (v == 0) or base.fuera_de_rango(var_rango, v)
            if invalido and mostrado(snap, clave) not in ("---", "-?-"):
                mostrados_invalidos.append(f"cama {cama} t={t} {clave}={v:g}")
        # B04: peores valores de 8 h sin valores inválidos
        for clave, var_rango in (("peor_fc", "fc"), ("peor_spo2", "spo2"), ("peor_pam", "pa_inv_media")):
            v = snap.get(clave)
            if v is None:
                continue
            n_peores += 1
            if v == 0 or base.fuera_de_rango(var_rango, v):
                peores_invalidos.append(f"cama {cama} t={t} {clave}={v:g}")
    tiempos.append(time.perf_counter() - inicio)

n_snap = len(INSTANTES) * len(camas)
registrar("B01", "B - datos reales", "Lectura de las 15 camas en los 61 instantes del tramo",
          f"{n_snap} instantáneas", "0 errores", f"{len(errores)} errores" + (f" ({errores[0]})" if errores else ""),
          not errores)
registrar("B02", "B - datos reales", "Ningún dato posterior al instante consultado (sin 'datos del futuro')",
          f"{chequeos_futuro} consultas", "0 datos del futuro", f"{futuros} datos del futuro", futuros == 0)
ej = f" (ej.: {', '.join(mostrados_invalidos[:3])})" if mostrados_invalidos else ""
registrar("B03", "B - datos reales", "Ningún valor inválido (0 o fuera de rango) mostrado como número",
          f"{n_valores} valores mostrados", "0 valores inválidos mostrados como número",
          f"{len(mostrados_invalidos)} ({100 * len(mostrados_invalidos) / max(n_valores, 1):.1f} %){ej}", not mostrados_invalidos)
ej = f" (ej.: {', '.join(peores_invalidos[:3])})" if peores_invalidos else ""
registrar("B04", "B - datos reales", "Peores valores de 8 h calculados solo con mediciones válidas",
          f"{n_peores} peores valores", "0 peores valores inválidos",
          f"{len(peores_invalidos)} ({100 * len(peores_invalidos) / max(n_peores, 1):.1f} %){ej}", not peores_invalidos)
registrar("B05", "B - datos reales", "Tiempo de evaluación de las 15 camas por paso (la pantalla se actualiza cada 1 s)",
          f"{len(INSTANTES)} pasos", "< 1 s por paso",
          f"media {np.mean(tiempos) * 1000:.0f} ms, máximo {np.max(tiempos) * 1000:.0f} ms", np.max(tiempos) < 1.0)

# B06: concordancia FC del ECG (picos R detectados) vs FC del monitor
ritmo = senales.RitmoCache()
dif = []
for cama in camas:
    est = base.estadia_de_cama(cama)
    info = base.info_tramo(est)
    for t in (900, 1800):
        try:
            rr = ritmo.rr_hasta(est, info["ruta"], t, ultimos=30)
            fc_rr = 60000 / np.median(rr) if len(rr) else None
            d = base.ultimo(est, "fc", t)
            if fc_rr is not None and d is not None and d.valor:
                dif.append((cama, t, fc_rr, d.valor, abs(fc_rr - d.valor)))
        except Exception as error:
            errores.append(f"señal cama {cama}: {error}")
dentro = [x for x in dif if x[4] <= TOLERANCIA_FC_LPM]
fuera = [f"cama {c} t={t}: {a:.1f} vs {b:.1f}" for c, t, a, b, e in dif if e > TOLERANCIA_FC_LPM]
registrar("B06", "B - datos reales", f"FC calculada desde el ECG vs FC del monitor (tolerancia ±{TOLERANCIA_FC_LPM:.0f} lpm)",
          f"{len(dif)} comparaciones (15 camas, t = 900 y 1800 s)", f"todas dentro de ±{TOLERANCIA_FC_LPM:.0f} lpm",
          f"{len(dentro)} de {len(dif)} dentro; error medio {np.mean([x[4] for x in dif]):.1f} lpm"
          + (f"; fuera: {', '.join(fuera)}" if fuera else ""), not fuera)

# ------------------------------------------------------------
# Salida
# ------------------------------------------------------------
df = pd.DataFrame(resultados)
pd.set_option("display.max_colwidth", 70, "display.width", 200)
print(df[["id", "descripcion", "cumple"]].to_string(index=False))
n_ok = (df["cumple"] == "SI").sum()
print(f"\nRESULTADO: {n_ok} de {len(df)} pruebas cumplen "
      f"(A: {(df[df.grupo.str.startswith('A')].cumple == 'SI').sum()} de {df.grupo.str.startswith('A').sum()}, "
      f"B: {(df[df.grupo.str.startswith('B')].cumple == 'SI').sum()} de {df.grupo.str.startswith('B').sum()})")
for r in df[df.cumple == "NO"].itertuples():
    print(f"  NO CUMPLE {r.id}: {r.observado}")

salida = Path(__file__).resolve().parent
df.to_csv(salida / f"resultados_verificacion_{ETIQUETA}.csv", index=False, encoding="utf-8-sig")
al = pd.DataFrame([{"cama": c, "regla": r, "instantes_con_alarma": n, "porcentaje_del_tramo": round(100 * n / len(INSTANTES), 1)}
                   for (c, r), n in sorted(conteo_alarmas.items())])
al.to_csv(salida / f"alarmas_datos_reales_{ETIQUETA}.csv", index=False, encoding="utf-8-sig")
print(f"\nCSV guardados en {salida}:\n  resultados_verificacion_{ETIQUETA}.csv\n  alarmas_datos_reales_{ETIQUETA}.csv")
