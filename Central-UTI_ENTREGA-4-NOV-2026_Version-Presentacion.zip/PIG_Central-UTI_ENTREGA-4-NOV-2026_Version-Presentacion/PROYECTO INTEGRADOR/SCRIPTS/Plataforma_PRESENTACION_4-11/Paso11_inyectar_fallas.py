# -*- coding: utf-8 -*-
# ============================================================
# Paso11_inyectar_fallas.py - Aplica las inyecciones de plan_inyeccion_v3.csv
#
# Qué hace
#   1) Copia benchmark_uti.db a benchmark_uti_validacion.db (el original NO se toca).
#   2) Capa numérica: para cada falla/evento inyectado agrega filas a `mediciones` con
#      origen_dato = 'inyectado' y reemplaza_a = id de la fila original. La vista v_mediciones_visibles
#      ya oculta lo reemplazado, así que la plataforma ve el dato inyectado y el original queda guardado.
#      Los datos que "faltan" se marcan con calidad = '__ausente__' y la vista los oculta (se actualiza la vista).
#   3) Capa de señal: para las fallas de forma de onda escribe copias de los tramos en
#      SCRIPTS\tramos_con_falla\ (el tramo original queda intacto) y las registra en `tramos_senal`
#      con version = 'con_falla'; el original pasa a es_benchmark = 0.
#   4) Registra todo en la tabla `inyecciones_aplicadas` y verifica cada inyección contra la vista.
#   5) Lee huecos_naturales.csv (momentos en que el dato REAL ya falta o no es plausible) y, para cada inyección,
#      informa qué huecos caen dentro de su ventana (columna `huecos_solapados`). Una inyección numérica sólo
#      reemplaza filas que existen: donde el original ya no tiene dato no hay nada que inyectar, y el motor de la
#      plataforma podría marcar ahí una falla técnica natural que no corresponde a la inyección. La tabla
#      `huecos_naturales` queda copiada en la base de validación para consultarla desde SQL.
#
# Cómo correrlo (desde Anaconda Prompt, en la carpeta Plataforma):
#     python Paso11_inyectar_fallas.py                # crea benchmark_uti_validacion.db
#     python Paso11_inyectar_fallas.py --sobrescribir # si ya existe la copia, la rehace desde cero
#     python Paso11_inyectar_fallas.py --db RUTA.db   # otra base de origen
#
# Para que la plataforma use la copia con inyecciones (PowerShell):
#     $env:UTI_DB = "...\SCRIPTS\benchmark_uti_validacion.db" ; streamlit run Interfaz_uti_db.py
#
# Qué NO hace (queda registrado como 'runtime' o 'pendiente' en inyecciones_aplicadas):
#   - A15 red degradada (retraso/duplicados/desorden): es del transporte, se aplica al leer, no en la base.
#   - B10 ritmo irregular: espera la decisión sobre cómo medir la irregularidad del RR.
#   - Las ondas de B09, B02, B01, B06 y C07 no se modifican (sólo los números del monitor): la FC de la onda
#     de ECG seguirá siendo la real. Se documenta como limitación de la versión actual.
# ============================================================

import argparse
import hashlib
import json
import shutil
import sqlite3
import sys
from pathlib import Path

import numpy as np
import pandas as pd

AQUI = Path(__file__).resolve().parent
for _c in (AQUI, AQUI.parent / "Funciones", AQUI / "Funciones", AQUI.parent):
    sys.path.insert(0, str(_c))
try:
    import config
    RAIZ, CARPETA_DATOS = Path(config.RAIZ), Path(config.CARPETA_DATOS)
    RUTA_BASE = CARPETA_DATOS / "benchmark_uti.db"          # siempre la base original (no la de UTI_DB)
except Exception:                                   # sin config.py: todo relativo a esta carpeta
    RAIZ, RUTA_BASE, CARPETA_DATOS = AQUI.parent, AQUI.parent / "benchmark_uti.db", AQUI.parent
from senales import Tramo, detectar_picos_r        # noqa: E402

SEMILLA = 20260315
AUSENTE = "__ausente__"
INVALIDO = -32768
CARPETA_SALIDA_TRAMOS = "tramos_con_falla"


# ------------------------------------------------------------
# Utilidades
# ------------------------------------------------------------
def buscar(nombre):
    for c in (AQUI, AQUI.parent, CARPETA_DATOS, Path.cwd()):
        if (Path(c) / nombre).exists():
            return Path(c) / nombre
    raise FileNotFoundError(f"No encuentro {nombre} (ponelo junto a este script)")


def ruta_tramo(ruta_relativa):
    return RAIZ.joinpath(*str(ruta_relativa).replace("\\", "/").split("/"))


# ------------------------------------------------------------
# Capa numérica (tabla mediciones)
# ------------------------------------------------------------
class Numerico:
    COLS = "medicion_id, t_s, valor, valor_texto, unidad, fuente, itemid, calidad, plausible"

    def __init__(self, con):
        self.con = con
        self.rangos = {r[0]: (r[1], r[2]) for r in con.execute("SELECT variable, rango_min, rango_max FROM variables")}
        self.n_reemp = self.n_aus = self.n_nuevas = 0

    def reset(self):
        self.n_reemp = self.n_aus = self.n_nuevas = 0

    def visibles(self, est, var, t0, t1, fuente="numericos"):
        return self.con.execute(
            f"SELECT {self.COLS} FROM mediciones WHERE estadia_id=? AND variable=? AND fuente=? "
            "AND t_s BETWEEN ? AND ? AND COALESCE(calidad,'') <> ? "
            "AND medicion_id NOT IN (SELECT reemplaza_a FROM mediciones WHERE reemplaza_a IS NOT NULL) "
            "ORDER BY t_s", (est, var, fuente, t0, t1, AUSENTE)).fetchall()

    def _plausible(self, var, valor):
        mn, mx = self.rangos.get(var, (None, None))
        if valor is None:
            return None
        return int(not ((mn is not None and valor < mn) or (mx is not None and valor > mx)))

    def reemplazar(self, est, var, t0, t1, fn, fuente="numericos", cambiar_t=None, unidad=None):
        """fn(t, valor) -> nuevo valor (None = el dato deja de existir)."""
        for (mid, t, v, vt, u, f, it, cal, pl) in self.visibles(est, var, t0, t1, fuente):
            nuevo = fn(t, v)
            if nuevo is None:
                self.con.execute(
                    "INSERT INTO mediciones(estadia_id,variable,t_s,valor,valor_texto,unidad,fuente,itemid,calidad,plausible,"
                    "origen_dato,reemplaza_a) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                    (est, var, t, None, None, u, f, it, AUSENTE, None, "inyectado", mid))
                self.n_aus += 1
            else:
                self.con.execute(
                    "INSERT INTO mediciones(estadia_id,variable,t_s,valor,valor_texto,unidad,fuente,itemid,calidad,plausible,"
                    "origen_dato,reemplaza_a) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                    (est, var, t if cambiar_t is None else t + cambiar_t, float(nuevo), vt, unidad or u, f, it, cal,
                     self._plausible(var, float(nuevo)), "inyectado", mid))
                self.n_reemp += 1

    def insertar(self, est, var, t, valor, unidad, fuente, origen="inyectado", calidad=None):
        self.con.execute(
            "INSERT INTO mediciones(estadia_id,variable,t_s,valor,valor_texto,unidad,fuente,itemid,calidad,plausible,"
            "origen_dato,reemplaza_a) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (est, var, float(t), float(valor), None, unidad, fuente, None, calidad, self._plausible(var, float(valor)),
             origen, None))
        self.n_nuevas += 1

    def ultimo_antes(self, est, var, t0, fuente="numericos"):
        r = self.con.execute(
            "SELECT valor FROM mediciones WHERE estadia_id=? AND variable=? AND fuente=? AND t_s < ? AND valor IS NOT NULL "
            "AND COALESCE(calidad,'') <> ? AND medicion_id NOT IN (SELECT reemplaza_a FROM mediciones WHERE reemplaza_a IS NOT NULL) "
            "ORDER BY t_s DESC LIMIT 1", (est, var, fuente, t0, AUSENTE)).fetchone()
        return None if r is None else r[0]

    def valor_en(self, est, var, t0, t1, fuente="numericos"):
        return {round(r[1]): r[2] for r in self.visibles(est, var, t0, t1, fuente)}


def actualizar_vista(con):
    """La vista oculta lo reemplazado (ya lo hacía) y ahora también los datos marcados como ausentes."""
    con.execute("DROP VIEW IF EXISTS v_mediciones_visibles")
    con.execute(
        "CREATE VIEW v_mediciones_visibles AS "
        "SELECT estadia_id, variable, t_s, valor, valor_texto, unidad, fuente, calidad FROM mediciones "
        "WHERE t_s <= 1800 AND COALESCE(calidad,'') <> '__ausente__' "
        "AND medicion_id NOT IN (SELECT reemplaza_a FROM mediciones WHERE reemplaza_a IS NOT NULL)")


# ------------------------------------------------------------
# Huecos naturales (huecos_naturales.csv): momentos en que el dato REAL ya falta o no es plausible.
# Una inyección numérica sólo puede reemplazar filas que existen; donde la base ya no tiene dato, no hay nada
# que reemplazar. Por eso se informa, para cada inyección, qué huecos naturales caen dentro de su ventana.
# ------------------------------------------------------------
VARS_PA = ["pa_inv_sis", "pa_inv_dia", "pa_inv_media"]
TODAS_VARS = ["fc", "fr", "spo2", "pulso", "pvc"] + VARS_PA
VARS_POR_TIPO = {
    "ecg_sin_electrodo": ["fc"], "asistolia": ["fc"], "bradicardia": ["fc"], "taquicardia": ["fc"],
    "extrasistoles_aisladas": ["fc"], "ritmo_irregular": ["fc"],
    "inestabilidad_combinada": ["fc"] + VARS_PA, "hipertension_severa": ["pa_inv_sis", "pa_inv_media"],
    "abp_plana": VARS_PA, "abp_amortiguada": VARS_PA, "purga_linea": VARS_PA, "desplazamiento_cero": VARS_PA,
    "insuficiencia_respiratoria": ["spo2"], "pvc_elevada": ["pvc"], "cama_sin_comunicacion": TODAS_VARS,
    "artefacto_movimiento": [], "red_degradada": [], "desfase_reloj": [],
}


def cargar_huecos(con):
    """Lee huecos_naturales.csv (o, si no está, la tabla huecos_naturales de la base). Devuelve un DataFrame (puede ser vacío)."""
    try:
        h = pd.read_csv(buscar("huecos_naturales.csv"), encoding="utf-8-sig")
    except FileNotFoundError:
        try:
            h = pd.read_sql("SELECT * FROM huecos_naturales", con)
        except Exception:                                                     # noqa: BLE001
            print("AVISO: no encuentro huecos_naturales.csv ni la tabla huecos_naturales; no se informan solapamientos.\n")
            return pd.DataFrame(columns=["cama_id", "variable", "tipo", "t_inicio_s", "t_fin_s"])
    if not con.execute("SELECT 1 FROM sqlite_master WHERE name='huecos_naturales'").fetchone():
        h.to_sql("huecos_naturales", con, index=False)                         # queda disponible dentro de la base de validación
    return h


def solapes_con_huecos(h, f, par):
    """Huecos naturales de la misma cama y de las variables afectadas que se cruzan con la ventana de la inyección."""
    t0, t1 = float(f["t_inicio_s"]), float(f["t_fin_s"])
    if f["tipo"] == "unidades_erroneas":
        vs = [par["variable"]]
    elif f["tipo"] in ("dato_congelado", "canal_ausente", "valor_imposible"):
        vs = [f["canal"]]
    else:
        vs = VARS_POR_TIPO.get(f["tipo"], [])
    if not vs or h.empty:
        return []
    x = h[(h.cama_id == int(f["cama_id"])) & (h.variable.isin(vs)) & (h.t_fin_s >= t0) & (h.t_inicio_s <= max(t1, t0 + 1))]
    out = []
    for r in x.itertuples():
        seg = max(0.0, min(t1, r.t_fin_s) - max(t0, r.t_inicio_s))
        out.append(f"{r.variable} {r.tipo} ({seg / 60:.0f} min de la ventana)")
    return out


# ------------------------------------------------------------
# Capa de señal (tramos WFDB, formato 16 bits)
# ------------------------------------------------------------
class Onda:
    def __init__(self, ruta_base):
        self.tr = Tramo(ruta_base)
        self.tr._cargar()
        self.dig = self.tr._datos.copy().astype(np.int32)
        self.fs = self.tr.fs
        self.rng = np.random.default_rng(SEMILLA)
        self.nombres = [c.upper() for c in self.tr.canales]
        self.tocado = False
        self.reescalados = set()

    def j(self, canal):
        return self.nombres.index(canal.upper())

    def tiene(self, canal):
        return canal.upper() in self.nombres

    def rango(self, t0, t1):
        a = max(0, int(round(t0 * self.fs)))
        b = min(self.dig.shape[0], int(round(t1 * self.fs)))
        return a, b

    def fis(self, canal, a, b):
        j = self.j(canal)
        x = (self.dig[a:b, j].astype(float) - self.tr.baseline[j]) / self.tr.ganancia[j]
        x[self.dig[a:b, j] == INVALIDO] = np.nan
        return x

    def _reescalar(self, j, x):
        """Si el valor nuevo no entra en 16 bits con la ganancia original (p. ej. una purga a 300 mmHg en un canal que llega
        a 130), se cambia ganancia y línea de base del canal y se recodifica todo el canal. Se anota en el encabezado."""
        todo = (self.dig[:, j].astype(float) - self.tr.baseline[j]) / self.tr.ganancia[j]
        todo[self.dig[:, j] == INVALIDO] = np.nan
        lo = np.nanmin([np.nanmin(todo), np.nanmin(x)])
        hi = np.nanmax([np.nanmax(todo), np.nanmax(x)])
        margen = 0.05 * (hi - lo)
        lo, hi = lo - margen, hi + margen
        ganancia = 64000.0 / (hi - lo)
        baseline = int(round(-32000 - lo * ganancia))
        d = np.rint(todo * ganancia + baseline)
        d[np.isnan(todo)] = INVALIDO
        self.dig[:, j] = d.astype(np.int32)
        self.tr.ganancia[j], self.tr.baseline[j] = ganancia, float(baseline)
        self.reescalados.add(j)

    def poner(self, canal, a, b, x):
        j = self.j(canal)
        x = np.asarray(x, float)
        v = x[~np.isnan(x)]
        if v.size:
            lim = (v * self.tr.ganancia[j] + self.tr.baseline[j])
            if lim.min() < -32767 or lim.max() > 32767:
                self._reescalar(j, x)
        d = np.rint(np.asarray(x, float) * self.tr.ganancia[j] + self.tr.baseline[j])
        d = np.clip(d, -32767, 32767)
        d[np.isnan(x)] = INVALIDO
        self.dig[a:b, j] = d.astype(np.int32)
        self.tocado = True

    # --- modificaciones ---
    def plano_con_ruido(self, canal, t0, t1, ruido):
        a, b = self.rango(t0, t1)
        previo = self.fis(canal, max(0, a - int(5 * self.fs)), a)
        base = np.nanmedian(previo) if previo.size and not np.isnan(previo).all() else np.nanmedian(self.fis(canal, a, b))
        self.poner(canal, a, b, base + self.rng.normal(0, ruido, b - a))

    def constante(self, canal, t0, t1):
        a, b = self.rango(t0, t1)
        valor = self.fis(canal, max(0, a - 1), a)[0]
        self.poner(canal, a, b, np.full(b - a, valor))

    def ruido_banda(self, canal, t0, t1, banda, amp_rel):
        from scipy.signal import butter, sosfiltfilt
        a, b = self.rango(t0, t1)
        todo = self.fis(canal, 0, self.dig.shape[0])
        qrs = np.nanpercentile(todo, 99.5) - np.nanpercentile(todo, 0.5)
        ruido = self.rng.normal(0, 1, b - a)
        sos = butter(3, banda, btype="band", fs=self.fs, output="sos")
        ruido = sosfiltfilt(sos, ruido)
        ruido = ruido / np.std(ruido) * (amp_rel * qrs / 3.0)
        borde = np.minimum(1.0, np.minimum(np.arange(b - a), np.arange(b - a)[::-1]) / (self.fs * 1.0))
        self.poner(canal, a, b, self.fis(canal, a, b) + ruido * borde)

    def amortiguar(self, canal, t0, t1, factor):
        from scipy.ndimage import uniform_filter1d
        a, b = self.rango(t0, t1)
        x = self.fis(canal, a, b)
        m = uniform_filter1d(np.where(np.isnan(x), np.nanmean(x), x), size=int(5 * self.fs), mode="nearest")
        self.poner(canal, a, b, m + factor * (x - m))

    def purga(self, canal, t0, duracion, pico):
        a, b = self.rango(t0, t0 + duracion)
        x = self.fis(canal, a, b)
        t = np.arange(b - a) / self.fs
        base = np.nanmedian(x)
        perfil = (pico - base) * np.exp(-t / (duracion / 3.0)) * (1 - np.exp(-t / 0.1))
        self.poner(canal, a, b, x + perfil)

    def desplazar(self, canal, t0, t1, offset):
        a, b = self.rango(t0, t1)
        self.poner(canal, a, b, self.fis(canal, a, b) + offset)

    def sin_senal(self, t0, t1):
        a, b = self.rango(t0, t1)
        self.dig[a:b, :] = INVALIDO
        self.tocado = True

    def extrasistoles(self, canal, t0, t1, n):
        ecg = self.fis(canal, 0, self.dig.shape[0])
        picos = detectar_picos_r(ecg, self.fs)
        en_ventana = [i for i, p in enumerate(picos) if t0 <= p <= t1 and i + 1 < len(picos)]
        if len(en_ventana) < n + 2:
            raise RuntimeError(f"Pocos latidos en la ventana ({len(en_ventana)}) para {n} extrasístoles")
        elegidos = [en_ventana[int(round(f * (len(en_ventana) - 1)))] for f in np.linspace(0.2, 0.8, n)]
        previa, posterior = int(0.08 * self.fs), int(0.12 * self.fs)
        horas = []
        for i in elegidos:
            r, rn = picos[i], picos[i + 1]
            c = int(round(r * self.fs))
            plantilla = ecg[c - previa:c + posterior].copy()
            plantilla -= np.linspace(plantilla[0], plantilla[-1], len(plantilla))     # sin tendencia
            # complejo ancho: se estira 1,6x y se agranda 1,2x
            n_nuevo = int(len(plantilla) * 1.6)
            plantilla = np.interp(np.linspace(0, len(plantilla) - 1, n_nuevo), np.arange(len(plantilla)), plantilla) * 1.2
            t_nuevo = r + 0.55 * (rn - r)
            k = int(round(t_nuevo * self.fs)) - int(n_nuevo * previa / (previa + posterior))
            ecg[k:k + n_nuevo] += plantilla
            horas.append(round(t_nuevo, 2))
        self.poner(canal, 0, len(ecg), ecg)
        return horas

    def guardar(self, destino_base, nombre_registro):
        """Escribe .dat/.hea nuevos (mismo formato que el original). Devuelve sha256 del .dat."""
        destino_base.parent.mkdir(parents=True, exist_ok=True)
        dat = destino_base.with_suffix(".dat")
        self.dig.astype("<i2").tofile(dat)
        orig = self.tr.base.with_suffix(".hea").read_text(encoding="utf-8", errors="replace").splitlines()
        salida, k = [], 0
        for linea in orig:
            if not linea.strip() or linea.startswith("#"):
                salida.append(linea)
                continue
            p = linea.split()
            if k == 0:
                p[0] = nombre_registro
            else:
                col = self.dig[:, k - 1]
                p[0] = dat.name
                if k - 1 in self.reescalados:
                    p[2] = f"{float(self.tr.ganancia[k - 1])!r}({int(self.tr.baseline[k - 1])})/{self.tr.unidades[k - 1]}"
                p[5] = str(int(col[0]))
                p[6] = str(int(col.astype(np.int64).sum() % 65536))
            salida.append(" ".join(p))
            k += 1
        destino_base.with_suffix(".hea").write_text("\n".join(salida) + "\n", encoding="utf-8")
        return hashlib.sha256(dat.read_bytes()).hexdigest()


# ------------------------------------------------------------
# Aplicación de cada falla
# ------------------------------------------------------------
def aplicar(f, est, num, ondas, con):
    """Devuelve (capa, nota). Modifica la base y/o la onda de la estadía."""
    tipo, ca = f["tipo"], f["canal"]
    t0, t1 = float(f["t_inicio_s"]), float(f["t_fin_s"])
    par = json.loads(f["parametros"]) if isinstance(f["parametros"], str) and f["parametros"].strip() else {}

    def onda():
        if est not in ondas:
            fila = con.execute("SELECT ruta_archivo FROM tramos_senal WHERE estadia_id=? AND es_benchmark=1 "
                               "ORDER BY tramo_id LIMIT 1", (est,)).fetchone()
            if fila is None:
                raise RuntimeError(f"La estadía {est} no tiene tramo de señal")
            ondas[est] = (Onda(ruta_tramo(fila[0])), fila[0])
        return ondas[est][0]

    if tipo == "ecg_sin_electrodo":
        onda().plano_con_ruido("II", t0, t1, par.get("ruido_uV", 15) / 1000.0)
        num.reemplazar(est, "fc", t0, t1, lambda t, v: None)           # el monitor pierde la FC del ECG
        return "señal+numérica", "ECG plano con ruido; FC del ECG ausente; pulso (PLETH) conservado"
    if tipo == "artefacto_movimiento":
        onda().ruido_banda("II", t0, t1, par.get("banda_Hz", [5, 40]), par.get("amplitud_vs_QRS", 3.0))
        return "señal", "ruido de banda 5-40 Hz sobre el ECG; números del monitor sin cambios"
    if tipo == "asistolia":
        o = onda()
        for c in ("II", "PLETH"):
            if o.tiene(c):
                o.plano_con_ruido(c, t0, t1, 0.002 if c == "II" else 0.5)
        num.reemplazar(est, "fc", t0, t1, lambda t, v: 0.0)
        num.reemplazar(est, "pulso", t0, t1, lambda t, v: 0.0)
        num.reemplazar(est, "spo2", t0, t1, lambda t, v: None)
        if num.n_reemp == 0:
            num.insertar(est, "fc", (t0 + t1) / 2, 0.0, "lpm", "numericos")
            num.insertar(est, "pulso", (t0 + t1) / 2, 0.0, "lpm", "numericos")
        return "señal+numérica", "ECG y PLETH planos; FC y pulso en 0; SpO2 sin señal"
    if tipo == "dato_congelado":
        num.reemplazar(est, ca, t0, t1, lambda t, v: par.get("valor", v))
        return "numérica", f"{ca} fijo en {par.get('valor')}"
    if tipo == "red_degradada":
        return "runtime", "retraso/duplicados/desorden se aplican en el transporte (al leer), no en la base"
    if tipo == "canal_ausente":
        num.reemplazar(est, ca, t0, t1, lambda t, v: None)
        return "numérica", f"{ca} sin muestras en la ventana"
    if tipo == "valor_imposible":
        num.reemplazar(est, ca, t0, t1, lambda t, v: par["valor"])
        return "numérica", f"{ca} = {par['valor']}"
    if tipo == "desfase_reloj":
        desfase = par.get("desfase_s", 5400)
        variables = [r[0] for r in con.execute("SELECT DISTINCT variable FROM mediciones WHERE estadia_id=? AND fuente='chartevents' "
                                               "AND t_s BETWEEN ? AND ?", (est, t0, t1))]
        for var in variables:
            num.reemplazar(est, var, t0, t1, lambda t, v: v, fuente="chartevents", cambiar_t=desfase)
        return "numérica", f"{num.n_reemp} registros manuales con la hora corrida +{desfase} s (quedan en el futuro: la vista no los muestra)"
    if tipo == "abp_plana":
        o = onda()
        o.constante("ABP", t0, t1)
        for var in ("pa_inv_sis", "pa_inv_dia", "pa_inv_media"):
            ultimo = num.ultimo_antes(est, var, t0)
            if ultimo is not None:
                num.reemplazar(est, var, t0, t1, lambda t, v, u=ultimo: u)
        return "señal+numérica", "ABP constante en el último valor previo; presiones invasivas congeladas"
    if tipo == "abp_amortiguada":
        onda().amortiguar("ABP", t0, t1, par.get("factor_presion_pulso", 0.4))
        fac = par.get("factor_presion_pulso", 0.4)
        media = num.valor_en(est, "pa_inv_media", t0, t1)
        for var in ("pa_inv_sis", "pa_inv_dia"):
            num.reemplazar(est, var, t0, t1, lambda t, v, m=media: (m[round(t)] + fac * (v - m[round(t)])) if round(t) in m else v)
        return "señal+numérica", f"presión de pulso x{fac}, media constante"
    if tipo == "purga_linea":
        onda().purga("ABP", t0, t1 - t0, par.get("pico_mmHg", 300))
        return "señal", "pico de purga sobre la onda ABP; números del monitor sin cambios (promedian un minuto)"
    if tipo == "inestabilidad_combinada":
        pam = par["pam"]
        media = num.valor_en(est, "pa_inv_media", t0, t1)
        num.reemplazar(est, "fc", t0, t1, lambda t, v: par["fc"])
        for var in ("pa_inv_sis", "pa_inv_dia", "pa_inv_media"):
            num.reemplazar(est, var, t0, t1, lambda t, v, m=media: (v + (pam - m[round(t)])) if round(t) in m else v)
        return "numérica", f"FC {par['fc']} y PAM {pam} (se conserva la presión de pulso real)"
    if tipo == "hipertension_severa":
        d = par["delta_mmHg"]
        num.reemplazar(est, "pa_inv_sis", t0, t1, lambda t, v: v + d)
        num.reemplazar(est, "pa_inv_media", t0, t1, lambda t, v: v + d / 3.0)
        return "numérica", f"PAS +{d} mmHg, PAM +{d/3:.0f} mmHg, PAD sin cambios"
    if tipo in ("bradicardia", "taquicardia"):
        num.reemplazar(est, "fc", t0, t1, lambda t, v: par["fc"])
        return "numérica", f"FC fija en {par['fc']} (la onda de ECG conserva el ritmo real)"
    if tipo == "insuficiencia_respiratoria":
        num.reemplazar(est, "spo2", t0, t1, lambda t, v: par["spo2"])
        return "numérica", f"SpO2 fija en {par['spo2']} (la FR real ya es de 30-32 rpm)"
    if tipo == "cama_sin_comunicacion":
        o = onda()
        o.sin_senal(t0, t1)
        for var in ("fc", "fr", "spo2", "pulso", "pvc", "pa_inv_sis", "pa_inv_dia", "pa_inv_media"):
            num.reemplazar(est, var, t0, t1, lambda t, v: None)
        return "señal+numérica", "todos los canales del monitor ausentes en la ventana"
    if tipo == "extrasistoles_aisladas":
        horas = onda().extrasistoles("II", t0, t1, par.get("n_latidos", 3))
        return "señal", f"{len(horas)} latidos prematuros anchos (sin pausa compensadora) en t = {horas}"
    if tipo == "pvc_elevada":
        num.reemplazar(est, "pvc", t0, t1, lambda t, v: par["pvc"])
        return "numérica", f"PVC fija en {par['pvc']} mmHg (la PVC real de la ventana es de 0 a 6)"
    if tipo == "ritmo_irregular":
        return "pendiente", "espera la decisión sobre cómo medir la irregularidad del RR (CV objetivo 0,25)"
    if tipo == "unidades_erroneas":
        v = par["variable"]
        if v == "temperatura":
            num.insertar(est, "temperatura", t0, par["valor"], "°F", "chartevents")
        elif v == "fio2":
            num.insertar(est, "fio2", t0, par["valor"], "%", "chartevents")
        return "numérica", f"{v} cargada como {par['valor']} (unidad equivocada)"
    if tipo == "desplazamiento_cero":
        off = par["offset_mmHg"]
        onda().desplazar("ABP", t0, t1, off)
        for var in ("pa_inv_sis", "pa_inv_dia", "pa_inv_media"):
            num.reemplazar(est, var, t0, t1, lambda t, v: v + off)
        num.insertar(est, "pa_ni_media", par["referencia_ni_t_s"], par["referencia_ni_media"], "mmHg", "chartevents",
                     origen="sintetico", calidad=None)
        return "señal+numérica", f"ABP +{off} mmHg; referencia no invasiva simulada de {par['referencia_ni_media']} mmHg"
    raise ValueError(f"Tipo de inyección desconocido: {tipo}")


# ------------------------------------------------------------
# Verificación contra la vista
# ------------------------------------------------------------
def verificar(con, f, est, tramo_nuevo, tramo_orig=None):
    tipo, t0, t1 = f["tipo"], float(f["t_inicio_s"]), float(f["t_fin_s"])
    par = json.loads(f["parametros"]) if isinstance(f["parametros"], str) and f["parametros"].strip() else {}

    def vis(var, a=None, b=None, fuente="numericos"):
        a = t0 if a is None else a
        b = t1 if b is None else b
        r = con.execute("SELECT t_s, valor FROM v_mediciones_visibles WHERE estadia_id=? AND variable=? AND fuente=? "
                        "AND t_s BETWEEN ? AND ? ORDER BY t_s", (est, var, fuente, a, b)).fetchall()
        return np.array([x[1] for x in r if x[1] is not None], float)

    def onda_ventana(canal):
        tr = Tramo(tramo_nuevo)
        _, y = tr.canal_completo(canal)
        a, b = int(t0 * tr.fs), int(t1 * tr.fs)
        return y[a:b], tr

    t = f["tipo"]
    try:
        if t in ("dato_congelado",):
            v = vis(f["canal"]); return len(v) >= 3 and np.all(v == par["valor"]), f"{len(v)} muestras = {par['valor']}"
        if t == "canal_ausente":
            v = vis(f["canal"]); return len(v) == 0, f"{len(v)} muestras visibles (esperado 0)"
        if t == "valor_imposible":
            v = vis(f["canal"]); return len(v) > 0 and np.all(v == par["valor"]), f"{len(v)} muestras = {par['valor']}"
        if t == "bradicardia" or t == "taquicardia":
            v = vis("fc"); return len(v) >= 3 and np.all(v == par["fc"]), f"FC {v.min():.0f}-{v.max():.0f} ({len(v)} muestras)"
        if t == "pvc_elevada":
            v = vis("pvc"); return len(v) >= 3 and np.all(v == par["pvc"]), f"PVC {v.min():.0f}-{v.max():.0f} ({len(v)} muestras)"
        if t == "insuficiencia_respiratoria":
            v = vis("spo2"); return len(v) >= 3 and np.all(v == par["spo2"]), f"SpO2 {v.min():.0f}-{v.max():.0f}"
        if t == "inestabilidad_combinada":
            fc, pm = vis("fc"), vis("pa_inv_media")
            return len(fc) >= 3 and np.all(fc == par["fc"]) and np.allclose(pm, par["pam"]), f"FC {fc.min():.0f}, PAM {pm.min():.0f}-{pm.max():.0f}"
        if t == "hipertension_severa":
            s = vis("pa_inv_sis"); return len(s) >= 3 and 181 <= s.min() and s.max() <= 260, f"PAS {s.min():.0f}-{s.max():.0f} (banda 181-219 sostenida)"
        if t == "ecg_sin_electrodo":
            fc = vis("fc"); y, tr = onda_ventana("II"); return len(fc) == 0 and np.nanstd(y) < 0.05, f"FC visibles {len(fc)}; desvío ECG {np.nanstd(y):.3f}"
        if t == "artefacto_movimiento":
            y, tr = onda_ventana("II"); fuera = Tramo(tramo_nuevo).canal_completo("II")[1]
            return np.nanstd(y) > 1.5 * np.nanstd(fuera[: int(t0 * tr.fs)]), f"desvío ECG ventana {np.nanstd(y):.3f}"
        if t == "asistolia":
            fc = vis("fc"); y, tr = onda_ventana("II"); return len(fc) >= 1 and np.all(fc == 0) and np.nanstd(y) < 0.05, f"FC {fc}"
        if t == "abp_plana":
            y, tr = onda_ventana("ABP"); return np.nanstd(y) < 0.01, f"desvío ABP {np.nanstd(y):.4f}"
        if t == "abp_amortiguada":
            y, tr = onda_ventana("ABP"); yo = Tramo(tramo_orig).canal_completo("ABP")[1][int(t0 * tr.fs):int(t1 * tr.fs)]
            return np.nanstd(y) < 0.7 * np.nanstd(yo), f"desvío ABP {np.nanstd(y):.1f} vs original {np.nanstd(yo):.1f} mmHg"
        if t == "purga_linea":
            y, tr = onda_ventana("ABP"); return np.nanmax(y) > 250, f"pico ABP {np.nanmax(y):.0f} mmHg"
        if t == "desplazamiento_cero":
            s = vis("pa_inv_media"); ni = vis("pa_ni_media", par["referencia_ni_t_s"], par["referencia_ni_t_s"], "chartevents")
            return len(s) >= 3 and len(ni) == 1, f"PAM invasiva {s.min():.0f}-{s.max():.0f} vs NI {ni}"
        if t == "cama_sin_comunicacion":
            n = sum(len(vis(v)) for v in ("fc", "fr", "spo2", "pulso", "pa_inv_media"))
            y, tr = onda_ventana("II"); return n == 0 and np.isnan(y).all(), f"{n} muestras visibles; ECG inválido = {np.isnan(y).all()}"
        if t == "extrasistoles_aisladas":
            y, tr = onda_ventana("II"); yo = Tramo(tramo_orig).canal_completo("II")[1][int(t0 * tr.fs):int(t1 * tr.fs)]
            n1, n0 = len(detectar_picos_r(y, tr.fs)), len(detectar_picos_r(yo, tr.fs))
            return n1 - n0 == par.get("n_latidos", 3), f"latidos en la ventana: {n0} -> {n1} (se esperan +{par.get('n_latidos', 3)})"
        if t == "unidades_erroneas":
            v = vis(par["variable"], t0, t0, "chartevents"); return len(v) == 1, f"{par['variable']} = {v}"
        if t == "desfase_reloj":
            return True, "registros manuales de la ventana fuera de la vista (hora futura)"
        return True, "sin verificación automática"
    except Exception as e:                                   # noqa: BLE001
        return False, f"error al verificar: {e}"


# ------------------------------------------------------------
# Programa principal
# ------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default=str(RUTA_BASE))
    ap.add_argument("--salida", default=None, help="base de salida (por defecto benchmark_uti_validacion.db junto a la de origen)")
    ap.add_argument("--sobrescribir", action="store_true")
    a = ap.parse_args()

    origen = Path(a.db)
    destino = Path(a.salida) if a.salida else origen.with_name("benchmark_uti_validacion.db")
    if not origen.exists():
        sys.exit(f"No existe la base de origen: {origen}")
    if destino.exists():
        if not a.sobrescribir:
            sys.exit(f"Ya existe {destino.name}. Usá --sobrescribir para rehacerla desde cero (el original no se toca).")
        destino.unlink()
    shutil.copy2(origen, destino)
    print(f"Base de trabajo: {destino}\n(el original {origen.name} no se modifica)\n")

    plan = pd.read_csv(buscar("plan_inyeccion_v3.csv"), encoding="utf-8-sig")
    con = sqlite3.connect(destino)
    con.execute("PRAGMA foreign_keys=OFF")
    con.executescript("""
        DROP TABLE IF EXISTS inyecciones_aplicadas;
        CREATE TABLE inyecciones_aplicadas (
            falla_id INTEGER PRIMARY KEY, escenario TEXT, cama_id INTEGER, estadia_id INTEGER, tipo TEXT, canal TEXT,
            t_inicio_s REAL, t_fin_s REAL, capa TEXT, filas_reemplazadas INTEGER, filas_ausentes INTEGER,
            filas_nuevas INTEGER, nota TEXT, estado TEXT, verificacion TEXT, detalle_verificacion TEXT, huecos_solapados TEXT);
    """)
    actualizar_vista(con)
    huecos = cargar_huecos(con)
    num = Numerico(con)
    ondas, camas = {}, {r[0]: r[1] for r in con.execute("SELECT cama_id, estadia_id FROM estadias WHERE es_actual=1")}
    filas = []

    for _, f in plan.sort_values(["cama_id", "t_inicio_s"]).iterrows():
        est = camas[int(f["cama_id"])]
        num.reset()
        try:
            capa, nota = aplicar(f, est, num, ondas, con)
            estado = {"runtime": "runtime", "pendiente": "pendiente"}.get(capa, "aplicada")
        except Exception as e:                                               # noqa: BLE001
            capa, nota, estado = "error", str(e), "error"
        filas.append((f, est, capa, nota, estado, num.n_reemp, num.n_aus, num.n_nuevas))

    # --- escribir los tramos modificados y registrarlos ---
    nuevas = {}
    for est, (o, ruta_rel) in ondas.items():
        if not o.tocado:
            continue
        fila = con.execute("SELECT * FROM tramos_senal WHERE estadia_id=? AND es_benchmark=1 ORDER BY tramo_id LIMIT 1", (est,)).fetchone()
        cols = [d[0] for d in con.execute("SELECT * FROM tramos_senal LIMIT 0").description]
        reg = dict(zip(cols, fila))
        stem = Path(str(ruta_rel).replace("\\", "/")).name                  # p. ej. 43870_tramo
        nombre = stem + "_falla"
        carpeta = RAIZ / "SCRIPTS" / CARPETA_SALIDA_TRAMOS
        sha = o.guardar(carpeta / nombre, nombre)
        ruta_nueva = f"SCRIPTS\\{CARPETA_SALIDA_TRAMOS}\\{nombre}"
        con.execute("UPDATE tramos_senal SET es_benchmark=0 WHERE tramo_id=?", (reg["tramo_id"],))
        reg.pop("tramo_id")
        reg.update(version="con_falla", es_benchmark=1, ruta_archivo=ruta_nueva, origen_dato="inyectado")
        con.execute(f"INSERT INTO tramos_senal({','.join(reg)}) VALUES ({','.join('?' * len(reg))})", list(reg.values()))
        nuevas[est] = (carpeta / nombre, sha)

    # --- verificar y registrar ---
    print(f"{'#':>2} {'esc':4} {'cama':>4}  {'tipo':26} {'capa':15} {'estado':10} verificación")
    malas = 0
    for f, est, capa, nota, estado, nr, na, nn in filas:
        ver, det = "n/a", ""
        par_f = json.loads(f["parametros"]) if isinstance(f["parametros"], str) and f["parametros"].strip() else {}
        hs = solapes_con_huecos(huecos, f, par_f)
        if estado == "aplicada":
            base = nuevas[est][0] if est in nuevas else None
            orig = ondas[est][0].tr.base if est in ondas else None
            ok, det = verificar(con, f, est, base, orig)
            ver = "OK" if ok else "REVISAR"
            malas += (not ok)
        elif estado == "error":
            malas += 1
        con.execute("INSERT INTO inyecciones_aplicadas VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (int(f["falla_id"]), f["escenario"], int(f["cama_id"]), est, f["tipo"], f["canal"], float(f["t_inicio_s"]),
                     float(f["t_fin_s"]), capa, nr, na, nn, nota, estado, ver, det, "; ".join(hs)))
        print(f"{int(f['falla_id']):>2} {f['escenario']:4} {int(f['cama_id']):>4}  {f['tipo']:26} {capa:15} {estado:10} {ver} {det}")
        if hs:
            print(f"{'':>8}huecos naturales en la ventana: {'; '.join(hs)}")
    con.commit()

    tot = con.execute("SELECT origen_dato, COUNT(*) FROM mediciones GROUP BY origen_dato").fetchall()
    print(f"\nmediciones por origen: {tot}")
    print(f"tramos modificados: {len(nuevas)} -> {RAIZ / 'SCRIPTS' / CARPETA_SALIDA_TRAMOS}")
    print("Resumen:", con.execute("SELECT estado, COUNT(*) FROM inyecciones_aplicadas GROUP BY estado").fetchall())
    con.close()
    print("\nListo." if not malas else f"\nOJO: {malas} inyecciones para revisar (ver arriba).")


if __name__ == "__main__":
    main()
