# ============================================================
# persistencia.py - Base propia de la plataforma (plataforma_uti.db)
#
# Guarda lo que GENERA la plataforma (eventos de alarma, reconocimientos, movimientos de
# cama, dotación, inventario). Es independiente de benchmark_uti.db, que queda intacta.
# Cada "corrida" (una simulación) tiene su propio id: los eventos de una corrida no se
# mezclan con los de otra.
# Sin dependencias de Streamlit.
# ============================================================

import json
import sqlite3
import threading
from datetime import datetime

import pandas as pd

from datos_db import RUTA_BASE

RUTA_PLATAFORMA = RUTA_BASE.with_name("plataforma_uti.db")

ESQUEMA = """
CREATE TABLE IF NOT EXISTS corridas (
    corrida_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    inicio_real  TEXT NOT NULL,
    operador     TEXT
);
CREATE TABLE IF NOT EXISTS eventos (
    evento_id        INTEGER PRIMARY KEY AUTOINCREMENT,
    corrida_id       INTEGER NOT NULL REFERENCES corridas(corrida_id),
    cama_id          INTEGER NOT NULL,
    regla            TEXT NOT NULL,
    nivel            TEXT NOT NULL,          -- CRITICA / ADVERTENCIA / REQUIERE REVISION
    mensaje          TEXT,
    valores          TEXT,                   -- JSON con los valores que dispararon la regla
    t_inicio_s       REAL NOT NULL,
    t_fin_s          REAL,
    reconocido_por   TEXT,
    t_reconocido_s   REAL
);
CREATE INDEX IF NOT EXISTS idx_eventos ON eventos (corrida_id, cama_id, regla);
CREATE TABLE IF NOT EXISTS ocupacion (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    corrida_id   INTEGER NOT NULL REFERENCES corridas(corrida_id),
    t_s          REAL,
    cama_id      INTEGER NOT NULL,
    estadia_id   INTEGER,                    -- NULL = cama liberada
    operador     TEXT,
    motivo       TEXT
);
CREATE TABLE IF NOT EXISTS dotacion (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    registrado   TEXT NOT NULL,
    enfermeros   INTEGER, medicos INTEGER, kinesiologos INTEGER, horas_turno REAL,
    operador     TEXT
);
CREATE TABLE IF NOT EXISTS equipos (
    equipo_id  TEXT PRIMARY KEY,
    tipo TEXT, marca TEXT, modelo TEXT, sn TEXT, ubicacion TEXT
);
CREATE TABLE IF NOT EXISTS equipos_historial (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    equipo_id  TEXT NOT NULL REFERENCES equipos(equipo_id),
    registrado TEXT NOT NULL,
    accion     TEXT,
    detalle    TEXT,
    operador   TEXT
);
"""

DOTACION_INICIAL = (8, 2, 2, 8.5)   # enfermeros, médicos, kinesiólogos, horas del turno (declarada)


def _ahora():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


class Persistencia:
    def __init__(self, ruta=None):
        self.ruta = ruta or RUTA_PLATAFORMA
        self._lock = threading.RLock()
        self.con = sqlite3.connect(str(self.ruta), check_same_thread=False)
        self.con.execute("PRAGMA foreign_keys = ON")
        with self._lock:
            self.con.executescript(ESQUEMA)
            self.con.commit()
        self._inventario_inicial()

    # ---------------- corridas ----------------
    def nueva_corrida(self, operador):
        with self._lock:
            cur = self.con.execute("INSERT INTO corridas (inicio_real, operador) VALUES (?, ?)",
                                   (_ahora(), operador))
            self.con.commit()
            return cur.lastrowid

    # ---------------- eventos de alarma ----------------
    def sincronizar_alarmas(self, corrida_id, cama_id, t_s, activas):
        """activas = [{'regla','nivel','mensaje','valores'}]. Abre las nuevas y cierra las que dejaron de cumplirse."""
        with self._lock:
            abiertas = {r[1]: (r[0], r[2]) for r in self.con.execute(
                "SELECT evento_id, regla, nivel FROM eventos "
                "WHERE corrida_id=? AND cama_id=? AND t_fin_s IS NULL", (corrida_id, cama_id))}
            reglas_activas = {a["regla"] for a in activas}
            cambios = 0
            for a in activas:
                if a["regla"] not in abiertas:
                    self.con.execute(
                        "INSERT INTO eventos (corrida_id, cama_id, regla, nivel, mensaje, valores, t_inicio_s) "
                        "VALUES (?,?,?,?,?,?,?)",
                        (corrida_id, cama_id, a["regla"], a["nivel"], a["mensaje"],
                         json.dumps(a.get("valores", {}), default=float), float(t_s)))
                    cambios += 1
                elif abiertas[a["regla"]][1] != a["nivel"]:
                    self.con.execute("UPDATE eventos SET nivel=? WHERE evento_id=?",
                                     (a["nivel"], abiertas[a["regla"]][0]))
                    cambios += 1
            for regla, (eid, _) in abiertas.items():
                if regla not in reglas_activas:
                    self.con.execute("UPDATE eventos SET t_fin_s=? WHERE evento_id=?", (float(t_s), eid))
                    cambios += 1
            if cambios:           # solo se escribe en disco cuando hay algo nuevo
                self.con.commit()

    def cerrar_todas(self, corrida_id, t_s):
        with self._lock:
            self.con.execute("UPDATE eventos SET t_fin_s=? WHERE corrida_id=? AND t_fin_s IS NULL",
                             (float(t_s), corrida_id))
            self.con.commit()

    def reconocer(self, evento_id, operador, t_s):
        with self._lock:
            self.con.execute("UPDATE eventos SET reconocido_por=?, t_reconocido_s=? "
                             "WHERE evento_id=? AND reconocido_por IS NULL", (operador, float(t_s), evento_id))
            self.con.commit()

    def eventos(self, corrida_id, cama_id=None):
        sql = "SELECT * FROM eventos WHERE corrida_id=?"
        par = [corrida_id]
        if cama_id is not None:
            sql += " AND cama_id=?"
            par.append(cama_id)
        with self._lock:
            return pd.read_sql(sql + " ORDER BY t_inicio_s DESC, evento_id DESC", self.con, params=par)

    # ---------------- ocupación de camas (órdenes ADT) ----------------
    def ocupacion(self, corrida_id, base_camas):
        """{cama_id: estadia_id | None}. base_camas = {cama_id: estadia_id} de la base; las órdenes ADT lo modifican."""
        estado = dict(base_camas)
        with self._lock:
            for cama, est in self.con.execute(
                    "SELECT cama_id, estadia_id FROM ocupacion WHERE corrida_id=? ORDER BY id", (corrida_id,)):
                estado[cama] = est
        return estado

    def registrar_orden_adt(self, corrida_id, t_s, cama_id, estadia_id, operador, motivo=""):
        with self._lock:
            self.con.execute("INSERT INTO ocupacion (corrida_id, t_s, cama_id, estadia_id, operador, motivo) "
                             "VALUES (?,?,?,?,?,?)", (corrida_id, float(t_s), cama_id, estadia_id, operador, motivo))
            self.con.commit()

    def ordenes_adt(self, corrida_id):
        with self._lock:
            return pd.read_sql("SELECT t_s, cama_id, estadia_id, operador, motivo FROM ocupacion "
                               "WHERE corrida_id=? ORDER BY id DESC", self.con, params=[corrida_id])

    # ---------------- dotación ----------------
    def dotacion(self):
        with self._lock:
            fila = self.con.execute("SELECT enfermeros, medicos, kinesiologos, horas_turno FROM dotacion "
                                    "ORDER BY id DESC LIMIT 1").fetchone()
        enf, med, kin, hs = fila or DOTACION_INICIAL
        return {"enfermeros": enf, "medicos": med, "kinesiologos": kin, "horas_turno": hs}

    def guardar_dotacion(self, enf, med, kin, hs, operador):
        with self._lock:
            self.con.execute("INSERT INTO dotacion (registrado, enfermeros, medicos, kinesiologos, horas_turno, operador) "
                             "VALUES (?,?,?,?,?,?)", (_ahora(), enf, med, kin, hs, operador))
            self.con.commit()

    # ---------------- inventario de equipos ----------------
    def _inventario_inicial(self):
        with self._lock:
            if self.con.execute("SELECT COUNT(*) FROM equipos").fetchone()[0]:
                return
            ahora = _ahora()
            filas = []
            for i in range(1, 16):
                box = f"BOX-{i:02d}"
                filas.append((f"Ventilador-{i:02d}-UTI1", "Ventilador Mecánico", "TECME", "Neumovent Advance", f"TM-{1000 + i}", box))
                filas.append((f"Monitor-{i:02d}-UTI1", "Monitor Multiparamétrico", "Mindray", "BeneVision N15", f"MD-{5000 + i}", box))
            for i in range(1, 4):
                filas.append((f"Ventilador-SOPORTE{i}-UTI1", "Ventilador Mecánico", "TECME", "Neumovent Advance", f"TM-SOP{i}", "DEPOSITO"))
                filas.append((f"Monitor-SOPORTE{i}-UTI1", "Monitor Multiparamétrico", "Mindray", "BeneVision N15", f"MD-SOP{i}", "DEPOSITO"))
            self.con.executemany("INSERT INTO equipos VALUES (?,?,?,?,?,?)", filas)
            self.con.executemany(
                "INSERT INTO equipos_historial (equipo_id, registrado, accion, detalle, operador) VALUES (?,?,?,?,?)",
                [(f[0], ahora, "ALTA INICIAL", f"Asignado a {f[5]}", "sistema") for f in filas])
            self.con.commit()

    def equipos(self):
        with self._lock:
            return pd.read_sql("SELECT * FROM equipos ORDER BY equipo_id", self.con)

    def mover_equipo(self, equipo_id, destino, observacion, operador):
        with self._lock:
            ant = self.con.execute("SELECT ubicacion FROM equipos WHERE equipo_id=?", (equipo_id,)).fetchone()[0]
            self.con.execute("UPDATE equipos SET ubicacion=? WHERE equipo_id=?", (destino, equipo_id))
            self.con.execute("INSERT INTO equipos_historial (equipo_id, registrado, accion, detalle, operador) "
                             "VALUES (?,?,?,?,?)",
                             (equipo_id, _ahora(), "TRASLADO",
                              f"De {ant} a {destino}. Obs: {observacion or 'Reasignación operativa'}", operador))
            self.con.commit()

    def historial_equipo(self, equipo_id):
        with self._lock:
            return pd.read_sql("SELECT registrado, accion, detalle, operador FROM equipos_historial "
                               "WHERE equipo_id=? ORDER BY id DESC", self.con, params=[equipo_id])
