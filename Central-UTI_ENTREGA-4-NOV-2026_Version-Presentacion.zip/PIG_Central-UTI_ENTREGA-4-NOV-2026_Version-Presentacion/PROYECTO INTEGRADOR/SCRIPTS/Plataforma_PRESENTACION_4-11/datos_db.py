# ============================================================
# datos_db.py - Capa de datos de la plataforma (solo lectura)
#
# - Abre benchmark_uti.db en SOLO LECTURA.
# - Consulta únicamente las vistas v_* y tablas de contexto. Nunca las tablas de
#   validación (escenarios, asignaciones, eventos_esperados, fallas_tecnicas,
#   anomalias_reales) ni las columnas plausible / origen_dato.
# - Nada de lo que devuelve es posterior al instante pedido (t_s).
# - No depende de Streamlit: se puede usar y probar desde la consola.
#
# Reglas v2 (22/10/2026): snapshot() agrega 'previos' y 'fuentes' (persistencia, D3) y la PA no
# invasiva tiene vigencia propia de 60 min (D6), leída de parametros_validacion.csv.
# config.py se toma primero de esta carpeta (versión con UTI_DB).
#
# Convención de tiempo: t_s = segundos desde el minuto 0 (inicio del tramo).
#   t_s < 0 -> historia previa (hasta 24 h); 0 <= t_s <= 1800 -> tramo en vivo.
# ============================================================

import sys
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
import sqlite3

# --- importar config.py: primero el de esta carpeta (versión con UTI_DB / BASE_ORIGINAL), después SCRIPTS\Funciones
_AQUI = Path(__file__).resolve().parent
for _carpeta in (_AQUI, _AQUI.parent / "Funciones", _AQUI / "Funciones"):
    if (_carpeta / "config.py").exists():
        sys.path.insert(0, str(_carpeta))
        break
from config import RUTA_BASE, RAIZ, ANCLAJE_MINUTO_0, DURACION_TRAMO_S  # noqa: E402

# Variables que salen de un monitor / respirador (se espera dato cada minuto)
VARIABLES_MONITOR = {"fc", "pulso", "spo2", "fr", "fr_total", "pa_inv_sis", "pa_inv_dia", "pa_inv_media", "pvc"}
VIGENCIA_MONITOR_S = 5 * 60          # un valor de monitor de más de 5 min ya no es "en vivo"
VIGENCIA_MANUAL_S = 4 * 3600         # signos cargados por enfermería (PA no invasiva, T°, GCS, FiO2)
VIGENCIA_LAB_S = 24 * 3600           # laboratorio
VARIABLES_LAB = {"pao2", "creatinina", "bilirrubina_total", "plaquetas"}
VENTANA_PEOR_S = 8 * 3600            # ventana para el "peor valor del turno"
# Tipo de ingreso: la base lo trae en inglés (MIMIC). Un valor que no esté acá no se muestra.
TIPO_INGRESO_ES = {"EMERGENCY": "Urgencia", "URGENT": "Urgencia", "ELECTIVE": "Programado"}

# [reglas v2] D6: la presión no invasiva tiene vigencia propia (antes 4 h, como la temperatura).
# Se lee de parametros_validacion.csv (la misma especificación que usa el Paso10); si no está, 60 min.
VARIABLES_PNI = {"pa_ni_sis", "pa_ni_dia", "pa_ni_media"}
VIGENCIA_PNI_S = 3600
SALTO_MAX_S = 150                    # D3: dos muestras a más de 150 s no son "seguidas"
for _c in (Path(RUTA_BASE).parent, Path(RAIZ), _AQUI.parent, _AQUI):
    _f = _c / "parametros_validacion.csv"
    if _f.exists():
        _par = pd.read_csv(_f, encoding="utf-8-sig").set_index("clave")["valor"].to_dict()
        VIGENCIA_PNI_S = float(_par.get("vigencia_pni_s", VIGENCIA_PNI_S))
        SALTO_MAX_S = float(_par.get("salto_max_s", SALTO_MAX_S))
        break

# Prioridad cuando dos fuentes tienen el mismo instante (gana la de número mayor)
_PRIORIDAD_FUENTE = {"chartevents": 0, "labevents": 0, "calculado": 1, "numericos": 2}


@dataclass
class Dato:
    valor: float | None
    t_s: float
    antiguedad_s: float
    fuente: str
    texto: str | None = None
    calidad: str | None = None
    vigente: bool = True


def vigencia_s(variable):
    if variable in VARIABLES_MONITOR:
        return VIGENCIA_MONITOR_S
    if variable in VARIABLES_LAB:
        return VIGENCIA_LAB_S
    if variable in VARIABLES_PNI:
        return VIGENCIA_PNI_S
    return VIGENCIA_MANUAL_S


class BaseUTI:
    def __init__(self, ruta=None):
        self.ruta = Path(ruta or RUTA_BASE)
        if not self.ruta.exists():
            raise FileNotFoundError(f"No existe la base: {self.ruta}\nCorré antes Paso8 y Paso9.")
        uri = self.ruta.resolve().as_uri() + "?mode=ro"
        con = sqlite3.connect(uri, uri=True)
        try:
            self._cargar(con)
        finally:
            con.close()

    # ---------------------------------------------------------
    def _cargar(self, con):
        self.parametros = dict(con.execute("SELECT clave, valor FROM parametros").fetchall())
        self.anclaje = datetime.strptime(self.parametros.get("anclaje_minuto_0", ANCLAJE_MINUTO_0),
                                         "%Y-%m-%d %H:%M:%S")
        self.duracion_s = float(self.parametros.get("duracion_tramo", DURACION_TRAMO_S))
        self.total_camas = int(self.parametros.get("total_camas", 15))

        self.rangos = {v: (mn, mx) for v, mn, mx in
                       con.execute("SELECT variable, rango_min, rango_max FROM variables")}
        self.unidades = dict(con.execute("SELECT variable, unidad FROM variables").fetchall())

        est = pd.read_sql("SELECT * FROM v_estadias_visibles", con)
        pac = pd.read_sql("SELECT subject_id, sexo, edad, edad_anonimizada FROM pacientes", con)
        self.estadias = est.merge(pac, on="subject_id", how="left").set_index("estadia_id", drop=False)

        self.camas = pd.read_sql("SELECT cama_id, perfil_canales, equipamiento, estadia_actual FROM camas "
                                 "ORDER BY cama_id", con)
        self.tramos = pd.read_sql("SELECT estadia_id, ruta_archivo, fs, canales, duracion_s "
                                  "FROM v_tramos_visibles", con).set_index("estadia_id")

        med = pd.read_sql("SELECT estadia_id, variable, t_s, valor, valor_texto, fuente, calidad "
                          "FROM v_mediciones_visibles", con)
        med["prio"] = med["fuente"].map(_PRIORIDAD_FUENTE).fillna(0).astype(int)
        self._series = {}
        for (eid, var), g in med.groupby(["estadia_id", "variable"], sort=False):
            orden = np.lexsort((g["prio"].to_numpy(), g["t_s"].to_numpy()))
            g = g.iloc[orden]
            self._series[(int(eid), var)] = {
                "t": g["t_s"].to_numpy(float),
                "v": g["valor"].to_numpy(float),
                "fuente": g["fuente"].to_numpy(object),
                "texto": g["valor_texto"].to_numpy(object),
                "calidad": g["calidad"].to_numpy(object),
            }

    # ---------------------------------------------------------
    # Tiempo
    # ---------------------------------------------------------
    def hora_sim(self, t_s):
        return self.anclaje + timedelta(seconds=float(t_s))

    # ---------------------------------------------------------
    # Consultas puntuales
    # ---------------------------------------------------------
    def ultimo(self, estadia_id, variable, t_s):
        """Último dato de `variable` con t <= t_s (o None). Nunca devuelve datos del futuro."""
        s = self._series.get((int(estadia_id), variable))
        if s is None:
            return None
        i = int(np.searchsorted(s["t"], t_s, side="right")) - 1
        if i < 0:
            return None
        antig = float(t_s - s["t"][i])
        valor = s["v"][i]
        return Dato(valor=None if np.isnan(valor) else float(valor), t_s=float(s["t"][i]),
                    antiguedad_s=antig, fuente=str(s["fuente"][i]), texto=s["texto"][i],
                    calidad=s["calidad"][i], vigente=antig <= vigencia_s(variable))

    def previo(self, estadia_id, variable, dato):
        """[reglas v2] D3: valor de la muestra anterior de la MISMA fuente, si está a <= SALTO_MAX_S.
        Sirve para exigir persistencia (2 muestras seguidas). Nunca mira el futuro."""
        if dato is None:
            return None
        if hasattr(self, "_sync"):                     # receptor de emisores virtuales: series en memoria
            self._sync(estadia_id, variable)
        s = self._series.get((int(estadia_id), variable))
        if s is None:
            return None
        i = int(np.searchsorted(s["t"], dato.t_s, side="left")) - 1
        while i >= 0 and s["fuente"][i] != dato.fuente:
            i -= 1
        if i < 0 or dato.t_s - s["t"][i] > SALTO_MAX_S or np.isnan(s["v"][i]):
            return None
        return float(s["v"][i])

    def serie(self, estadia_id, variable, t_ini, t_fin, fuente=None):
        """Serie [t_ini, t_fin] como DataFrame (t_s, valor, fuente)."""
        s = self._series.get((int(estadia_id), variable))
        if s is None:
            return pd.DataFrame(columns=["t_s", "valor", "fuente"])
        a = int(np.searchsorted(s["t"], t_ini, side="left"))
        b = int(np.searchsorted(s["t"], t_fin, side="right"))
        df = pd.DataFrame({"t_s": s["t"][a:b], "valor": s["v"][a:b], "fuente": s["fuente"][a:b]})
        if fuente:
            df = df[df["fuente"] == fuente]
        return df.reset_index(drop=True)

    def rango(self, variable):
        mn, mx = self.rangos.get(variable, (None, None))
        return mn, mx

    def fuera_de_rango(self, variable, valor):
        mn, mx = self.rango(variable)
        if valor is None:
            return False
        return (mn is not None and valor < mn) or (mx is not None and valor > mx)

    def medidas(self, estadia_id, t_ini, t_fin):
        """Todas las mediciones visibles de una estadía con t_ini < t <= t_fin, como tuplas
        (variable, t_s, valor, texto, fuente). Las usa el emisor de reproducción (emisor.py)."""
        eid = int(estadia_id)
        salida = []
        for (e, var), s in self._series.items():
            if e != eid:
                continue
            a = int(np.searchsorted(s["t"], t_ini, side="right"))
            b = int(np.searchsorted(s["t"], t_fin, side="right"))
            for i in range(a, b):
                v = s["v"][i]
                salida.append((var, float(s["t"][i]), None if np.isnan(v) else float(v), s["texto"][i], str(s["fuente"][i])))
        salida.sort(key=lambda m: m[1])
        return salida

    # ---------------------------------------------------------
    # Estadías y camas
    # ---------------------------------------------------------
    def estadia_de_cama(self, cama_id):
        fila = self.camas.loc[self.camas["cama_id"] == cama_id, "estadia_actual"]
        if fila.empty or pd.isna(fila.iloc[0]):
            return None
        return int(fila.iloc[0])

    def ids_estadias(self):
        return [int(e) for e in self.estadias["estadia_id"]]

    def ficha(self, estadia_id):
        e = self.estadias.loc[int(estadia_id)]
        edad = "89+" if e.get("edad_anonimizada") == 1 else ("" if pd.isna(e.get("edad")) else int(e["edad"]))
        return {
            "estadia_id": int(estadia_id),
            "subject_id": int(e["subject_id"]),
            "unidad": e.get("unidad") or "",
            "tipo_internacion": e.get("tipo_internacion") or "",
            "edad": edad,
            "sexo": e.get("sexo") or "",
            "t_ingreso_s": float(e["t_ingreso_s"]) if not pd.isna(e["t_ingreso_s"]) else None,
        }

    def descripcion(self, estadia_id):
        """Texto corto para tarjetas (la base no tiene diagnóstico: se muestra tipo de ingreso en castellano, edad y sexo).
        El código de unidad de la base (MICU, SICU, CCU...) no se muestra: corresponde al origen de los datos y confunde."""
        f = self.ficha(estadia_id)
        partes = []
        tipo = TIPO_INGRESO_ES.get(str(f["tipo_internacion"]).strip().upper())
        if tipo:
            partes.append(tipo)
        persona = f"{f['edad']} años {f['sexo']}".strip() if f["edad"] != "" else str(f["sexo"]).strip()
        if persona:
            partes.append(persona)
        return " | ".join(partes).upper()

    def dias_estancia(self, estadia_id, t_s):
        t_in = self.ficha(estadia_id)["t_ingreso_s"]
        return None if t_in is None else max(0.0, (t_s - t_in) / 86400.0)

    # ---------------------------------------------------------
    # Instantánea de una estadía (lo que "ve" el monitor central en t_s)
    # ---------------------------------------------------------
    def snapshot(self, estadia_id, t_s):
        eid = int(estadia_id)
        d = lambda v: self.ultimo(eid, v, t_s)
        val = lambda x: None if x is None else x.valor

        # Presión arterial: invasiva si está en vivo; si no, no invasiva (con su antigüedad)
        inv = {k: d(f"pa_inv_{k}") for k in ("sis", "dia", "media")}
        ni = {k: d(f"pa_ni_{k}") for k in ("sis", "dia", "media")}
        inv_viva = any(x is not None and x.vigente for x in inv.values())
        origen_pa, pa = ("INV", inv) if inv_viva else (("NI", ni) if any(ni.values()) else (None, ni))
        sis, dia, media = (val(pa[k]) for k in ("sis", "dia", "media"))
        pam_calculada = False
        if media is None and sis is not None and dia is not None:
            media, pam_calculada = dia + (sis - dia) / 3.0, True
        dato_pa = next((x for x in (pa["media"], pa["sis"], pa["dia"]) if x is not None), None)

        fr, var_fr = d("fr"), "fr"
        if fr is None or not fr.vigente:
            alt = d("fr_total")
            if alt is not None and (fr is None or alt.t_s > fr.t_s):
                fr, var_fr = alt, "fr_total"

        datos = {
            "fc": d("fc"), "pulso": d("pulso"), "spo2": d("spo2"), "fr": fr, "pvc": d("pvc"),
            "pa": dato_pa, "temperatura": d("temperatura"), "fio2": d("fio2"),
            "dispositivo_o2": d("dispositivo_o2"), "gcs": d("gcs_total"),
            "pao2": d("pao2"), "creatinina": d("creatinina"),
            "bilirrubina_total": d("bilirrubina_total"), "plaquetas": d("plaquetas"),
        }

        # Peor valor en la ventana del turno.
        # [unificada] Solo con mediciones válidas: se descartan los 0 (sensor desconectado) y los
        # valores fuera del rango fisiológico de la tabla `variables`, para que una desconexión no
        # quede registrada como "peor valor". Se informa cuántas muestras se descartaron.
        t0 = t_s - VENTANA_PEOR_S
        descartados = {}
        def extremo(var, fun):
            s = self.serie(eid, var, t0, t_s)
            s = s.dropna(subset=["valor"])
            mn, mx = self.rango(var)
            ok = s["valor"] != 0
            if mn is not None:
                ok &= s["valor"] >= mn
            if mx is not None:
                ok &= s["valor"] <= mx
            descartados[var] = int((~ok).sum())
            s = s[ok]
            return None if s.empty else float(fun(s["valor"]))
        var_pam = "pa_inv_media" if origen_pa == "INV" else "pa_ni_media"

        # Tendencia de FC (últimos 150 minutos)
        tend = self.serie(eid, "fc", t_s - 150 * 60, t_s).dropna(subset=["valor"])["valor"].tolist()

        # [reglas v2] D3: muestra anterior de cada variable (persistencia) y fuente de la actual.
        # Solo los numéricos del monitor exigen persistencia; una medición manual vale por sí misma (D6).
        pref = "pa_inv_" if origen_pa == "INV" else "pa_ni_"
        actuales = {"fc": ("fc", datos["fc"]), "spo2": ("spo2", datos["spo2"]), "fr": (var_fr, fr),
                    "pas": (pref + "sis", pa["sis"]), "pad": (pref + "dia", pa["dia"]),
                    "pam": (pref + "media", pa["media"])}
        previos = {k: self.previo(eid, var, dato) for k, (var, dato) in actuales.items()}
        fuentes = {k: (dato.fuente if dato is not None else None) for k, (var, dato) in actuales.items()}

        return {
            "estado": "OCUPADA", "estadia_id": eid, "t_s": float(t_s),
            "previos": previos, "fuentes": fuentes,
            "diagnostico": self.descripcion(eid),
            "datos": datos,
            "fc": val(datos["fc"]), "spo2": val(datos["spo2"]), "fr": val(fr), "fio2": val(datos["fio2"]),
            "gcs": val(datos["gcs"]), "pas": sis, "pad": dia, "pam": media,
            "pa_origen": origen_pa, "pam_calculada": pam_calculada,
            "tendencia_fc": tend,
            "peor_fc": extremo("fc", np.max), "peor_pam": extremo(var_pam, np.min),
            "peor_spo2": extremo("spo2", np.min),
            "peor_descartados": {"fc": descartados.get("fc", 0), "pam": descartados.get(var_pam, 0),
                                 "spo2": descartados.get("spo2", 0)},
        }

    # ---------------------------------------------------------
    # Señal continua del tramo
    # ---------------------------------------------------------
    def info_tramo(self, estadia_id):
        if int(estadia_id) not in self.tramos.index:
            return None
        t = self.tramos.loc[int(estadia_id)]
        ruta = RAIZ.joinpath(*str(t["ruta_archivo"]).replace("\\", "/").split("/"))
        return {"ruta": ruta, "fs": float(t["fs"]),
                "canales": [c.strip() for c in str(t["canales"]).split(",")],
                "duracion_s": float(t["duracion_s"])}
