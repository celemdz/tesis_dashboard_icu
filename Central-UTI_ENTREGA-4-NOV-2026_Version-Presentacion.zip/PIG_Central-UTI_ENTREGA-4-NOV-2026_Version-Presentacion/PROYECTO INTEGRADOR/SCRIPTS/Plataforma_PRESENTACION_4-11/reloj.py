# ============================================================
# reloj.py - Reloj de simulación (sin dependencias de Streamlit)
# ============================================================
import time

VELOCIDADES = [1, 5, 10, 30, 60]


class RelojSim:
    def __init__(self, t_max=1800.0, t_min=0.0, t_inicial=0.0, velocidad=1):
        self.t_min, self.t_max = float(t_min), float(t_max)
        self.t_s = float(t_inicial)
        self.velocidad = velocidad
        self.corriendo = False
        self._ultimo = None

    def iniciar(self, ahora=None):
        if self.t_s >= self.t_max:
            self.t_s = self.t_min
        self.corriendo = True
        self._ultimo = time.monotonic() if ahora is None else ahora

    def pausar(self):
        self.avanzar()
        self.corriendo = False

    def ir_a(self, t_s):
        self.t_s = min(max(float(t_s), self.t_min), self.t_max)
        self._ultimo = time.monotonic()

    def reiniciar(self):
        self.corriendo = False
        self.t_s = self.t_min
        self._ultimo = None

    def avanzar(self, ahora=None, paso_max_real=5.0):
        """Suma el tiempo real transcurrido x velocidad. Devuelve el t_s actual."""
        ahora = time.monotonic() if ahora is None else ahora
        if self.corriendo and self._ultimo is not None:
            dt = min(max(ahora - self._ultimo, 0.0), paso_max_real)
            self.t_s = min(self.t_s + dt * self.velocidad, self.t_max)
            if self.t_s >= self.t_max:
                self.corriendo = False
        self._ultimo = ahora
        return self.t_s
